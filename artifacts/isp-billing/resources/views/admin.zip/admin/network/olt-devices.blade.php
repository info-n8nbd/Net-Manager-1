@extends('layouts.admin')

@section('title', 'OLT Devices')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
<li class="breadcrumb-item">Network</li>
<li class="breadcrumb-item active">OLT Devices</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-server mr-2"></i>OLT Devices</h3>
        <div class="card-tools">
            <a href="{{ route('admin.olt.create') }}" class="btn btn-primary btn-sm">
                <i class="fas fa-plus mr-1"></i>Add OLT Device
            </a>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Name</th>
                        <th>IP Address</th>
                        <th>Vendor</th>
                        <th>Model</th>
                        <th>Location</th>
                        <th>Ports</th>
                        <th>Status</th>
                        <th width="150">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($olts as $olt)
                    <tr>
                        <td><strong>{{ $olt->name }}</strong></td>
                        <td><code>{{ $olt->ip_address }}:{{ $olt->port }}</code></td>
                        <td><span class="badge badge-info">{{ $olt->vendor_name }}</span></td>
                        <td>{{ $olt->model ?? 'N/A' }}</td>
                        <td>{{ $olt->location ?? 'N/A' }}</td>
                        <td>{{ $olt->total_ports }}</td>
                        <td>
                            @if($olt->is_active)
                                <span class="badge badge-success">Active</span>
                            @else
                                <span class="badge badge-danger">Inactive</span>
                            @endif
                        </td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-info btn-sm" onclick="testConnection({{ $olt->id }})" title="Test Connection">
                                    <i class="fas fa-plug"></i>
                                </button>
                                <a href="{{ route('admin.olt.edit', $olt) }}" class="btn btn-warning btn-sm" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="{{ route('admin.olt.destroy', $olt) }}" method="POST" style="display:inline" onsubmit="return confirm('Are you sure?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <i class="fas fa-server fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No OLT devices found. <a href="{{ route('admin.olt.create') }}">Add one now</a>.</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($olts->hasPages())
    <div class="card-footer">
        {{ $olts->links() }}
    </div>
    @endif
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card card-outline card-info">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-info-circle mr-2"></i>Supported OLT Vendors</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 col-6 mb-3">
                        <div class="info-box bg-gradient-primary">
                            <span class="info-box-icon"><i class="fas fa-network-wired"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Huawei</span>
                                <span class="info-box-number">MA5680T, MA5683T</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="info-box bg-gradient-success">
                            <span class="info-box-icon"><i class="fas fa-network-wired"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">ZTE</span>
                                <span class="info-box-number">C300, C320, C600</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="info-box bg-gradient-warning">
                            <span class="info-box-icon"><i class="fas fa-network-wired"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">BDCOM</span>
                                <span class="info-box-number">GP3600, P3310</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="info-box bg-gradient-danger">
                            <span class="info-box-icon"><i class="fas fa-network-wired"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">VSOL</span>
                                <span class="info-box-number">V1600, V1600G</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function testConnection(oltId) {
    Swal.fire({
        title: 'Testing Connection...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });
    
    $.ajax({
        url: '/admin/network/olt/' + oltId + '/test',
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        success: function(response) {
            if (response.success) {
                Swal.fire('Success!', response.message, 'success');
            } else {
                Swal.fire('Failed!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Could not test connection.', 'error');
        }
    });
}
</script>
@endpush
