@extends('layouts.admin')

@section('title', 'MikroTik Devices')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
<li class="breadcrumb-item">Network</li>
<li class="breadcrumb-item active">MikroTik Devices</li>
@endsection

@section('content')
<style>
@media (min-width: 992px) { .mobile-device-cards { display: none !important; } }
@media (max-width: 991px) { .desktop-device-table { display: none !important; } .add-device-sidebar { display: none !important; } }
</style>

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-server mr-2"></i>MikroTik Devices</h3>
                <div class="card-tools">
                    <a href="{{ route('admin.network.diagram') }}" class="btn btn-sm btn-info mr-1">
                        <i class="fas fa-project-diagram"></i> <span class="d-none d-md-inline">Diagram</span>
                    </a>
                    <a href="{{ route('admin.olt.index') }}" class="btn btn-sm btn-success">
                        <i class="fas fa-network-wired"></i> <span class="d-none d-md-inline">OLT</span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Mobile Card View -->
                <div class="mobile-device-cards">
                    <div class="device-card-grid">
                        @forelse($devices as $device)
                        <div class="device-card">
                            <div class="device-card-header {{ $device->status == 'online' ? 'online' : 'offline' }}">
                                <div class="device-name">
                                    {{ $device->name }}
                                    @if($device->model)
                                    <br><small style="opacity:0.8">{{ $device->model }}</small>
                                    @endif
                                </div>
                                <span class="device-status">{{ ucfirst($device->status ?? 'Unknown') }}</span>
                            </div>
                            <div class="device-card-body">
                                <div class="device-info-row">
                                    <span class="device-info-label"><i class="fas fa-globe mr-1"></i>Host</span>
                                    <span class="device-info-value"><code>{{ $device->host }}:{{ $device->port }}</code></span>
                                </div>
                                <div class="device-info-row">
                                    <span class="device-info-label"><i class="fas fa-map-marker-alt mr-1"></i>Zone</span>
                                    <span class="device-info-value">{{ $device->zone->name ?? 'N/A' }}</span>
                                </div>
                                <div class="device-info-row">
                                    <span class="device-info-label"><i class="fas fa-toggle-on mr-1"></i>Status</span>
                                    <span class="device-info-value">
                                        <span class="badge badge-{{ $device->is_active ? 'success' : 'danger' }}">
                                            {{ $device->is_active ? 'Active' : 'Inactive' }}
                                        </span>
                                    </span>
                                </div>
                                @if($device->last_checked_at)
                                <div class="device-info-row">
                                    <span class="device-info-label"><i class="fas fa-clock mr-1"></i>Checked</span>
                                    <span class="device-info-value">{{ $device->last_checked_at->diffForHumans() }}</span>
                                </div>
                                @endif
                            </div>
                            <div class="device-card-footer">
                                <button type="button" class="btn btn-info btn-sm" onclick="testConnection({{ $device->id }})">
                                    <i class="fas fa-plug mr-1"></i>Test
                                </button>
                                <a href="{{ route('admin.network.devices.edit', $device) }}" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit mr-1"></i>Edit
                                </a>
                                <form action="{{ route('admin.network.devices.destroy', $device) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this device?')">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </div>
                        @empty
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-server fa-3x mb-3"></i>
                            <p>No MikroTik devices configured yet.</p>
                        </div>
                        @endforelse
                    </div>
                </div>

                <!-- Desktop Table View -->
                <div class="desktop-device-table">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover mb-0">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Name</th>
                                    <th>Host</th>
                                    <th>Port</th>
                                    <th>Zone</th>
                                    <th>Status</th>
                                    <th>Connection</th>
                                    <th width="150">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($devices as $device)
                                <tr>
                                    <td>
                                        <strong>{{ $device->name }}</strong>
                                        @if($device->model)
                                        <br><small class="text-muted">{{ $device->model }}</small>
                                        @endif
                                    </td>
                                    <td><code>{{ $device->host }}</code></td>
                                    <td>{{ $device->port }}</td>
                                    <td>{{ $device->zone->name ?? 'N/A' }}</td>
                                    <td>
                                        <span class="badge badge-{{ $device->is_active ? 'success' : 'danger' }}">
                                            {{ $device->is_active ? 'Active' : 'Inactive' }}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-{{ $device->status == 'online' ? 'success' : ($device->status == 'warning' ? 'warning' : 'secondary') }}" id="status-{{ $device->id }}">
                                            {{ ucfirst($device->status ?? 'Unknown') }}
                                        </span>
                                        @if($device->last_checked_at)
                                        <br><small class="text-muted">{{ $device->last_checked_at->diffForHumans() }}</small>
                                        @endif
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-info btn-sm" onclick="testConnection({{ $device->id }})" title="Test Connection">
                                                <i class="fas fa-plug"></i>
                                            </button>
                                            <a href="{{ route('admin.network.devices.edit', $device) }}" class="btn btn-warning btn-sm" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="{{ route('admin.network.devices.destroy', $device) }}" method="POST" style="display:inline" onsubmit="return confirm('Are you sure you want to delete this device?')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <i class="fas fa-server fa-3x text-muted mb-3"></i>
                                        <p class="text-muted">No MikroTik devices configured yet.</p>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @if($devices->hasPages())
            <div class="card-footer">
                {{ $devices->links() }}
            </div>
            @endif
        </div>
    </div>
    <div class="col-lg-4 add-device-sidebar">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-plus-circle mr-2"></i>Add MikroTik Device</h3>
            </div>
            <form action="{{ route('admin.network.devices.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label>Device Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., Main Router">
                    </div>
                    <div class="form-group">
                        <label>Host/IP Address <span class="text-danger">*</span></label>
                        <input type="text" name="host" class="form-control" required placeholder="192.168.1.1">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>API Port</label>
                                <input type="number" name="port" class="form-control" value="8728">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Zone</label>
                                <select name="zone_id" class="form-control">
                                    <option value="">Select Zone</option>
                                    @foreach($zones as $zone)
                                    <option value="{{ $zone->id }}">{{ $zone->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>API Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" class="form-control" required placeholder="admin">
                    </div>
                    <div class="form-group">
                        <label>API Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Optional notes..."></textarea>
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" value="1" checked>
                            <label class="custom-control-label" for="is_active">Active</label>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-save mr-2"></i>Add Device</button>
                </div>
            </form>
        </div>

        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-info-circle mr-2"></i>Quick Help</h3>
            </div>
            <div class="card-body">
                <p class="text-sm"><strong>API Port:</strong> Default is 8728 for non-SSL, 8729 for SSL.</p>
                <p class="text-sm"><strong>Username:</strong> Create a dedicated API user in MikroTik with read/write permissions.</p>
                <p class="text-sm mb-0"><strong>Test:</strong> Use the plug icon to test device connectivity.</p>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function testConnection(deviceId) {
    Swal.fire({
        title: 'Testing Connection...',
        text: 'Please wait while we connect to the device',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });
    
    $.ajax({
        url: '/admin/network/devices/' + deviceId + '/test',
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        success: function(response) {
            if (response.success) {
                $('#status-' + deviceId).removeClass('badge-secondary badge-warning').addClass('badge-success').text('Online');
                Swal.fire('Success!', response.message, 'success');
            } else {
                $('#status-' + deviceId).removeClass('badge-success badge-warning').addClass('badge-secondary').text('Offline');
                Swal.fire('Failed!', response.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error!', 'Could not test connection.', 'error');
        }
    });
}
</script>
@endpush
