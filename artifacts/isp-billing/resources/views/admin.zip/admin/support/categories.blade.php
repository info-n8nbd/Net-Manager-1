@extends('layouts.admin')

@section('title', 'Ticket Categories')
@section('breadcrumb')
<li class="breadcrumb-item active">Categories</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Ticket Categories</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Name</th><th>Description</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($categories as $cat)
                        <tr>
                            <td>{{ $cat->name }}</td>
                            <td>{{ $cat->description ?? '-' }}</td>
                            <td><span class="badge badge-{{ $cat->is_active ? 'success' : 'danger' }}">{{ $cat->is_active ? 'Active' : 'Inactive' }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="3" class="text-center">No categories</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Category</h3></div>
            <form action="{{ route('admin.support.categories.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Category</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
