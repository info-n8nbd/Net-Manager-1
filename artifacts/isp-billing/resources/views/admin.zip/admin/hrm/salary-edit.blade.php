@extends('layouts.admin')

@section('title', 'Edit Salary')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.hrm.salary') }}">Salary</a></li>
<li class="breadcrumb-item active">Edit Salary</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-edit mr-2"></i>Edit Salary Record</h3>
            </div>
            <form action="{{ route('admin.hrm.salary.update', $salary) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="card-body">
                    <div class="alert alert-info">
                        <strong>Employee:</strong> {{ $salary->employee->name ?? 'N/A' }}<br>
                        <strong>Period:</strong> {{ $salary->month }}/{{ $salary->year }}<br>
                        <strong>Working Days:</strong> {{ $salary->working_days }}
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Basic Salary (৳) <span class="text-danger">*</span></label>
                                <input type="number" name="basic_salary" class="form-control" value="{{ $salary->basic_salary }}" step="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Net Salary (৳) <span class="text-danger">*</span></label>
                                <input type="number" name="net_salary" class="form-control" value="{{ $salary->net_salary }}" step="0.01" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Allowances (৳)</label>
                                <input type="number" name="allowances" class="form-control" value="{{ $salary->allowances ?? 0 }}" step="0.01">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Deductions (৳)</label>
                                <input type="number" name="deductions" class="form-control" value="{{ $salary->deductions ?? 0 }}" step="0.01">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Bonus (৳)</label>
                                <input type="number" name="bonus" class="form-control" value="{{ $salary->bonus ?? 0 }}" step="0.01">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-control" required>
                            <option value="pending" {{ $salary->status == 'pending' ? 'selected' : '' }}>Pending</option>
                            <option value="partial" {{ $salary->status == 'partial' ? 'selected' : '' }}>Partial</option>
                            <option value="paid" {{ $salary->status == 'paid' ? 'selected' : '' }}>Paid</option>
                        </select>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i>Update Salary</button>
                    <a href="{{ route('admin.hrm.salary') }}" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-danger">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-trash mr-2"></i>Delete Salary</h3>
            </div>
            <div class="card-body">
                <p class="text-muted">Permanently delete this salary record.</p>
                <form action="{{ route('admin.hrm.salary.destroy', $salary) }}" method="POST" onsubmit="return confirm('Delete this salary record?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-block">
                        <i class="fas fa-trash mr-1"></i>Delete Salary
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
