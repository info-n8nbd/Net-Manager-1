@extends('layouts.admin')

@section('title', 'Edit Technician')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.hrm.technicians') }}">Technicians</a></li>
<li class="breadcrumb-item active">Edit</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user-edit mr-2"></i>Edit Technician: {{ $technician->name }}</h3>
            </div>
            <form action="{{ route('admin.hrm.technicians.update', $technician) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" 
                                       value="{{ old('name', $technician->name) }}" required>
                                @error('name')<span class="invalid-feedback">{{ $message }}</span>@enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" 
                                       value="{{ old('email', $technician->email) }}" required>
                                @error('email')<span class="invalid-feedback">{{ $message }}</span>@enderror
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Phone <span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" 
                                       value="{{ old('phone', $technician->phone) }}" required>
                                @error('phone')<span class="invalid-feedback">{{ $message }}</span>@enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>New Password <small class="text-muted">(Leave blank to keep current)</small></label>
                                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror">
                                @error('password')<span class="invalid-feedback">{{ $message }}</span>@enderror
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Assigned Zones <span class="text-danger">*</span></label>
                        <select name="zone_ids[]" class="form-control select2 @error('zone_ids') is-invalid @enderror" multiple required>
                            @php
                                $assignedZones = $technician->employee?->zone_ids ?? [];
                            @endphp
                            @foreach($zones as $zone)
                            <option value="{{ $zone->id }}" {{ in_array($zone->id, old('zone_ids', $assignedZones)) ? 'selected' : '' }}>
                                {{ $zone->name }}
                            </option>
                            @endforeach
                        </select>
                        <small class="text-muted">Select zones this technician can access</small>
                        @error('zone_ids')<span class="invalid-feedback">{{ $message }}</span>@enderror
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Department</label>
                                <select name="department_id" class="form-control">
                                    <option value="">Select Department</option>
                                    @foreach($departments as $dept)
                                    <option value="{{ $dept->id }}" {{ old('department_id', $technician->employee?->department_id) == $dept->id ? 'selected' : '' }}>
                                        {{ $dept->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Basic Salary (৳)</label>
                                <input type="number" name="basic_salary" class="form-control" 
                                       value="{{ old('basic_salary', $technician->employee?->basic_salary ?? 0) }}" step="0.01">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2">{{ old('address', $technician->employee?->address) }}</textarea>
                    </div>
                    
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" 
                               {{ old('is_active', $technician->is_active) ? 'checked' : '' }}>
                        <label class="custom-control-label" for="is_active">Active Account</label>
                    </div>
                </div>
                
                <div class="card-header bg-warning">
                    <h3 class="card-title"><i class="fas fa-shield-alt mr-2"></i>Access Control Permissions</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted mb-3">Select which features this technician can access:</p>
                    
                    @php
                        $techPermissions = [
                            'technician.dashboard' => ['label' => 'Dashboard', 'icon' => 'fa-tachometer-alt', 'desc' => 'View dashboard statistics'],
                            'technician.clients' => ['label' => 'My Clients', 'icon' => 'fa-users', 'desc' => 'View and manage assigned clients'],
                            'technician.due_report' => ['label' => 'Due Report', 'icon' => 'fa-exclamation-triangle', 'desc' => 'View client dues and collect payments'],
                            'technician.collection' => ['label' => 'My Collection', 'icon' => 'fa-money-bill-wave', 'desc' => 'View collection history'],
                            'technician.tickets' => ['label' => 'Assigned Tickets', 'icon' => 'fa-ticket-alt', 'desc' => 'View and resolve support tickets'],
                            'technician.new_connection' => ['label' => 'New Connections', 'icon' => 'fa-plus-circle', 'desc' => 'Submit new connection applications'],
                            'technician.package_requests' => ['label' => 'Package Requests', 'icon' => 'fa-box', 'desc' => 'View client package change requests'],
                        ];
                        $userPermissions = $technician->permissions->pluck('name')->toArray();
                    @endphp
                    
                    <div class="row">
                        @foreach($techPermissions as $permName => $perm)
                        <div class="col-md-6 mb-3">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="perm_{{ $permName }}" 
                                       name="permissions[]" value="{{ $permName }}"
                                       {{ in_array($permName, old('permissions', $userPermissions)) ? 'checked' : '' }}>
                                <label class="custom-control-label" for="perm_{{ $permName }}">
                                    <i class="fas {{ $perm['icon'] }} mr-1 text-primary"></i> {{ $perm['label'] }}
                                </label>
                                <br><small class="text-muted ml-4">{{ $perm['desc'] }}</small>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    
                    <div class="mt-3">
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="selectAllPerms()">
                            <i class="fas fa-check-double mr-1"></i>Select All
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="deselectAllPerms()">
                            <i class="fas fa-times mr-1"></i>Deselect All
                        </button>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save mr-2"></i>Update Technician
                    </button>
                    <a href="{{ route('admin.hrm.technicians') }}" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-info">
                <h3 class="card-title"><i class="fas fa-info-circle mr-2"></i>Account Info</h3>
            </div>
            <div class="card-body">
                <dl>
                    <dt>Created</dt>
                    <dd>{{ $technician->created_at->format('M d, Y h:i A') }}</dd>
                    
                    <dt>Last Updated</dt>
                    <dd>{{ $technician->updated_at->format('M d, Y h:i A') }}</dd>
                    
                    @if($technician->employee)
                    <dt>Employee ID</dt>
                    <dd>{{ $technician->employee->employee_id }}</dd>
                    
                    <dt>Joining Date</dt>
                    <dd>{{ $technician->employee->joining_date?->format('M d, Y') ?? 'N/A' }}</dd>
                    @endif
                </dl>
            </div>
        </div>
        
        <div class="card card-danger">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-exclamation-triangle mr-2"></i>Danger Zone</h3>
            </div>
            <div class="card-body">
                <p>Deleting this technician will permanently remove their account and all associated data.</p>
                <form action="{{ route('admin.hrm.technicians.destroy', $technician) }}" method="POST" 
                      onsubmit="return confirm('Are you sure you want to delete this technician? This action cannot be undone.')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-block">
                        <i class="fas fa-trash mr-2"></i>Delete Technician
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css">
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(function() {
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Select zones'
    });
});

function selectAllPerms() {
    $('input[name="permissions[]"]').prop('checked', true);
}

function deselectAllPerms() {
    $('input[name="permissions[]"]').prop('checked', false);
}
</script>
@endpush
