@extends('layouts.admin')

@section('title', 'Attendance')
@section('breadcrumb')
<li class="breadcrumb-item active">Attendance</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daily Attendance - {{ \Carbon\Carbon::parse($date)->format('d M Y') }}</h3>
        <div class="card-tools">
            <form method="GET" class="form-inline">
                <input type="date" name="date" class="form-control form-control-sm mr-2" value="{{ $date }}">
                <button type="submit" class="btn btn-info btn-sm">Load</button>
            </form>
        </div>
    </div>
    <form action="{{ route('admin.hrm.attendance.store') }}" method="POST">
        @csrf
        <input type="hidden" name="attendance_date" value="{{ $date }}">
        <div class="card-body">
            <table class="table table-bordered">
                <thead><tr><th>Employee</th><th>Status</th><th>Check In</th><th>Check Out</th></tr></thead>
                <tbody>
                    @foreach($employees as $emp)
                    @php $att = $attendances[$emp->id] ?? null; @endphp
                    <tr>
                        <td>{{ $emp->name }}</td>
                        <td>
                            <select name="attendance[{{ $emp->id }}]" class="form-control form-control-sm">
                                <option value="present" {{ $att?->status == 'present' ? 'selected' : '' }}>Present</option>
                                <option value="absent" {{ $att?->status == 'absent' ? 'selected' : '' }}>Absent</option>
                                <option value="late" {{ $att?->status == 'late' ? 'selected' : '' }}>Late</option>
                                <option value="leave" {{ $att?->status == 'leave' ? 'selected' : '' }}>Leave</option>
                            </select>
                        </td>
                        <td><input type="time" name="check_in[{{ $emp->id }}]" class="form-control form-control-sm" value="{{ $att?->check_in }}"></td>
                        <td><input type="time" name="check_out[{{ $emp->id }}]" class="form-control form-control-sm" value="{{ $att?->check_out }}"></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="card-footer"><button type="submit" class="btn btn-primary">Save Attendance</button></div>
    </form>
</div>
@endsection
