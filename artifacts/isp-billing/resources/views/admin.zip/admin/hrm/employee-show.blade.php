@extends('layouts.admin')

@section('title', 'Employee Details')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.hrm.employees') }}">HRM</a></li>
<li class="breadcrumb-item active">{{ $employee->name }}</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <div class="text-center">
                    <img class="profile-user-img img-fluid img-circle" src="https://ui-avatars.com/api/?name={{ urlencode($employee->name) }}&background=1e3a5f&color=fff&size=128" alt="Employee">
                </div>
                <h3 class="profile-username text-center">{{ $employee->name }}</h3>
                <p class="text-muted text-center">{{ $employee->designation->name ?? 'Staff' }}</p>

                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item">
                        <b>Employee ID</b> <a class="float-right">{{ $employee->employee_id ?? 'N/A' }}</a>
                    </li>
                    <li class="list-group-item">
                        <b>Department</b> <a class="float-right">{{ $employee->department->name ?? 'N/A' }}</a>
                    </li>
                    <li class="list-group-item">
                        <b>Joining Date</b> <a class="float-right">{{ $employee->joining_date?->format('d M Y') ?? 'N/A' }}</a>
                    </li>
                    <li class="list-group-item">
                        <b>Basic Salary</b> <a class="float-right">৳{{ number_format($employee->basic_salary, 0) }}</a>
                    </li>
                    <li class="list-group-item">
                        <b>Status</b> 
                        <span class="badge badge-{{ $employee->status === 'active' ? 'success' : 'danger' }} float-right">
                            {{ ucfirst($employee->status) }}
                        </span>
                    </li>
                </ul>

                <a href="{{ route('admin.hrm.employees.cv', $employee) }}" class="btn btn-primary btn-block">
                    <i class="fas fa-file-pdf mr-1"></i>Download CV
                </a>
            </div>
        </div>
        
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-phone mr-2"></i>Contact Info</h3>
            </div>
            <div class="card-body">
                <strong><i class="fas fa-phone mr-1"></i> Phone</strong>
                <p class="text-muted">{{ $employee->phone }}</p>
                <hr>
                <strong><i class="fas fa-envelope mr-1"></i> Email</strong>
                <p class="text-muted">{{ $employee->email ?? 'Not provided' }}</p>
                <hr>
                <strong><i class="fas fa-map-marker-alt mr-1"></i> Address</strong>
                <p class="text-muted">{{ $employee->address ?? 'Not provided' }}</p>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header p-2">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#attendance" data-toggle="tab">Attendance</a></li>
                    <li class="nav-item"><a class="nav-link" href="#salary" data-toggle="tab">Salary History</a></li>
                    <li class="nav-item"><a class="nav-link" href="#documents" data-toggle="tab">Documents</a></li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="active tab-pane" id="attendance">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Check In</th>
                                    <th>Check Out</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($employee->attendances ?? [] as $att)
                                <tr>
                                    <td>{{ $att->attendance_date->format('d M Y') }}</td>
                                    <td>{{ $att->check_in ?? '-' }}</td>
                                    <td>{{ $att->check_out ?? '-' }}</td>
                                    <td>
                                        <span class="badge badge-{{ $att->status === 'present' ? 'success' : ($att->status === 'absent' ? 'danger' : 'warning') }}">
                                            {{ ucfirst($att->status) }}
                                        </span>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="4" class="text-center text-muted">No attendance records</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="tab-pane" id="salary">
                        <p class="text-muted text-center">Salary history will be displayed here</p>
                    </div>
                    
                    <div class="tab-pane" id="documents">
                        <p class="text-muted text-center">Employee documents will be displayed here</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
