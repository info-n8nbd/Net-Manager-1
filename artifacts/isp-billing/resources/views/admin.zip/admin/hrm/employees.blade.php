@extends('layouts.admin')

@section('title', 'Employees')
@section('breadcrumb')
<li class="breadcrumb-item active">Employees</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Employees</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Name</th><th>Phone</th><th>Department</th><th>Designation</th><th>Salary (৳)</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($employees as $emp)
                        <tr>
                            <td>{{ $emp->name }}</td>
                            <td>{{ $emp->phone }}</td>
                            <td>{{ $emp->department->name ?? 'N/A' }}</td>
                            <td>{{ $emp->designation->name ?? 'N/A' }}</td>
                            <td>{{ number_format($emp->basic_salary, 2) }}</td>
                            <td><span class="badge badge-{{ $emp->status == 'active' ? 'success' : 'danger' }}">{{ ucfirst($emp->status) }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="6" class="text-center">No employees</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $employees->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Employee</h3></div>
            <form action="{{ route('admin.hrm.employees.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name *</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Phone *</label><input type="text" name="phone" class="form-control" required></div>
                    <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control"></div>
                    <div class="form-group"><label>Department</label>
                        <select name="department_id" class="form-control">
                            <option value="">Select</option>
                            @foreach($departments as $dept)
                            <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Designation</label>
                        <select name="designation_id" class="form-control">
                            <option value="">Select</option>
                            @foreach($designations as $des)
                            <option value="{{ $des->id }}">{{ $des->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Joining Date *</label><input type="date" name="joining_date" class="form-control" required></div>
                    <div class="form-group"><label>Basic Salary (৳) *</label><input type="number" name="basic_salary" class="form-control" required step="0.01"></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Employee</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
