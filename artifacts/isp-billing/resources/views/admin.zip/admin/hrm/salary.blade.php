@extends('layouts.admin')

@section('title', 'Salary')
@section('breadcrumb')
<li class="breadcrumb-item active">Salary</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Salary - {{ date('F Y', mktime(0,0,0,$month,1,$year)) }}</h3>
        <div class="card-tools">
            <form method="GET" class="form-inline">
                <select name="month" class="form-control form-control-sm mr-2">
                    @for($i = 1; $i <= 12; $i++)
                    <option value="{{ $i }}" {{ $i == $month ? 'selected' : '' }}>{{ date('F', mktime(0,0,0,$i,1)) }}</option>
                    @endfor
                </select>
                <select name="year" class="form-control form-control-sm mr-2">
                    @for($y = date('Y')-2; $y <= date('Y'); $y++)
                    <option value="{{ $y }}" {{ $y == $year ? 'selected' : '' }}>{{ $y }}</option>
                    @endfor
                </select>
                <button type="submit" class="btn btn-info btn-sm">Filter</button>
            </form>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead><tr><th>Employee</th><th>Basic (৳)</th><th>Bonus (৳)</th><th>Deduction (৳)</th><th>Net (৳)</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($salaries as $salary)
                <tr>
                    <td>{{ $salary->employee->name ?? 'N/A' }}</td>
                    <td>{{ number_format($salary->basic_salary, 2) }}</td>
                    <td>{{ number_format($salary->bonus, 2) }}</td>
                    <td>{{ number_format($salary->deductions, 2) }}</td>
                    <td>{{ number_format($salary->net_salary, 2) }}</td>
                    <td><span class="badge badge-{{ $salary->status == 'paid' ? 'success' : 'warning' }}">{{ ucfirst($salary->status) }}</span></td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">No salary records for this month</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $salaries->links() }}
    </div>
</div>
@endsection
