@extends('layouts.admin')

@section('title', 'Technicians')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.hrm.employees') }}">HRM</a></li>
<li class="breadcrumb-item active">Technicians</li>
@endsection

@section('content')
<div class="row mb-3">
    <div class="col-6 col-md-3 mb-2">
        <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
            <div class="stat-number">{{ $technicians->total() }}</div>
            <div class="stat-label">Technicians</div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
            <div class="stat-number">{{ $technicians->where('is_active', true)->count() }}</div>
            <div class="stat-label">Active</div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <div class="stat-box bg-warning text-dark text-center py-3 rounded h-100">
            <div class="stat-number">{{ $zones->count() }}</div>
            <div class="stat-label">Zones</div>
        </div>
    </div>
    <div class="col-6 col-md-3 mb-2">
        <a href="{{ route('admin.hrm.technicians.performance') }}" class="text-decoration-none">
            <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
                <div class="stat-number"><i class="fas fa-chart-line"></i></div>
                <div class="stat-label">Performance</div>
            </div>
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-users-cog mr-2"></i>Technician Accounts</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Assigned Zones</th>
                            <th>Status</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($technicians as $tech)
                        <tr>
                            <td>
                                <a href="{{ route('admin.hrm.technicians.show', $tech) }}">
                                    <strong>{{ $tech->name }}</strong>
                                </a>
                            </td>
                            <td>{{ $tech->email }}</td>
                            <td>{{ $tech->phone }}</td>
                            <td>
                                @if($tech->employee && $tech->employee->zone_ids)
                                    @php
                                        $zoneNames = $zones->whereIn('id', $tech->employee->zone_ids)->pluck('name');
                                    @endphp
                                    @foreach($zoneNames as $zoneName)
                                        <span class="badge badge-info">{{ $zoneName }}</span>
                                    @endforeach
                                @else
                                    <span class="text-muted">No zones assigned</span>
                                @endif
                            </td>
                            <td>
                                <span class="badge badge-{{ $tech->is_active ? 'success' : 'danger' }}">
                                    {{ $tech->is_active ? 'Active' : 'Inactive' }}
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="{{ route('admin.hrm.technicians.show', $tech) }}" class="btn btn-sm btn-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('admin.hrm.technicians.edit', $tech) }}" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('admin.hrm.technicians.destroy', $tech) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this technician?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                <i class="fas fa-users-cog fa-3x mb-3 d-block"></i>
                                No technicians found. Add your first technician using the form.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                {{ $technicians->links() }}
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user-plus mr-2"></i>Add New Technician</h3>
            </div>
            <form action="{{ route('admin.hrm.technicians.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label>Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required>
                        @error('name')
                        <span class="invalid-feedback">{{ $message }}</span>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label>Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required>
                        @error('email')
                        <span class="invalid-feedback">{{ $message }}</span>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label>Phone <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone') }}" required>
                        @error('phone')
                        <span class="invalid-feedback">{{ $message }}</span>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label>Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" required>
                        @error('password')
                        <span class="invalid-feedback">{{ $message }}</span>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label>Assigned Zones <span class="text-danger">*</span></label>
                        <select name="zone_ids[]" class="form-control select2 @error('zone_ids') is-invalid @enderror" multiple required>
                            @foreach($zones as $zone)
                            <option value="{{ $zone->id }}" {{ in_array($zone->id, old('zone_ids', [])) ? 'selected' : '' }}>
                                {{ $zone->name }}
                            </option>
                            @endforeach
                        </select>
                        <small class="text-muted">Select zones this technician can access</small>
                        @error('zone_ids')
                        <span class="invalid-feedback">{{ $message }}</span>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label>Department</label>
                        <select name="department_id" class="form-control">
                            <option value="">Select Department</option>
                            @foreach($departments as $dept)
                            <option value="{{ $dept->id }}" {{ old('department_id') == $dept->id ? 'selected' : '' }}>
                                {{ $dept->name }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Basic Salary (৳)</label>
                        <input type="number" name="basic_salary" class="form-control" value="{{ old('basic_salary', 0) }}" step="0.01">
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2">{{ old('address') }}</textarea>
                    </div>
                    
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" checked>
                        <label class="custom-control-label" for="is_active">Active Account</label>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-user-plus mr-2"></i>Create Technician Account
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css">
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(function() {
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Select zones'
    });
});
</script>
@endpush
