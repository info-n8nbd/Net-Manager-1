@extends('layouts.admin')

@section('title', 'Zones')
@section('breadcrumb')
<li class="breadcrumb-item active">Zones</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Zones & Areas</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Zone Name</th><th>Areas</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($zones as $zone)
                        <tr>
                            <td>{{ $zone->name }}</td>
                            <td>{{ $zone->areas->pluck('name')->join(', ') }}</td>
                            <td><span class="badge badge-{{ $zone->is_active ? 'success' : 'danger' }}">{{ $zone->is_active ? 'Active' : 'Inactive' }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="3" class="text-center">No zones</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $zones->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Zone</h3></div>
            <form action="{{ route('admin.settings.zones.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Zone Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Zone</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
