@extends('layouts.admin')

@section('title', 'Payment Methods')
@section('breadcrumb')
<li class="breadcrumb-item active">Payment Methods</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Payment Methods</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Name</th><th>Code</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($methods as $method)
                        <tr>
                            <td>{{ $method->name }}</td>
                            <td>{{ $method->code }}</td>
                            <td><span class="badge badge-{{ $method->is_active ? 'success' : 'danger' }}">{{ $method->is_active ? 'Active' : 'Inactive' }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="3" class="text-center">No payment methods</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Payment Method</h3></div>
            <form action="{{ route('admin.settings.payment-methods.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Code</label><input type="text" name="code" class="form-control" required></div>
                    <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Method</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
