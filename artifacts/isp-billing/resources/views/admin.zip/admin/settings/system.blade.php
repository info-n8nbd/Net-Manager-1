@extends('layouts.admin')

@section('title', 'System Settings')
@section('breadcrumb')
<li class="breadcrumb-item active">System Settings</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">System Settings</h3></div>
    <form action="{{ route('admin.settings.system.update') }}" method="POST">
        @csrf
        <div class="card-body">
            <h5 class="mb-3 text-primary"><i class="fas fa-cog mr-2"></i>Billing Settings</h5>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Auto Disable on Due (Days)</label>
                        <input type="number" name="auto_disable_days" class="form-control" value="{{ $settings['auto_disable_days'] ?? 7 }}">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Bill Generation Day</label>
                        <input type="number" name="bill_generation_day" class="form-control" value="{{ $settings['bill_generation_day'] ?? 1 }}" min="1" max="28">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Due Days After Bill</label>
                        <input type="number" name="due_days" class="form-control" value="{{ $settings['due_days'] ?? 15 }}">
                    </div>
                </div>
            </div>

            <hr>
            <h5 class="mb-3 text-primary"><i class="fas fa-sms mr-2"></i>SMS Settings</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>SMS Gateway</label>
                        <select name="sms_gateway" class="form-control">
                            <option value="none" {{ ($settings['sms_gateway'] ?? '') == 'none' ? 'selected' : '' }}>None</option>
                            <option value="bulksmsbd" {{ ($settings['sms_gateway'] ?? '') == 'bulksmsbd' ? 'selected' : '' }}>BulkSMSBD</option>
                            <option value="greenweb" {{ ($settings['sms_gateway'] ?? '') == 'greenweb' ? 'selected' : '' }}>Green Web</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>SMS API Key</label>
                        <input type="text" name="sms_api_key" class="form-control" value="{{ $settings['sms_api_key'] ?? '' }}">
                    </div>
                </div>
            </div>

            <hr>
            <h5 class="mb-3 text-primary"><i class="fab fa-telegram mr-2"></i>Telegram Ticket Bot (All Employees)</h5>
            <p class="text-muted small">This bot sends ticket notifications to a group where all employees can see new tickets.</p>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Ticket Bot Token</label>
                        <input type="text" name="telegram_ticket_bot_token" class="form-control" value="{{ $settings['telegram_ticket_bot_token'] ?? '' }}" placeholder="Enter bot token from @BotFather">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Ticket Group Chat ID</label>
                        <input type="text" name="telegram_ticket_group_id" class="form-control" value="{{ $settings['telegram_ticket_group_id'] ?? '' }}" placeholder="e.g., -1001234567890">
                    </div>
                </div>
            </div>

            <hr>
            <h5 class="mb-3 text-primary"><i class="fab fa-telegram mr-2"></i>Telegram Alert Bot (Admin/Employees)</h5>
            <p class="text-muted small">This bot sends client connect/disconnect alerts to admin and employees.</p>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Alert Bot Token</label>
                        <input type="text" name="telegram_alert_bot_token" class="form-control" value="{{ $settings['telegram_alert_bot_token'] ?? '' }}" placeholder="Enter bot token from @BotFather">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Alert Group Chat ID</label>
                        <input type="text" name="telegram_alert_group_id" class="form-control" value="{{ $settings['telegram_alert_group_id'] ?? '' }}" placeholder="e.g., -1001234567890">
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer"><button type="submit" class="btn btn-primary"><i class="fas fa-save mr-2"></i>Save Settings</button></div>
    </form>
</div>
@endsection
