@extends('layouts.admin')

@section('title', 'Packages')
@section('breadcrumb')
<li class="breadcrumb-item active">Packages</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Internet Packages</h3></div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr><th>Name</th><th>Code</th><th>Price (৳)</th><th>Bandwidth</th><th>Type</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        @forelse($packages as $package)
                        <tr>
                            <td>{{ $package->name }}</td>
                            <td>{{ $package->code }}</td>
                            <td>{{ number_format($package->price, 2) }}</td>
                            <td>{{ $package->bandwidth }}</td>
                            <td>{{ $package->connection_type }}</td>
                            <td><span class="badge badge-{{ $package->is_active ? 'success' : 'danger' }}">{{ $package->is_active ? 'Active' : 'Inactive' }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="6" class="text-center">No packages</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $packages->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Package</h3></div>
            <form action="{{ route('admin.settings.packages.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Code</label><input type="text" name="code" class="form-control" required></div>
                    <div class="form-group"><label>Price (৳)</label><input type="number" name="price" class="form-control" step="0.01" required></div>
                    <div class="form-group"><label>Download Speed</label><input type="number" name="download_speed" class="form-control" required></div>
                    <div class="form-group"><label>Upload Speed</label><input type="number" name="upload_speed" class="form-control" required></div>
                    <div class="form-group"><label>Type</label>
                        <select name="connection_type" class="form-control">
                            <option value="PPPoE">PPPoE</option>
                            <option value="Static IP">Static IP</option>
                            <option value="Hotspot">Hotspot</option>
                            <option value="DHCP">DHCP</option>
                        </select>
                    </div>
                    <div class="form-check"><input type="checkbox" name="is_active" class="form-check-input" checked><label class="form-check-label">Active</label></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Package</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
