@extends('layouts.admin')

@section('title', 'Company Profile')
@section('breadcrumb')
<li class="breadcrumb-item active">Company Profile</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Company Profile</h3></div>
    <form action="{{ route('admin.settings.company.update') }}" method="POST">
        @csrf
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group"><label>Company Name</label><input type="text" name="name" class="form-control" value="{{ $company->name }}"></div>
                    <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control" value="{{ $company->email }}"></div>
                    <div class="form-group"><label>Phone</label><input type="text" name="phone" class="form-control" value="{{ $company->phone }}"></div>
                    <div class="form-group"><label>Alt Phone</label><input type="text" name="alt_phone" class="form-control" value="{{ $company->alt_phone }}"></div>
                    <div class="form-group"><label>Website</label><input type="text" name="website" class="form-control" value="{{ $company->website }}"></div>
                </div>
                <div class="col-md-6">
                    <div class="form-group"><label>Address</label><textarea name="address" class="form-control" rows="3">{{ $company->address }}</textarea></div>
                    <div class="form-group"><label>BTRC License No</label><input type="text" name="btrc_license" class="form-control" value="{{ $company->btrc_license }}"></div>
                    <div class="form-group"><label>BIN No</label><input type="text" name="bin_no" class="form-control" value="{{ $company->bin_no }}"></div>
                    <div class="form-group"><label>Trade License</label><input type="text" name="trade_license" class="form-control" value="{{ $company->trade_license }}"></div>
                </div>
            </div>
            <div class="form-group"><label>Invoice Footer</label><textarea name="invoice_footer" class="form-control" rows="2">{{ $company->invoice_footer }}</textarea></div>
        </div>
        <div class="card-footer"><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
</div>
@endsection
