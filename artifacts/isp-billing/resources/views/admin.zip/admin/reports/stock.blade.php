@extends('layouts.admin')

@section('title', 'Stock Report')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="#">Reports</a></li>
<li class="breadcrumb-item active">Stock Report</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-boxes mr-2"></i>Stock Report</h3>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ collect($report)->sum('in_stock_count') }}</div>
                    <div class="stat-label">In Stock</div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ collect($report)->sum('assigned_count') }}</div>
                    <div class="stat-label">Assigned</div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-danger text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ collect($report)->sum('damaged_count') }}</div>
                    <div class="stat-label">Damaged</div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ count($report) }}</div>
                    <div class="stat-label">Products</div>
                </div>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th class="text-center">In Stock</th>
                        <th class="text-center">Assigned</th>
                        <th class="text-center">Damaged</th>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($report as $product)
                    <tr>
                        <td><strong>{{ $product['name'] }}</strong></td>
                        <td>{{ $product['category']['name'] ?? 'N/A' }}</td>
                        <td class="text-center">
                            <span class="badge badge-success">{{ $product['in_stock_count'] }}</span>
                        </td>
                        <td class="text-center">
                            <span class="badge badge-info">{{ $product['assigned_count'] }}</span>
                        </td>
                        <td class="text-center">
                            <span class="badge badge-danger">{{ $product['damaged_count'] }}</span>
                        </td>
                        <td class="text-center">
                            <strong>{{ $product['in_stock_count'] + $product['assigned_count'] + $product['damaged_count'] }}</strong>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No products found in inventory</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
