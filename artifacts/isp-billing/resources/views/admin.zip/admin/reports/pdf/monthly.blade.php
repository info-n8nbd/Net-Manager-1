<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Monthly Report</title>
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #1e3a5f; padding-bottom: 10px; }
        .header h1 { color: #1e3a5f; margin: 0; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #1e3a5f; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .total-row { background-color: #1e3a5f !important; color: white; font-weight: bold; }
        .text-right { text-align: right; }
        .summary { background: #f5f5f5; padding: 15px; margin-bottom: 20px; border-left: 4px solid #1e3a5f; }
        .footer { margin-top: 30px; text-align: center; color: #666; font-size: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ $companyName }}</h1>
        <p>Monthly Revenue Report</p>
        <p>Period: {{ $date }}</p>
    </div>

    <div class="summary">
        <strong>Total Revenue: {{ $currency }}{{ number_format($revenue, 2) }}</strong>
    </div>

    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th class="text-right">Collection ({{ $currency }})</th>
            </tr>
        </thead>
        <tbody>
            @foreach($dailyData as $row)
            <tr>
                <td>{{ $row->date }}</td>
                <td class="text-right">{{ number_format($row->total, 2) }}</td>
            </tr>
            @endforeach
            <tr class="total-row">
                <td>Total</td>
                <td class="text-right">{{ $currency }}{{ number_format($revenue, 2) }}</td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Generated on {{ now()->format('d M Y H:i:s') }} | Smart Online Billing</p>
    </div>
</body>
</html>
