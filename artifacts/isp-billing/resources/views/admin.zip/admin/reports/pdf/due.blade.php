<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Due Report</title>
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #c53030; padding-bottom: 10px; }
        .header h1 { color: #1e3a5f; margin: 0; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #c53030; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .total-row { background-color: #c53030 !important; color: white; font-weight: bold; }
        .text-right { text-align: right; }
        .footer { margin-top: 30px; text-align: center; color: #666; font-size: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ $companyName }}</h1>
        <p>Due Clients Report</p>
        <p>Generated: {{ $date }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Client ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Zone</th>
                <th>Package</th>
                <th class="text-right">Due Amount ({{ $currency }})</th>
            </tr>
        </thead>
        <tbody>
            @foreach($clients as $index => $client)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $client->client_id }}</td>
                <td>{{ $client->name }}</td>
                <td>{{ $client->phone }}</td>
                <td>{{ $client->zone->name ?? 'N/A' }}</td>
                <td>{{ $client->package->name ?? 'N/A' }}</td>
                <td class="text-right">{{ number_format($client->due_amount, 2) }}</td>
            </tr>
            @endforeach
            <tr class="total-row">
                <td colspan="6">Total Due</td>
                <td class="text-right">{{ $currency }}{{ number_format($totalDue, 2) }}</td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Generated on {{ now()->format('d M Y H:i:s') }} | Smart Online Billing</p>
    </div>
</body>
</html>
