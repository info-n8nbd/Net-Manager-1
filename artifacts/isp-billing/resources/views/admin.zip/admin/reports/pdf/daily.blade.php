<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daily Collection Report</title>
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #1e3a5f; padding-bottom: 10px; }
        .header h1 { color: #1e3a5f; margin: 0; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #1e3a5f; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .total-row { background-color: #1e3a5f !important; color: white; font-weight: bold; }
        .text-right { text-align: right; }
        .footer { margin-top: 30px; text-align: center; color: #666; font-size: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ $companyName }}</h1>
        <p>Daily Collection Report</p>
        <p>Date: {{ $date }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Client</th>
                <th>Bill No</th>
                <th>Payment Method</th>
                <th>Collected By</th>
                <th class="text-right">Amount ({{ $currency }})</th>
            </tr>
        </thead>
        <tbody>
            @foreach($payments as $index => $payment)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $payment->client->name ?? 'N/A' }}</td>
                <td>{{ $payment->bill->bill_number ?? 'N/A' }}</td>
                <td>{{ $payment->paymentMethod->name ?? 'Cash' }}</td>
                <td>{{ $payment->collectedBy->name ?? 'Admin' }}</td>
                <td class="text-right">{{ number_format($payment->amount, 2) }}</td>
            </tr>
            @endforeach
            <tr class="total-row">
                <td colspan="5">Total Collection</td>
                <td class="text-right">{{ $currency }}{{ number_format($totalCollection, 2) }}</td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Generated on {{ now()->format('d M Y H:i:s') }} | Smart Online Billing</p>
    </div>
</body>
</html>
