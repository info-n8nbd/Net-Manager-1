@extends('layouts.admin')

@section('title', 'Due Report')
@section('breadcrumb')
<li class="breadcrumb-item active">Due Report</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Due Report</h3></div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-6 col-md-4">
                <div class="stat-box bg-danger text-white text-center py-3 rounded">
                    <div class="stat-number">৳{{ number_format($totalDue, 0) }}</div>
                    <div class="stat-label">Total Due</div>
                </div>
            </div>
        </div>
        <table class="table table-bordered table-striped">
            <thead>
                <tr><th>Client ID</th><th>Name</th><th>Phone</th><th>Zone</th><th>Package</th><th>Due (৳)</th><th>Actions</th></tr>
            </thead>
            <tbody>
                @forelse($clients as $client)
                <tr>
                    <td>{{ $client->client_id }}</td>
                    <td>{{ $client->name }}</td>
                    <td>{{ $client->phone }}</td>
                    <td>{{ $client->zone->name ?? '-' }}</td>
                    <td>{{ $client->package->name ?? '-' }}</td>
                    <td class="text-danger font-weight-bold">{{ number_format($client->due_amount, 2) }}</td>
                    <td><a href="{{ route('admin.payments.create') }}?client_id={{ $client->id }}" class="btn btn-success btn-xs">Collect</a></td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center">No due amounts</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $clients->links() }}
    </div>
</div>
@endsection
