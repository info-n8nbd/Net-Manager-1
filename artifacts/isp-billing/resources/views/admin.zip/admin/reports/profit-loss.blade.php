@extends('layouts.admin')

@section('title', 'Profit & Loss Statement')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Profit & Loss Statement</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Reports</a></li>
                    <li class="breadcrumb-item active">P&L Statement</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Filter Period</h3>
            </div>
            <div class="card-body">
                <form method="GET" class="row">
                    <div class="col-md-3">
                        <label>Start Date</label>
                        <input type="date" name="start_date" class="form-control" 
                               value="{{ $startDate->format('Y-m-d') }}">
                    </div>
                    <div class="col-md-3">
                        <label>End Date</label>
                        <input type="date" name="end_date" class="form-control" 
                               value="{{ $endDate->format('Y-m-d') }}">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Generate Report
                        </button>
                    </div>
                    <div class="col-md-3 d-flex align-items-end justify-content-end">
                        <button type="button" class="btn btn-success" onclick="window.print()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title">Revenue / Income</h3>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>Subscription Revenue</td>
                                    <td class="text-right">৳{{ number_format($report['revenue']['subscription'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Connection Fees</td>
                                    <td class="text-right">৳{{ number_format($report['revenue']['connection'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Reconnection Fees</td>
                                    <td class="text-right">৳{{ number_format($report['revenue']['reconnection'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Equipment Sales</td>
                                    <td class="text-right">৳{{ number_format($report['revenue']['equipment'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Other Income</td>
                                    <td class="text-right">৳{{ number_format($report['revenue']['other'] ?? 0, 2) }}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="bg-success text-white font-weight-bold">
                                    <td>Total Revenue</td>
                                    <td class="text-right">৳{{ number_format($report['total_revenue'] ?? 0, 2) }}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-danger">
                    <div class="card-header">
                        <h3 class="card-title">Expenses</h3>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>Salary & Wages</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['salary'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Bandwidth Cost</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['bandwidth'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Equipment & Maintenance</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['equipment'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Utilities</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['utilities'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Office & Administrative</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['office'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Marketing</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['marketing'] ?? 0, 2) }}</td>
                                </tr>
                                <tr>
                                    <td>Other Expenses</td>
                                    <td class="text-right">৳{{ number_format($report['expenses']['other'] ?? 0, 2) }}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="bg-danger text-white font-weight-bold">
                                    <td>Total Expenses</td>
                                    <td class="text-right">৳{{ number_format($report['total_expenses'] ?? 0, 2) }}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card {{ ($report['net_profit'] ?? 0) >= 0 ? 'card-success' : 'card-danger' }}">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 text-center border-right">
                                <h5 class="text-muted">Total Revenue</h5>
                                <h2 class="text-success">৳{{ number_format($report['total_revenue'] ?? 0, 2) }}</h2>
                            </div>
                            <div class="col-md-4 text-center border-right">
                                <h5 class="text-muted">Total Expenses</h5>
                                <h2 class="text-danger">৳{{ number_format($report['total_expenses'] ?? 0, 2) }}</h2>
                            </div>
                            <div class="col-md-4 text-center">
                                <h5 class="text-muted">{{ ($report['net_profit'] ?? 0) >= 0 ? 'Net Profit' : 'Net Loss' }}</h5>
                                <h2 class="{{ ($report['net_profit'] ?? 0) >= 0 ? 'text-success' : 'text-danger' }}">
                                    ৳{{ number_format(abs($report['net_profit'] ?? 0), 2) }}
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center text-muted mt-3">
            <small>
                Report Period: {{ $startDate->format('d M Y') }} to {{ $endDate->format('d M Y') }} | 
                Generated: {{ now()->format('d M Y H:i') }}
            </small>
        </div>
    </div>
</section>
@endsection
