@extends('layouts.admin')

@section('title', 'Reseller Report')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="#">Reports</a></li>
<li class="breadcrumb-item active">Reseller Report</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-store mr-2"></i>Reseller Report</h3>
        <div class="card-tools">
            <form class="form-inline" method="GET">
                <select name="reseller_id" class="form-control form-control-sm mr-2">
                    <option value="">All Resellers</option>
                    @foreach($resellers as $reseller)
                    <option value="{{ $reseller->id }}" {{ request('reseller_id') == $reseller->id ? 'selected' : '' }}>
                        {{ $reseller->name }}
                    </option>
                    @endforeach
                </select>
                <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-filter"></i> Filter</button>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-4 mb-2">
                <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
                    <div class="stat-number">৳{{ number_format(collect($report)->sum('total_revenue'), 0) }}</div>
                    <div class="stat-label">Revenue</div>
                </div>
            </div>
            <div class="col-4 mb-2">
                <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ collect($report)->sum('client_count') }}</div>
                    <div class="stat-label">Clients</div>
                </div>
            </div>
            <div class="col-4 mb-2">
                <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
                    <div class="stat-number">৳{{ number_format(collect($report)->sum('wallet_balance'), 0) }}</div>
                    <div class="stat-label">Wallet</div>
                </div>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Reseller</th>
                        <th>Company</th>
                        <th class="text-center">Clients</th>
                        <th class="text-right">Wallet Balance (৳)</th>
                        <th class="text-right">Total Revenue (৳)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($report as $row)
                    <tr>
                        <td><strong>{{ $row['reseller'] }}</strong></td>
                        <td>{{ $row['company'] ?? 'N/A' }}</td>
                        <td class="text-center">
                            <span class="badge badge-info">{{ $row['client_count'] }}</span>
                        </td>
                        <td class="text-right">৳{{ number_format($row['wallet_balance'], 2) }}</td>
                        <td class="text-right text-success">
                            <strong>৳{{ number_format($row['total_revenue'], 2) }}</strong>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">No reseller data available</td>
                    </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr class="bg-light">
                        <th colspan="2">Total</th>
                        <th class="text-center">{{ collect($report)->sum('client_count') }}</th>
                        <th class="text-right">৳{{ number_format(collect($report)->sum('wallet_balance'), 2) }}</th>
                        <th class="text-right text-success">৳{{ number_format(collect($report)->sum('total_revenue'), 2) }}</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
@endsection
