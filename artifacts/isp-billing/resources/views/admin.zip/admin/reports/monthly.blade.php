@extends('layouts.admin')

@section('title', 'Monthly Revenue Report')
@section('breadcrumb')
<li class="breadcrumb-item active">Monthly Revenue</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Monthly Revenue - {{ date('F Y', mktime(0,0,0,$month,1,$year)) }}</h3>
        <div class="card-tools">
            <form method="GET" class="form-inline">
                <select name="month" class="form-control form-control-sm mr-2">
                    @for($i = 1; $i <= 12; $i++)
                    <option value="{{ $i }}" {{ $i == $month ? 'selected' : '' }}>{{ date('F', mktime(0,0,0,$i,1)) }}</option>
                    @endfor
                </select>
                <select name="year" class="form-control form-control-sm mr-2">
                    @for($y = date('Y')-2; $y <= date('Y'); $y++)
                    <option value="{{ $y }}" {{ $y == $year ? 'selected' : '' }}>{{ $y }}</option>
                    @endfor
                </select>
                <button type="submit" class="btn btn-info btn-sm">Filter</button>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-6 col-md-4">
                <div class="stat-box bg-success text-white text-center py-3 rounded">
                    <div class="stat-number">৳{{ number_format($revenue, 0) }}</div>
                    <div class="stat-label">Revenue</div>
                </div>
            </div>
        </div>
        <canvas id="dailyChart" height="100"></canvas>
    </div>
</div>
@endsection

@push('scripts')
<script>
new Chart(document.getElementById('dailyChart'), {
    type: 'bar',
    data: {
        labels: @json($dailyData->pluck('date')),
        datasets: [{
            label: 'Daily Collection (BDT)',
            data: @json($dailyData->pluck('total')),
            backgroundColor: '#28a745'
        }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
});
</script>
@endpush
