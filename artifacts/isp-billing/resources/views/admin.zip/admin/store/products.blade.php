@extends('layouts.admin')

@section('title', 'Products')
@section('breadcrumb')
<li class="breadcrumb-item active">Products</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Products</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Price (৳)</th><th>Stock</th></tr></thead>
                    <tbody>
                        @forelse($products as $product)
                        <tr class="{{ $product->stock_quantity <= $product->alert_quantity ? 'table-warning' : '' }}">
                            <td>{{ $product->code }}</td>
                            <td>{{ $product->name }}</td>
                            <td>{{ $product->category->name ?? 'N/A' }}</td>
                            <td>{{ number_format($product->selling_price, 2) }}</td>
                            <td>{{ $product->stock_quantity }} {{ $product->unit }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="5" class="text-center">No products</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $products->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Product</h3></div>
            <form action="{{ route('admin.store.products.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Code</label><input type="text" name="code" class="form-control" required></div>
                    <div class="form-group"><label>Category</label>
                        <select name="category_id" class="form-control">
                            <option value="">None</option>
                            @foreach($categories as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Purchase Price (৳)</label><input type="number" name="purchase_price" class="form-control" step="0.01" required></div>
                    <div class="form-group"><label>Selling Price (৳)</label><input type="number" name="selling_price" class="form-control" step="0.01" required></div>
                    <div class="form-group"><label>Unit</label><input type="text" name="unit" class="form-control" value="pcs"></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Product</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
