@extends('layouts.admin')

@section('title', 'Stock')
@section('breadcrumb')
<li class="breadcrumb-item active">Stock</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Current Stock</h3></div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead><tr><th>Product</th><th>Code</th><th>Unit</th><th>Stock Qty</th><th>Alert Qty</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($products as $product)
                <tr class="{{ $product->stock_quantity <= $product->alert_quantity ? 'table-danger' : '' }}">
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->code }}</td>
                    <td>{{ $product->unit }}</td>
                    <td>{{ $product->stock_quantity }}</td>
                    <td>{{ $product->alert_quantity }}</td>
                    <td>
                        @if($product->stock_quantity <= $product->alert_quantity)
                        <span class="badge badge-danger">Low Stock</span>
                        @else
                        <span class="badge badge-success">In Stock</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">No products</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $products->links() }}
    </div>
</div>
@endsection
