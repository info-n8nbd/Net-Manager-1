@extends('layouts.admin')

@section('title', 'Purchases')
@section('breadcrumb')
<li class="breadcrumb-item active">Purchases</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Purchase Orders</h3></div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead><tr><th>PO No</th><th>Vendor</th><th>Date</th><th>Total (৳)</th><th>Paid (৳)</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($purchases as $purchase)
                <tr>
                    <td>{{ $purchase->purchase_no }}</td>
                    <td>{{ $purchase->vendor->name ?? 'N/A' }}</td>
                    <td>{{ $purchase->purchase_date->format('d M Y') }}</td>
                    <td>{{ number_format($purchase->total, 2) }}</td>
                    <td>{{ number_format($purchase->paid, 2) }}</td>
                    <td><span class="badge badge-{{ $purchase->status == 'received' ? 'success' : 'warning' }}">{{ ucfirst($purchase->status) }}</span></td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">No purchases</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $purchases->links() }}
    </div>
</div>
@endsection
