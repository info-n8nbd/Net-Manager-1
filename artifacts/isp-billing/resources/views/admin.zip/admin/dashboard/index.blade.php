@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')
<div class="row mb-3">
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.clients.index') }}" class="text-decoration-none">
            <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
                <div class="stat-number">{{ $totalClients ?? 0 }}</div>
                <div class="stat-label">Clients</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.clients.index') }}?status=active" class="text-decoration-none">
            <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
                <div class="stat-number">{{ $activeClients ?? 0 }}</div>
                <div class="stat-label">Active</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.billing.due') }}" class="text-decoration-none">
            <div class="stat-box bg-warning text-dark text-center py-3 rounded h-100">
                <div class="stat-number">৳{{ number_format($totalDue ?? 0, 0) }}</div>
                <div class="stat-label">Due</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.support.tickets') }}" class="text-decoration-none">
            <div class="stat-box bg-danger text-white text-center py-3 rounded h-100">
                <div class="stat-number">{{ $openTickets ?? 0 }}</div>
                <div class="stat-label">Tickets</div>
            </div>
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Monthly Revenue ({{ date('Y') }})</h3>
                </div>
            </div>
            <div class="card-body">
                <canvas id="revenueChart" height="150"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Client Status</h3>
            </div>
            <div class="card-body">
                <canvas id="clientStatusChart" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Today's Collection</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Amount</th>
                            <th>Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($todayPayments ?? [] as $payment)
                        <tr>
                            <td>{{ $payment->client->name ?? 'N/A' }}</td>
                            <td>৳{{ number_format($payment->amount, 2) }}</td>
                            <td>{{ $payment->paymentMethod->name ?? 'Cash' }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" class="text-center">No payments today</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Recent Tickets</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Ticket</th>
                            <th>Client</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentTickets ?? [] as $ticket)
                        <tr>
                            <td>{{ $ticket->ticket_no }}</td>
                            <td>{{ $ticket->client->name ?? 'N/A' }}</td>
                            <td><span class="badge badge-{{ $ticket->status == 'open' ? 'warning' : ($ticket->status == 'resolved' ? 'success' : 'info') }}">{{ ucfirst($ticket->status) }}</span></td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" class="text-center">No recent tickets</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    var revenueData = @json($monthlyRevenue ?? [0,0,0,0,0,0,0,0,0,0,0,0]);
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue (BDT)',
                data: revenueData,
                borderColor: '#007bff',
                backgroundColor: 'rgba(0,123,255,0.1)',
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } }
        }
    });

    new Chart(document.getElementById('clientStatusChart'), {
        type: 'doughnut',
        data: {
            labels: ['Active', 'Inactive', 'Suspended', 'Pending'],
            datasets: [{
                data: [{{ $activeClients ?? 0 }}, {{ $inactiveClients ?? 0 }}, {{ $suspendedClients ?? 0 }}, {{ $pendingClients ?? 0 }}],
                backgroundColor: ['#28a745', '#6c757d', '#dc3545', '#ffc107']
            }]
        },
        options: { responsive: true }
    });
});
</script>
@endpush
