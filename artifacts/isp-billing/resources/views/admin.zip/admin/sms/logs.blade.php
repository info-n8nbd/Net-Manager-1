@extends('layouts.admin')

@section('title', 'SMS Logs')
@section('breadcrumb')
<li class="breadcrumb-item active">SMS Logs</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">SMS Logs</h3></div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead><tr><th>Phone</th><th>Client</th><th>Message</th><th>Status</th><th>Sent By</th><th>Date</th></tr></thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td>{{ $log->phone }}</td>
                    <td>{{ $log->client->name ?? 'N/A' }}</td>
                    <td>{{ Str::limit($log->message, 40) }}</td>
                    <td><span class="badge badge-{{ $log->status == 'sent' ? 'success' : ($log->status == 'pending' ? 'warning' : 'danger') }}">{{ ucfirst($log->status) }}</span></td>
                    <td>{{ $log->sentBy->name ?? 'N/A' }}</td>
                    <td>{{ $log->created_at->format('d M Y H:i') }}</td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">No SMS logs</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $logs->links() }}
    </div>
</div>
@endsection
