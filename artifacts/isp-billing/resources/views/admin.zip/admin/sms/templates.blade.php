@extends('layouts.admin')

@section('title', 'SMS Templates')
@section('breadcrumb')
<li class="breadcrumb-item active">SMS Templates</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">SMS Templates</h3></div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead><tr><th>Name</th><th>Type</th><th>Content</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($templates as $template)
                        <tr>
                            <td>{{ $template->name }}</td>
                            <td>{{ $template->type }}</td>
                            <td>{{ Str::limit($template->content, 50) }}</td>
                            <td><span class="badge badge-{{ $template->is_active ? 'success' : 'danger' }}">{{ $template->is_active ? 'Active' : 'Inactive' }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="4" class="text-center">No templates</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header"><h3 class="card-title">Add Template</h3></div>
            <form action="{{ route('admin.sms.templates.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Type</label>
                        <select name="type" class="form-control" required>
                            <option value="payment_reminder">Payment Reminder</option>
                            <option value="bill_generated">Bill Generated</option>
                            <option value="payment_received">Payment Received</option>
                            <option value="connection_active">Connection Active</option>
                            <option value="connection_suspended">Connection Suspended</option>
                            <option value="custom">Custom</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Content</label><textarea name="content" class="form-control" rows="4" required></textarea></div>
                    <div class="form-check"><input type="checkbox" name="is_active" class="form-check-input" checked><label class="form-check-label">Active</label></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-primary">Add Template</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
