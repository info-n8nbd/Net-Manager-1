@extends('layouts.admin')

@section('title', 'SMS Auto Process')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.sms.templates') }}">SMS</a></li>
<li class="breadcrumb-item active">Auto Process</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-6">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-cog mr-2"></i>Bill Generation SMS</h3>
            </div>
            <div class="card-body">
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input" id="billGenSms" checked>
                    <label class="custom-control-label" for="billGenSms">Enable Bill Generation SMS</label>
                </div>
                <p class="text-muted">Send SMS to all clients when bills are generated with their bill amount and due date.</p>
            </div>
        </div>
        
        <div class="card card-warning card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-bell mr-2"></i>Deadline Reminders</h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="custom-control custom-switch mb-2">
                        <input type="checkbox" class="custom-control-input" id="reminder1" checked>
                        <label class="custom-control-label" for="reminder1">1st Reminder (3 days before deadline)</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="custom-control custom-switch mb-2">
                        <input type="checkbox" class="custom-control-input" id="reminder2" checked>
                        <label class="custom-control-label" for="reminder2">2nd Reminder (1 day before deadline)</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="disconnectSms" checked>
                        <label class="custom-control-label" for="disconnectSms">Disconnection SMS (on deadline)</label>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-mobile-alt mr-2"></i>Online Payment SMS</h3>
            </div>
            <div class="card-body">
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input" id="onlinePaySms" checked>
                    <label class="custom-control-label" for="onlinePaySms">Send SMS on Online Payment</label>
                </div>
                <p class="text-muted">Automatically send confirmation SMS with TrxID when client pays via bKash/Rocket/iPay.</p>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card card-danger card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-server mr-2"></i>Device Down Notification</h3>
            </div>
            <div class="card-body">
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input" id="deviceDownSms" checked>
                    <label class="custom-control-label" for="deviceDownSms">Enable Device Down SMS</label>
                </div>
                <div class="form-group">
                    <label>Notify Admin Phone</label>
                    <input type="text" class="form-control" value="+8801XXXXXXXXX">
                </div>
                <p class="text-muted">Send SMS when any ONU/Router goes offline.</p>
            </div>
        </div>
        
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fab fa-telegram mr-2"></i>Telegram Notifications</h3>
            </div>
            <div class="card-body">
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input" id="telegramNotif">
                    <label class="custom-control-label" for="telegramNotif">Enable Telegram Notifications</label>
                </div>
                <div class="form-group">
                    <label>Telegram Bot Token</label>
                    <input type="text" class="form-control" placeholder="Enter Bot Token">
                </div>
                <div class="form-group">
                    <label>Chat/Group ID</label>
                    <input type="text" class="form-control" placeholder="Enter Chat ID">
                </div>
                <p class="text-muted">Send notifications to Telegram group for payments, device status, etc.</p>
            </div>
        </div>
        
        <div class="card card-secondary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-clock mr-2"></i>Schedule Time</h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label>Reminder SMS Time</label>
                    <input type="time" class="form-control" value="09:00">
                </div>
                <div class="form-group">
                    <label>Device Check Interval</label>
                    <select class="form-control">
                        <option value="1">Every 1 minute</option>
                        <option value="5" selected>Every 5 minutes</option>
                        <option value="15">Every 15 minutes</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-footer">
                <button type="button" class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save All Settings</button>
                <button type="button" class="btn btn-success float-right"><i class="fas fa-play mr-1"></i>Run Auto Process Now</button>
            </div>
        </div>
    </div>
</div>
@endsection
