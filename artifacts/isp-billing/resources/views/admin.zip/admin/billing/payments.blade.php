@extends('layouts.admin')

@section('title', 'Payments')
@section('breadcrumb')
<li class="breadcrumb-item active">Payments</li>
@endsection

@section('content')
<style>
.payment-card { border-left: 4px solid #28a745; margin-bottom: 12px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.payment-card .card-body { padding: 12px 15px; }
.payment-card .payment-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.payment-card .client-name { font-weight: 600; font-size: 15px; color: #333; margin: 0; }
.payment-card .payment-amount { font-weight: bold; font-size: 16px; color: #28a745; }
.payment-card .payment-info { font-size: 13px; color: #666; margin-bottom: 5px; }
.payment-card .payment-meta { display: flex; flex-wrap: wrap; gap: 10px; font-size: 12px; }
@media (min-width: 768px) { .mobile-cards { display: none; } }
@media (max-width: 767px) { .desktop-table { display: none; } }
</style>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
        <h3 class="card-title mb-2 mb-md-0">All Payments</h3>
        <a href="{{ route('admin.payments.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Receive Payment</a>
    </div>
    <div class="card-body">
        <div class="mobile-cards">
            @forelse($payments as $payment)
            <div class="card payment-card">
                <div class="card-body">
                    <div class="payment-header">
                        <h6 class="client-name">{{ $payment->client->name ?? 'N/A' }}</h6>
                        <span class="payment-amount">৳{{ number_format($payment->amount) }}</span>
                    </div>
                    <div class="payment-info">
                        <strong>#{{ $payment->payment_no }}</strong>
                    </div>
                    <div class="payment-meta mb-2">
                        <span><i class="fas fa-credit-card mr-1"></i>{{ $payment->paymentMethod->name ?? 'Cash' }}</span>
                        <span><i class="fas fa-calendar mr-1"></i>{{ $payment->payment_date->format('d M Y') }}</span>
                        <span><i class="fas fa-user mr-1"></i>{{ $payment->collectedBy->name ?? 'N/A' }}</span>
                    </div>
                    <div class="btn-group-mobile d-flex gap-2">
                        <a href="{{ route('admin.payments.edit', $payment) }}" class="btn btn-warning btn-sm flex-fill"><i class="fas fa-edit mr-1"></i>Edit</a>
                        <form action="{{ route('admin.payments.destroy', $payment) }}" method="POST" class="flex-fill" onsubmit="return confirm('Delete this payment?')">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm btn-block"><i class="fas fa-trash mr-1"></i>Delete</button>
                        </form>
                    </div>
                </div>
            </div>
            @empty
            <div class="text-center text-muted py-4">No payments found</div>
            @endforelse
        </div>

        <div class="desktop-table">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr><th>Payment No</th><th>Client</th><th>Amount (৳)</th><th>Method</th><th>Date</th><th>Collected By</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        @forelse($payments as $payment)
                        <tr>
                            <td>{{ $payment->payment_no }}</td>
                            <td>{{ $payment->client->name ?? 'N/A' }}</td>
                            <td>{{ number_format($payment->amount, 2) }}</td>
                            <td>{{ $payment->paymentMethod->name ?? 'Cash' }}</td>
                            <td>{{ $payment->payment_date->format('d M Y') }}</td>
                            <td>{{ $payment->collectedBy->name ?? 'N/A' }}</td>
                            <td>
                                <a href="{{ route('admin.payments.edit', $payment) }}" class="btn btn-warning btn-xs" title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('admin.payments.destroy', $payment) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this payment?')">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-xs" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="7" class="text-center">No payments found</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="d-flex flex-wrap justify-content-between align-items-center mt-3">
            <div class="mb-2">Showing {{ $payments->firstItem() ?? 0 }} to {{ $payments->lastItem() ?? 0 }} of {{ $payments->total() }} results</div>
            {{ $payments->links('vendor.pagination.bootstrap-4') }}
        </div>
    </div>
</div>
@endsection
