<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice {{ $bill->bill_no }}</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 24px; }
        .header p { margin: 5px 0; }
        .info-table { width: 100%; margin-bottom: 20px; }
        .info-table td { padding: 5px; vertical-align: top; }
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .items-table th, .items-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .items-table th { background: #f5f5f5; }
        .text-right { text-align: right; }
        .total-row { font-weight: bold; background: #f5f5f5; }
        .footer { text-align: center; margin-top: 40px; font-size: 10px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>INVOICE</h1>
        <p>{{ $bill->bill_no }}</p>
    </div>

    <table class="info-table">
        <tr>
            <td width="50%">
                <strong>Bill To:</strong><br>
                {{ $bill->client->name }}<br>
                {{ $bill->client->address }}<br>
                Phone: {{ $bill->client->phone }}
            </td>
            <td width="50%" class="text-right">
                <strong>Invoice Date:</strong> {{ $bill->bill_date->format('d M Y') }}<br>
                <strong>Due Date:</strong> {{ $bill->due_date->format('d M Y') }}<br>
                <strong>Client ID:</strong> {{ $bill->client->client_id }}<br>
                <strong>Package:</strong> {{ $bill->client->package->name ?? 'N/A' }}
            </td>
        </tr>
    </table>

    <table class="items-table">
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-right">Amount (BDT)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Monthly Subscription - {{ date('F Y', mktime(0,0,0,$bill->billing_month,1,$bill->billing_year)) }}</td>
                <td class="text-right">{{ number_format($bill->package_amount, 2) }}</td>
            </tr>
            @if($bill->previous_due > 0)
            <tr>
                <td>Previous Due</td>
                <td class="text-right">{{ number_format($bill->previous_due, 2) }}</td>
            </tr>
            @endif
            @if($bill->discount > 0)
            <tr>
                <td>Discount</td>
                <td class="text-right">-{{ number_format($bill->discount, 2) }}</td>
            </tr>
            @endif
            <tr class="total-row">
                <td>Total Amount</td>
                <td class="text-right">৳ {{ number_format($bill->total_amount, 2) }}</td>
            </tr>
            <tr>
                <td>Paid Amount</td>
                <td class="text-right">৳ {{ number_format($bill->paid_amount, 2) }}</td>
            </tr>
            <tr class="total-row">
                <td>Due Amount</td>
                <td class="text-right">৳ {{ number_format($bill->due_amount, 2) }}</td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        <p>Thank you for your business!</p>
        <p>This is a computer-generated invoice and does not require a signature.</p>
    </div>
</body>
</html>
