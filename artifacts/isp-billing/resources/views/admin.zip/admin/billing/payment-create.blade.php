@extends('layouts.admin')

@section('title', 'Receive Payment')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.payments.index') }}">Payments</a></li>
<li class="breadcrumb-item active">Receive</li>
@endsection

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-money-bill-wave mr-2"></i>Receive Payment</h3>
            </div>
            <form action="{{ route('admin.payments.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    @if(isset($selectedClient))
                    <div class="alert alert-info">
                        <i class="fas fa-user mr-2"></i>
                        <strong>Client:</strong> {{ $selectedClient->client_id }} - {{ $selectedClient->name }}
                        <span class="badge badge-{{ $selectedClient->due_amount > 0 ? 'danger' : 'success' }} ml-2">
                            Due: ৳{{ number_format($selectedClient->due_amount, 2) }}
                        </span>
                        <input type="hidden" name="client_id" value="{{ $selectedClient->id }}">
                    </div>
                    @else
                    <div class="form-group">
                        <label><i class="fas fa-user mr-1"></i> Select Client <span class="text-danger">*</span></label>
                        <select name="client_id" class="form-control select2" required>
                            <option value="">-- Choose Client --</option>
                            @foreach($clients as $client)
                            <option value="{{ $client->id }}" {{ request('client_id') == $client->id ? 'selected' : '' }}>
                                {{ $client->client_id }} - {{ $client->name }} (Due: ৳{{ number_format($client->due_amount, 2) }})
                            </option>
                            @endforeach
                        </select>
                    </div>
                    @endif

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><i class="fas fa-dollar-sign mr-1"></i> Amount (৳) <span class="text-danger">*</span></label>
                                <input type="number" name="amount" class="form-control form-control-lg" step="0.01" min="1" 
                                       placeholder="Enter amount" value="{{ old('amount') }}" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><i class="fas fa-credit-card mr-1"></i> Payment Method <span class="text-danger">*</span></label>
                                <select name="payment_method_id" class="form-control" required>
                                    @foreach($paymentMethods as $method)
                                    <option value="{{ $method->id }}" {{ old('payment_method_id') == $method->id ? 'selected' : '' }}>
                                        {{ $method->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><i class="fas fa-calendar mr-1"></i> Payment Date <span class="text-danger">*</span></label>
                                <input type="date" name="payment_date" class="form-control" 
                                       value="{{ old('payment_date', date('Y-m-d')) }}" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><i class="fas fa-receipt mr-1"></i> Transaction ID</label>
                                <input type="text" name="transaction_id" class="form-control" 
                                       placeholder="Optional - bKash/Nagad TrxID" value="{{ old('transaction_id') }}">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-comment mr-1"></i> Remarks</label>
                        <textarea name="remarks" class="form-control" rows="2" placeholder="Optional notes">{{ old('remarks') }}</textarea>
                    </div>

                    <input type="hidden" name="bill_id" value="{{ request('bill_id') }}">
                </div>
                <div class="card-footer text-right">
                    <a href="{{ route('admin.payments.index') }}" class="btn btn-secondary mr-2">
                        <i class="fas fa-times mr-1"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-check mr-1"></i> Receive Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css">
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('.select2').select2({
        placeholder: '-- Choose Client --',
        allowClear: true
    });
});
</script>
@endpush
