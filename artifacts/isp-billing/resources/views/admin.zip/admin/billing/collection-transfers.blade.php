@extends('layouts.admin')

@section('title', 'Collection Transfers')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.billing.index') }}">Billing</a></li>
<li class="breadcrumb-item active">Collection Transfers</li>
@endsection

@section('content')
<style>
.transfer-card { border-left: 4px solid #17a2b8; margin-bottom: 12px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.transfer-card.status-pending { border-left-color: #ffc107; }
.transfer-card.status-completed { border-left-color: #28a745; }
.transfer-card .card-body { padding: 12px 15px; }
.transfer-card .transfer-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.transfer-card .transfer-amount { font-weight: bold; font-size: 18px; color: #28a745; }
.transfer-card .transfer-info { font-size: 13px; color: #666; margin-bottom: 8px; }
.transfer-card .btn-group-mobile { display: flex; flex-wrap: wrap; gap: 6px; }
.transfer-card .btn-group-mobile .btn { flex: 1; min-width: 80px; font-size: 13px; padding: 6px 10px; }
@media (min-width: 768px) { .mobile-cards { display: none; } }
@media (max-width: 767px) { .desktop-table { display: none; } }
</style>

<div class="row mb-3">
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">New Collection Transfer</h5>
                <form action="{{ route('admin.billing.collection-transfers.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label>To Account</label>
                        <select name="to_account_id" class="form-control" required>
                            <option value="">-- Select Account --</option>
                            @foreach($accounts as $account)
                            <option value="{{ $account->id }}">{{ $account->name }} (৳{{ number_format($account->current_balance) }})</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Amount (৳)</label>
                        <input type="number" name="amount" class="form-control" step="0.01" min="1" required>
                    </div>
                    <div class="form-group">
                        <label>Transfer Date</label>
                        <input type="date" name="transfer_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                    </div>
                    <div class="form-group">
                        <label>Remarks</label>
                        <textarea name="remarks" class="form-control" rows="2" placeholder="Optional notes..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-light btn-block">
                        <i class="fas fa-paper-plane mr-1"></i> Submit Transfer
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-exchange-alt mr-2"></i>Collection Transfers</h3>
            </div>
            <div class="card-body">
                <div class="mobile-cards">
                    @forelse($transfers as $transfer)
                    <div class="card transfer-card status-{{ $transfer->status }}">
                        <div class="card-body">
                            <div class="transfer-header">
                                <div>
                                    <strong>{{ $transfer->transfer_no }}</strong>
                                    <span class="badge badge-{{ $transfer->status == 'completed' ? 'success' : 'warning' }} ml-2">
                                        {{ ucfirst($transfer->status) }}
                                    </span>
                                </div>
                                <span class="transfer-amount">৳{{ number_format($transfer->amount) }}</span>
                            </div>
                            <div class="transfer-info">
                                <i class="fas fa-user mr-1"></i> {{ $transfer->fromUser->name ?? 'N/A' }} 
                                <i class="fas fa-arrow-right mx-2"></i>
                                <i class="fas fa-university mr-1"></i> {{ $transfer->toAccount->name ?? 'N/A' }}
                            </div>
                            <div class="transfer-info">
                                <i class="fas fa-calendar mr-1"></i> {{ $transfer->transfer_date?->format('d M Y') ?? $transfer->created_at->format('d M Y') }}
                                @if($transfer->remarks)
                                <br><small class="text-muted"><i class="fas fa-comment mr-1"></i>{{ $transfer->remarks }}</small>
                                @endif
                            </div>
                            @if($transfer->status == 'pending')
                            <div class="btn-group-mobile">
                                <form action="{{ route('admin.billing.collection-transfers.verify', $transfer) }}" method="POST" class="flex-fill">
                                    @csrf
                                    <input type="hidden" name="action" value="verify">
                                    <button type="submit" class="btn btn-success btn-sm btn-block" onclick="return confirm('Verify this transfer?')">
                                        <i class="fas fa-check mr-1"></i> Verify
                                    </button>
                                </form>
                                <form action="{{ route('admin.billing.collection-transfers.verify', $transfer) }}" method="POST" class="flex-fill">
                                    @csrf
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="btn btn-danger btn-sm btn-block" onclick="return confirm('Reject this transfer?')">
                                        <i class="fas fa-times mr-1"></i> Reject
                                    </button>
                                </form>
                            </div>
                            @else
                            <small class="text-muted">
                                <i class="fas fa-check-circle text-success mr-1"></i>Verified by {{ $transfer->verifier->name ?? 'Admin' }}
                            </small>
                            @endif
                        </div>
                    </div>
                    @empty
                    <div class="text-center text-muted py-4">No collection transfers found</div>
                    @endforelse
                </div>

                <div class="desktop-table">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Transfer No</th>
                                    <th>From</th>
                                    <th>To Account</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($transfers as $transfer)
                                <tr>
                                    <td><code>{{ $transfer->transfer_no }}</code></td>
                                    <td>{{ $transfer->fromUser->name ?? 'N/A' }}</td>
                                    <td>{{ $transfer->toAccount->name ?? 'N/A' }}</td>
                                    <td class="text-success font-weight-bold">৳{{ number_format($transfer->amount, 2) }}</td>
                                    <td>{{ $transfer->transfer_date?->format('d M Y') ?? $transfer->created_at->format('d M Y') }}</td>
                                    <td>
                                        <span class="badge badge-{{ $transfer->status == 'completed' ? 'success' : 'warning' }}">
                                            {{ ucfirst($transfer->status) }}
                                        </span>
                                    </td>
                                    <td>
                                        @if($transfer->status == 'pending')
                                        <form action="{{ route('admin.billing.collection-transfers.verify', $transfer) }}" method="POST" class="d-inline">
                                            @csrf
                                            <input type="hidden" name="action" value="verify">
                                            <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Verify this transfer?')">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                        <form action="{{ route('admin.billing.collection-transfers.verify', $transfer) }}" method="POST" class="d-inline">
                                            @csrf
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Reject this transfer?')">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </form>
                                        @else
                                        <small class="text-muted">
                                            <i class="fas fa-check-circle text-success"></i> {{ $transfer->verifier->name ?? 'Admin' }}
                                        </small>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No collection transfers found</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card-footer">{{ $transfers->links() }}</div>
        </div>
    </div>
</div>
@endsection
