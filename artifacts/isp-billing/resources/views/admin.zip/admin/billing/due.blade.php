@extends('layouts.admin')

@section('title', 'Due Bills')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.billing.index') }}">Billing</a></li>
<li class="breadcrumb-item active">Due Bills</li>
@endsection

@section('content')
<style>
.bill-card { border-left: 4px solid #dc3545; margin-bottom: 12px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.bill-card.overdue { border-left-color: #dc3545; background: #fff5f5; }
.bill-card .card-body { padding: 12px 15px; }
.bill-card .bill-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.bill-card .client-name { font-weight: 600; font-size: 15px; color: #333; margin: 0; }
.bill-card .bill-amount { font-weight: bold; font-size: 16px; color: #dc3545; }
.bill-card .bill-info { font-size: 13px; color: #666; margin-bottom: 5px; }
.bill-card .bill-meta { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; font-size: 12px; }
.bill-card .btn-group-mobile { display: flex; flex-wrap: wrap; gap: 6px; }
.bill-card .btn-group-mobile .btn { flex: 1; min-width: 70px; font-size: 13px; padding: 6px 10px; }
@media (min-width: 768px) { .mobile-cards { display: none; } }
@media (max-width: 767px) { .desktop-table { display: none; } }
</style>

<div class="card">
    <div class="card-header"><h3 class="card-title">Due Bills</h3></div>
    <div class="card-body">
        <div class="mobile-cards">
            @forelse($bills as $bill)
            <div class="card bill-card {{ $bill->due_date < today() ? 'overdue' : '' }}">
                <div class="card-body">
                    <div class="bill-header">
                        <h6 class="client-name">{{ $bill->client->name ?? 'N/A' }}</h6>
                        <span class="bill-amount">৳{{ number_format($bill->due_amount) }}</span>
                    </div>
                    <div class="bill-info">
                        <strong>#{{ $bill->bill_no }}</strong> | {{ $bill->client->phone ?? 'N/A' }}
                    </div>
                    <div class="bill-meta">
                        <span><i class="fas fa-calendar mr-1"></i>Due: {{ $bill->due_date->format('d M Y') }}</span>
                        <span>Total: ৳{{ number_format($bill->total_amount) }}</span>
                        @if($bill->due_date < today())
                        <span class="badge badge-danger">Overdue</span>
                        @endif
                    </div>
                    <div class="btn-group-mobile">
                        <a href="{{ route('admin.payments.create') }}?client_id={{ $bill->client_id }}&bill_id={{ $bill->id }}" class="btn btn-success btn-sm">
                            <i class="fas fa-money-bill mr-1"></i> Collect
                        </a>
                        <a href="tel:{{ $bill->client->phone ?? '' }}" class="btn btn-primary btn-sm">
                            <i class="fas fa-phone mr-1"></i> Call
                        </a>
                    </div>
                </div>
            </div>
            @empty
            <div class="text-center text-muted py-4">No due bills</div>
            @endforelse
        </div>

        <div class="desktop-table">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr><th>Bill No</th><th>Client</th><th>Phone</th><th>Due Date</th><th>Total (৳)</th><th>Due (৳)</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        @forelse($bills as $bill)
                        <tr class="{{ $bill->due_date < today() ? 'table-danger' : '' }}">
                            <td>{{ $bill->bill_no }}</td>
                            <td>{{ $bill->client->name ?? 'N/A' }}</td>
                            <td>{{ $bill->client->phone ?? 'N/A' }}</td>
                            <td>{{ $bill->due_date->format('d M Y') }}</td>
                            <td>{{ number_format($bill->total_amount, 2) }}</td>
                            <td>{{ number_format($bill->due_amount, 2) }}</td>
                            <td>
                                <a href="{{ route('admin.payments.create') }}?client_id={{ $bill->client_id }}&bill_id={{ $bill->id }}" class="btn btn-success btn-xs">Collect</a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="7" class="text-center">No due bills</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        {{ $bills->links() }}
    </div>
</div>
@endsection
