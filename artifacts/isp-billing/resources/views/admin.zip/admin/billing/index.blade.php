@extends('layouts.admin')

@section('title', 'Bill List')
@section('breadcrumb')
<li class="breadcrumb-item active">Billing</li>
@endsection

@section('content')
<style>
.bill-card { border-left: 4px solid #17a2b8; margin-bottom: 12px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.bill-card.status-paid { border-left-color: #28a745; }
.bill-card.status-partial { border-left-color: #ffc107; }
.bill-card.status-unpaid { border-left-color: #dc3545; }
.bill-card .card-body { padding: 12px 15px; }
.bill-card .bill-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.bill-card .client-name { font-weight: 600; font-size: 15px; color: #333; margin: 0; }
.bill-card .bill-info { font-size: 13px; color: #666; margin-bottom: 5px; }
.bill-card .bill-meta { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; font-size: 12px; }
.bill-card .btn-group-mobile { display: flex; flex-wrap: wrap; gap: 6px; }
.bill-card .btn-group-mobile .btn { flex: 1; min-width: 60px; font-size: 13px; padding: 6px 10px; }
@media (min-width: 768px) { .mobile-cards { display: none; } }
@media (max-width: 767px) { .desktop-table { display: none; } }
</style>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
        <h3 class="card-title mb-2 mb-md-0">All Bills</h3>
        <a href="{{ route('admin.billing.generate') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Generate Bills</a>
    </div>
    <div class="card-body">
        <div class="mobile-cards">
            @forelse($bills as $bill)
            <div class="card bill-card status-{{ $bill->status }}">
                <div class="card-body">
                    <div class="bill-header">
                        <h6 class="client-name">{{ $bill->client->name ?? 'N/A' }}</h6>
                        <span class="badge badge-{{ $bill->status == 'paid' ? 'success' : ($bill->status == 'partial' ? 'warning' : 'danger') }}">{{ ucfirst($bill->status) }}</span>
                    </div>
                    <div class="bill-info">
                        <strong>#{{ $bill->bill_no }}</strong> | {{ $bill->billing_month }}/{{ $bill->billing_year }}
                    </div>
                    <div class="bill-meta">
                        <span>Total: <strong>৳{{ number_format($bill->total_amount) }}</strong></span>
                        <span class="text-success">Paid: ৳{{ number_format($bill->paid_amount) }}</span>
                        <span class="text-danger">Due: ৳{{ number_format($bill->due_amount) }}</span>
                    </div>
                    <div class="btn-group-mobile">
                        <a href="{{ route('admin.billing.show', $bill) }}" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <a href="{{ route('admin.billing.edit', $bill) }}" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="{{ route('admin.billing.invoice', $bill) }}" class="btn btn-secondary btn-sm">
                            <i class="fas fa-download"></i>
                        </a>
                    </div>
                </div>
            </div>
            @empty
            <div class="text-center text-muted py-4">No bills found</div>
            @endforelse
        </div>

        <div class="desktop-table">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr><th>Bill No</th><th>Client</th><th>Month</th><th>Total (৳)</th><th>Paid (৳)</th><th>Due (৳)</th><th>Status</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        @forelse($bills as $bill)
                        <tr>
                            <td>{{ $bill->bill_no }}</td>
                            <td>{{ $bill->client->name ?? 'N/A' }}</td>
                            <td>{{ $bill->billing_month }}/{{ $bill->billing_year }}</td>
                            <td>{{ number_format($bill->total_amount, 2) }}</td>
                            <td>{{ number_format($bill->paid_amount, 2) }}</td>
                            <td>{{ number_format($bill->due_amount, 2) }}</td>
                            <td><span class="badge badge-{{ $bill->status == 'paid' ? 'success' : ($bill->status == 'partial' ? 'warning' : 'danger') }}">{{ ucfirst($bill->status) }}</span></td>
                            <td>
                                <a href="{{ route('admin.billing.show', $bill) }}" class="btn btn-info btn-xs" title="View"><i class="fas fa-eye"></i></a>
                                <a href="{{ route('admin.billing.edit', $bill) }}" class="btn btn-warning btn-xs" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="{{ route('admin.billing.invoice', $bill) }}" class="btn btn-secondary btn-xs" title="Invoice"><i class="fas fa-download"></i></a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="8" class="text-center">No bills found</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        {{ $bills->links() }}
    </div>
</div>
@endsection
