@extends('layouts.admin')

@section('title', 'Dashboard')
@section('breadcrumb')
<li class="breadcrumb-item active">Dashboard</li>
@endsection

@section('content')
<div class="row mb-2">
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.clients.index') }}" class="text-decoration-none">
            <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
                <div class="stat-number">{{ $totalClients }}</div>
                <div class="stat-label">Total Clients</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.clients.index') }}?status=active" class="text-decoration-none">
            <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
                <div class="stat-number">{{ $activeClients }}</div>
                <div class="stat-label">Active Clients</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.reports.monthly') }}" class="text-decoration-none">
            <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
                <div class="stat-number">৳{{ number_format($monthlyCollection, 0) }}</div>
                <div class="stat-label">Monthly</div>
            </div>
        </a>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <a href="{{ route('admin.reports.due') }}" class="text-decoration-none">
            <div class="stat-box bg-danger text-white text-center py-3 rounded h-100">
                <div class="stat-number">৳{{ number_format($totalDue, 0) }}</div>
                <div class="stat-label">Total Due</div>
            </div>
        </a>
    </div>
</div>

<div class="row mb-2">
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-primary text-white text-center py-3 rounded h-100 position-relative">
            <span class="position-absolute" style="top: 5px; right: 8px; width: 8px; height: 8px; background: #00ff00; border-radius: 50%; animation: pulse 1s infinite;"></span>
            <div class="stat-number" id="liveOnlineClients">{{ $advancedStats['live_online_clients'] ?? 0 }}</div>
            <div class="stat-label">Live Online</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-danger text-white text-center py-3 rounded h-100 position-relative">
            <span class="position-absolute" style="top: 5px; right: 8px; width: 8px; height: 8px; background: #ffcc00; border-radius: 50%; animation: pulse 1s infinite;"></span>
            <div class="stat-number" id="liveOfflineClients">{{ $advancedStats['auto_inactive_clients'] ?? 0 }}</div>
            <div class="stat-label">Offline</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-success text-white text-center py-3 rounded h-100 position-relative">
            <span class="position-absolute" style="top: 5px; right: 8px; width: 8px; height: 8px; background: #00ff00; border-radius: 50%; animation: pulse 1s infinite;"></span>
            <div class="stat-number" id="liveTodayCollection">৳{{ number_format($advancedStats['today_collection'] ?? 0, 0) }}</div>
            <div class="stat-label">Today Collection</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-warning text-dark text-center py-3 rounded h-100 position-relative">
            <span class="position-absolute" style="top: 5px; right: 8px; width: 8px; height: 8px; background: #ff0000; border-radius: 50%; animation: pulse 1s infinite;" id="ticketPulse"></span>
            <div class="stat-number" id="livePendingTickets">{{ $advancedStats['pending_tickets'] ?? 0 }}</div>
            <div class="stat-label">Tickets</div>
        </div>
    </div>
</div>

<div class="row mb-2">
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['monthly_signup_fee'] ?? 0, 0) }}</div>
            <div class="stat-label">Signup Fee</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['monthly_reseller_collection'] ?? 0, 0) }}</div>
            <div class="stat-label">Reseller</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-danger text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['running_month_bills'] ?? 0, 0) }}</div>
            <div class="stat-label">Month Bills</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-secondary text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['old_due_amount'] ?? 0, 0) }}</div>
            <div class="stat-label">Old Due</div>
        </div>
    </div>
</div>

<div class="row mb-2">
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-warning text-dark text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['today_expense'] ?? 0, 0) }}</div>
            <div class="stat-label">Expense</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($advancedStats['monthly_others_collection'] ?? 0, 0) }}</div>
            <div class="stat-label">Others</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
            <div class="stat-number">{{ $inactiveClients }}</div>
            <div class="stat-label">Inactive</div>
        </div>
    </div>
    <div class="col-6 col-lg-3 mb-2">
        <div class="stat-box bg-primary text-white text-center py-3 rounded h-100">
            <div class="stat-number">{{ $pendingClients }}</div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
</div>

<div class="row mb-2">
    <div class="col-12">
        <div class="card card-dark card-outline mb-0">
            <div class="card-header bg-gradient-dark py-2">
                <h3 class="card-title"><i class="fas fa-satellite-dish mr-2 live-pulse"></i> Real-Time</h3>
                <div class="card-tools">
                    <small class="text-light" id="liveTimestamp">--:--:--</small>
                </div>
            </div>
            <div class="card-body p-2">
                <div class="row no-gutters">
                    <div class="col-4 p-1">
                        <div class="stat-box bg-success text-white text-center py-3 rounded">
                            <div class="stat-number" id="liveOnlineClients">{{ $advancedStats['live_online_clients'] ?? 0 }}</div>
                            <div class="stat-label">Online</div>
                        </div>
                    </div>
                    <div class="col-4 p-1">
                        <div class="stat-box bg-danger text-white text-center py-3 rounded">
                            <div class="stat-number" id="liveOfflineClients">0</div>
                            <div class="stat-label">Offline</div>
                        </div>
                    </div>
                    <div class="col-4 p-1">
                        <div class="stat-box bg-info text-white text-center py-3 rounded">
                            <div class="stat-number" id="liveTodayCollection">৳{{ number_format($advancedStats['today_collection'] ?? 0, 0) }}</div>
                            <div class="stat-label">Today</div>
                        </div>
                    </div>
                    <div class="col-4 p-1">
                        <div class="stat-box bg-warning text-dark text-center py-3 rounded">
                            <div class="stat-number" id="livePendingTickets">{{ $advancedStats['pending_tickets'] ?? 0 }}</div>
                            <div class="stat-label">Tickets</div>
                        </div>
                    </div>
                    <div class="col-4 p-1">
                        <div class="stat-box bg-danger text-white text-center py-3 rounded">
                            <div class="stat-number" id="liveCriticalTickets">0</div>
                            <div class="stat-label">Critical</div>
                        </div>
                    </div>
                    <div class="col-4 p-1">
                        <div class="stat-box bg-primary text-white text-center py-3 rounded">
                            <div class="stat-number" id="liveTodayNewClients">0</div>
                            <div class="stat-label">New</div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-2">
                    <div class="col-lg-4">
                        <div class="card card-outline card-success h-100">
                            <div class="card-header py-2">
                                <h5 class="card-title mb-0"><i class="fas fa-heartbeat mr-2"></i> ISP Health Score</h5>
                            </div>
                            <div class="card-body text-center">
                                <div class="health-score-circle mx-auto mb-3 grade-{{ strtolower(substr($ispHealth['grade'] ?? 'B', 0, 1)) }}">
                                    {{ $ispHealth['grade'] ?? 'B' }}
                                </div>
                                <h4 class="mb-1">{{ $ispHealth['overall_score'] ?? 85 }}%</h4>
                                <p class="text-muted mb-3">Overall Health</p>
                                <div class="row text-center">
                                    <div class="col-4 border-right">
                                        <h5 class="mb-0 text-success">{{ $ispHealth['network_score'] ?? 90 }}%</h5>
                                        <small class="text-muted">Network</small>
                                    </div>
                                    <div class="col-4 border-right">
                                        <h5 class="mb-0 text-info">{{ $ispHealth['billing_score'] ?? 85 }}%</h5>
                                        <small class="text-muted">Billing</small>
                                    </div>
                                    <div class="col-4">
                                        <h5 class="mb-0 text-primary">{{ $ispHealth['support_score'] ?? 80 }}%</h5>
                                        <small class="text-muted">Support</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card card-outline card-danger h-100">
                            <div class="card-header py-2">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-bell mr-2"></i> Live Alerts 
                                    <span class="badge badge-warning" id="alertCountBadge">0</span>
                                </h5>
                            </div>
                            <div class="card-body p-2" style="max-height: 250px; overflow-y: auto;">
                                <div id="liveAlertsContainer">
                                    <div class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                                        <br><small>Loading alerts...</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card card-outline card-info h-100">
                            <div class="card-header py-2">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-coins mr-2"></i> Live Payments
                                    <small class="float-right text-muted" id="liveTodayPaymentCount">0 payments</small>
                                </h5>
                            </div>
                            <div class="card-body p-2" style="max-height: 250px; overflow-y: auto;">
                                <div class="text-center mb-2">
                                    <h3 class="text-success mb-0" id="liveTodayCollectionTotal">৳0</h3>
                                    <small class="text-muted">Today's Total</small>
                                </div>
                                <div id="livePaymentsContainer">
                                    <div class="text-center text-muted py-3">
                                        <i class="fas fa-spinner fa-spin"></i> Loading...
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-3">
                    <div class="col-lg-6">
                        <div class="card card-outline card-primary">
                            <div class="card-header py-2">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-server mr-2"></i> Network Devices
                                    <small class="float-right">
                                        <span class="text-success" id="routersOnline">0</span> Online /
                                        <span class="text-danger" id="routersOffline">0</span> Offline
                                    </small>
                                </h5>
                            </div>
                            <div class="card-body p-2" style="max-height: 200px; overflow-y: auto;">
                                <div id="networkDevicesContainer">
                                    <div class="text-center text-muted py-3">
                                        <i class="fas fa-spinner fa-spin"></i> Loading devices...
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card card-outline card-secondary">
                            <div class="card-header py-2">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-tachometer-alt mr-2"></i> Network Health
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-1">
                                    <span>Router Availability</span>
                                    <span id="networkHealthText">100%</span>
                                </div>
                                <div class="progress mb-3" style="height: 20px;">
                                    <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" id="networkHealthBar" style="width: 100%"></div>
                                </div>
                                <div class="row text-center">
                                    <div class="col-4">
                                        <span class="text-success"><i class="fas fa-circle fa-xs"></i></span>
                                        <span id="liveTodayPayments">0</span> Payments
                                    </div>
                                    <div class="col-4">
                                        <span class="text-info"><i class="fas fa-circle fa-xs"></i></span>
                                        {{ $networkEvents['today_events'] ?? 0 }} Events
                                    </div>
                                    <div class="col-4">
                                        <span class="text-danger"><i class="fas fa-circle fa-xs"></i></span>
                                        {{ ($networkEvents['router_down_alerts'] ?? 0) + ($networkEvents['fiber_cut_alerts'] ?? 0) }} Alerts
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-clock mr-1"></i> Due Bills Aging</h3>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center border-bottom mb-3 pb-3">
                    <span class="text-success"><i class="fas fa-circle mr-1"></i> 0-7 Days</span>
                    <span class="badge badge-success badge-lg">{{ $advancedStats['due_bills_aging']['0_7_days'] ?? 0 }}</span>
                </div>
                <div class="d-flex justify-content-between align-items-center border-bottom mb-3 pb-3">
                    <span class="text-warning"><i class="fas fa-circle mr-1"></i> 7-15 Days</span>
                    <span class="badge badge-warning badge-lg">{{ $advancedStats['due_bills_aging']['7_15_days'] ?? 0 }}</span>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-danger"><i class="fas fa-circle mr-1"></i> 15+ Days</span>
                    <span class="badge badge-danger badge-lg">{{ $advancedStats['due_bills_aging']['15_plus_days'] ?? 0 }}</span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-bolt mr-1"></i> Quick Actions</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.clients.create') }}" class="btn btn-primary btn-block btn-sm">
                            <i class="fas fa-user-plus"></i> Add Client
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.billing.generate') }}" class="btn btn-info btn-block btn-sm">
                            <i class="fas fa-file-invoice"></i> Generate Bill
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.payments.create') }}" class="btn btn-success btn-block btn-sm">
                            <i class="fas fa-money-bill"></i> Collect Payment
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.clients.index') }}" class="btn btn-secondary btn-block btn-sm">
                            <i class="fas fa-search"></i> Search Client
                        </a>
                    </div>
                </div>
                <hr class="my-2">
                <p class="text-muted mb-2 text-sm"><i class="fas fa-network-wired mr-1"></i> Network Management</p>
                <div class="row">
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.network.devices') }}" class="btn btn-outline-danger btn-block btn-sm">
                            <i class="fas fa-server"></i> MikroTik
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.olt.index') }}" class="btn btn-outline-success btn-block btn-sm">
                            <i class="fas fa-sitemap"></i> OLT Devices
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.network.diagram') }}" class="btn btn-outline-info btn-block btn-sm">
                            <i class="fas fa-project-diagram"></i> Diagram
                        </a>
                    </div>
                    <div class="col-6 mb-2">
                        <a href="{{ route('admin.network.monitoring') }}" class="btn btn-outline-warning btn-block btn-sm">
                            <i class="fas fa-chart-line"></i> Monitoring
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user-clock mr-1"></i> Employee Activity Today</h3>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                    @forelse($advancedStats['employee_activity_summary'] ?? [] as $activity)
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        {{ $activity['name'] }}
                        <span class="badge badge-primary badge-pill">{{ $activity['activity_count'] }} actions</span>
                    </li>
                    @empty
                    <li class="list-group-item text-center text-muted">No activity today</li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card card-danger card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-hand-holding-usd mr-1"></i> Staff Collection Dues</h3>
                <div class="card-tools">
                    <a href="{{ route('admin.hrm.staff-dues') }}" class="btn btn-tool btn-sm"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Staff Name</th>
                                <th>Type</th>
                                <th class="text-right">Collected</th>
                                <th class="text-right">Receipted</th>
                                <th class="text-right">Due</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($advancedStats['staff_collection_dues'] ?? [] as $staff)
                            <tr>
                                <td>{{ $staff['name'] }}</td>
                                <td><span class="badge badge-{{ $staff['user_type'] == 'technician' ? 'info' : 'secondary' }}">{{ ucfirst($staff['user_type']) }}</span></td>
                                <td class="text-right">৳{{ number_format($staff['total_collected'], 0) }}</td>
                                <td class="text-right text-success">৳{{ number_format($staff['receipted'], 0) }}</td>
                                <td class="text-right text-danger font-weight-bold">৳{{ number_format($staff['current_due'], 0) }}</td>
                                <td>
                                    <a href="{{ route('admin.hrm.receive-dues', $staff['id']) }}" class="btn btn-xs btn-success" title="Receive">
                                        <i class="fas fa-plus"></i>
                                    </a>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="6" class="text-center text-muted py-3">No pending staff dues</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            @php
                $totalDues = collect($advancedStats['staff_collection_dues'] ?? [])->sum('current_due');
            @endphp
            @if($totalDues > 0)
            <div class="card-footer bg-danger text-white">
                <div class="d-flex justify-content-between">
                    <span>Total Staff Dues:</span>
                    <strong>৳{{ number_format($totalDues, 0) }}</strong>
                </div>
            </div>
            @endif
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title"><i class="fas fa-chart-line mr-1"></i> Monthly Collection vs Discount</h3>
            </div>
            <div class="card-body">
                <canvas id="collectionChart" height="200"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title"><i class="fas fa-user-plus mr-1"></i> New Clients (Last 30 Days)</h3>
            </div>
            <div class="card-body">
                <canvas id="newClientsChart" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title"><i class="fas fa-map-marker-alt mr-1"></i> Zone-wise Statistics</h3>
                <div class="card-tools">
                    <a href="{{ route('admin.reports.zone') }}" class="btn btn-tool btn-sm"><i class="fas fa-bars"></i></a>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped table-sm">
                    <thead><tr><th>Zone</th><th class="text-right">Clients</th></tr></thead>
                    <tbody>
                        @forelse($advancedStats['zone_statistics'] ?? [] as $zone)
                        <tr>
                            <td>{{ $zone['zone_name'] }}</td>
                            <td class="text-right"><span class="badge badge-info">{{ $zone['total'] }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="2" class="text-center">No zone data</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title"><i class="fas fa-chart-pie mr-1"></i> Client Status</h3>
            </div>
            <div class="card-body">
                <canvas id="clientStatusChart" height="180"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Recent Payments</h3>
                <div class="card-tools">
                    <a href="{{ route('admin.payments.index') }}" class="btn btn-tool btn-sm"><i class="fas fa-bars"></i></a>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-striped table-valign-middle">
                    <thead><tr><th>Client</th><th>Amount</th><th>Date</th></tr></thead>
                    <tbody>
                        @forelse($recentPayments as $payment)
                        <tr>
                            <td>{{ $payment->client->name ?? 'N/A' }}</td>
                            <td>৳{{ number_format($payment->amount, 2) }}</td>
                            <td>{{ $payment->payment_date->format('d M Y') }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="3" class="text-center">No recent payments</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">Recent Tickets</h3>
                <div class="card-tools">
                    <a href="{{ route('admin.support.tickets') }}" class="btn btn-tool btn-sm"><i class="fas fa-bars"></i></a>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-striped table-valign-middle">
                    <thead><tr><th>Client</th><th>Subject</th><th>Status</th></tr></thead>
                    <tbody>
                        @forelse($recentTickets as $ticket)
                        <tr>
                            <td>{{ $ticket->client->name ?? 'N/A' }}</td>
                            <td>{{ Str::limit($ticket->subject, 30) }}</td>
                            <td><span class="badge badge-{{ $ticket->status == 'open' ? 'warning' : ($ticket->status == 'in_progress' ? 'info' : 'success') }}">{{ ucfirst($ticket->status) }}</span></td>
                        </tr>
                        @empty
                        <tr><td colspan="3" class="text-center">No recent tickets</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
var collectionData = @json($advancedStats['monthly_collection_vs_discount'] ?? []);
new Chart(document.getElementById('collectionChart'), {
    type: 'bar',
    data: {
        labels: collectionData.map(d => d.month),
        datasets: [{
            label: 'Collection',
            data: collectionData.map(d => d.collection),
            backgroundColor: '#1e3a5f'
        }, {
            label: 'Discount',
            data: collectionData.map(d => d.discount),
            backgroundColor: '#c53030'
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

var newClientsData = @json($advancedStats['new_clients_last_30_days'] ?? []);
new Chart(document.getElementById('newClientsChart'), {
    type: 'line',
    data: {
        labels: newClientsData.map(d => d.date),
        datasets: [{
            label: 'New Clients',
            data: newClientsData.map(d => d.count),
            borderColor: '#1e3a5f',
            backgroundColor: 'rgba(30, 58, 95, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

new Chart(document.getElementById('clientStatusChart'), {
    type: 'doughnut',
    data: {
        labels: ['Active', 'Inactive', 'Pending', 'Suspended'],
        datasets: [{
            data: [{{ $activeClients }}, {{ $inactiveClients }}, {{ $pendingClients }}, {{ $suspendedClients }}],
            backgroundColor: ['#38a169', '#1e3a5f', '#3182ce', '#c53030']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

function updateLiveStats() {
    fetch('/admin/api/live-stats')
        .then(r => r.json())
        .then(data => {
            if(data.live_online_clients !== undefined) {
                animateNumber('liveOnlineClients', data.live_online_clients);
                animateNumber('liveOfflineClients', data.live_offline_clients);
                document.getElementById('liveTodayCollection').textContent = data.today_collection_formatted;
                animateNumber('livePendingTickets', data.pending_tickets);
                animateNumber('liveCriticalTickets', data.critical_tickets);
                animateNumber('liveTodayNewClients', data.today_new_clients);
                animateNumber('liveTodayPayments', data.today_payments_count);
                document.getElementById('liveTimestamp').textContent = 'Updated: ' + data.timestamp;
                
                var healthPct = data.network_health;
                document.getElementById('networkHealthBar').style.width = healthPct + '%';
                document.getElementById('networkHealthText').textContent = healthPct + '%';
            }
        })
        .catch(e => console.log('Live stats update failed'));
}

function updateLiveAlerts() {
    fetch('/admin/api/live-alerts')
        .then(r => r.json())
        .then(data => {
            var container = document.getElementById('liveAlertsContainer');
            if(!container) return;
            
            var html = '';
            data.alerts.slice(0, 5).forEach(function(alert) {
                var severityClass = alert.severity === 'critical' ? 'danger' : (alert.severity === 'warning' ? 'warning' : 'info');
                html += '<div class="callout callout-' + severityClass + ' py-2 mb-2">' +
                    '<div class="d-flex justify-content-between align-items-center">' +
                    '<div><i class="' + alert.icon + ' mr-2"></i><strong>' + alert.title + '</strong></div>' +
                    '<small class="text-muted">' + alert.time + '</small></div>' +
                    '<small>' + alert.message + '</small>' +
                    (alert.client ? '<br><small class="text-muted">Client: ' + alert.client + '</small>' : '') +
                    '</div>';
            });
            container.innerHTML = html || '<div class="text-center text-muted py-3"><i class="fas fa-check-circle text-success fa-2x mb-2"></i><br>No active alerts</div>';
            
            document.getElementById('alertCountBadge').textContent = data.total_critical + data.total_warnings;
            document.getElementById('alertCountBadge').className = 'badge badge-' + (data.total_critical > 0 ? 'danger' : 'warning');
        })
        .catch(e => console.log('Live alerts update failed'));
}

function updateLivePayments() {
    fetch('/admin/api/live-payments')
        .then(r => r.json())
        .then(data => {
            var container = document.getElementById('livePaymentsContainer');
            if(!container) return;
            
            var html = '<table class="table table-sm table-hover mb-0"><tbody>';
            data.recent_payments.slice(0, 6).forEach(function(payment) {
                html += '<tr>' +
                    '<td><strong>' + payment.client_name + '</strong><br><small class="text-muted">' + payment.client_id + '</small></td>' +
                    '<td class="text-right"><span class="text-success font-weight-bold">' + payment.amount_formatted + '</span><br><small class="text-muted">' + payment.method + '</small></td>' +
                    '<td class="text-right">' +
                        '<small class="text-primary">' + payment.submit_date + ' ' + payment.submit_time + '</small><br>' +
                        '<small class="text-muted">By: ' + payment.submitted_by + '</small>' +
                    '</td>' +
                    '</tr>';
            });
            html += '</tbody></table>';
            container.innerHTML = html;
            
            document.getElementById('liveTodayCollectionTotal').textContent = '৳' + Number(data.today_total).toLocaleString();
            document.getElementById('liveTodayPaymentCount').textContent = data.today_count + ' payments';
        })
        .catch(e => console.log('Live payments update failed'));
}

function updateNetworkStatus() {
    fetch('/admin/api/live-network')
        .then(r => r.json())
        .then(data => {
            var container = document.getElementById('networkDevicesContainer');
            if(!container) return;
            
            var html = '';
            data.devices.slice(0, 6).forEach(function(device) {
                var statusClass = device.status === 'online' ? 'success' : 'danger';
                var statusIcon = device.status === 'online' ? 'check-circle' : 'times-circle';
                html += '<div class="d-flex justify-content-between align-items-center border-bottom py-2">' +
                    '<div><i class="fas fa-' + statusIcon + ' text-' + statusClass + ' mr-2"></i>' + device.name + '</div>' +
                    '<div class="text-right"><small class="badge badge-light">' + device.clients_online + '/' + device.clients_total + ' clients</small></div>' +
                    '</div>';
            });
            container.innerHTML = html || '<div class="text-center text-muted py-3">No devices configured</div>';
            
            document.getElementById('routersOnline').textContent = data.total_online;
            document.getElementById('routersOffline').textContent = data.total_offline;
        })
        .catch(e => console.log('Network status update failed'));
}

function animateNumber(elementId, newValue) {
    var el = document.getElementById(elementId);
    if(!el) return;
    var current = parseInt(el.textContent) || 0;
    if(current !== newValue) {
        el.textContent = newValue;
        el.classList.add('number-change');
        setTimeout(function() { el.classList.remove('number-change'); }, 500);
    }
}

updateLiveStats();
updateLiveAlerts();
updateLivePayments();
updateNetworkStatus();

setInterval(updateLiveStats, 5000);
setInterval(updateLiveAlerts, 15000);
setInterval(updateLivePayments, 10000);
setInterval(updateNetworkStatus, 30000);
</script>

<style>
.live-pulse { animation: pulse 2s infinite; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
.number-change { animation: highlight 0.5s ease; }
@keyframes highlight { 0% { background: #ffc107; } 100% { background: transparent; } }
.health-score-circle { width: 120px; height: 120px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold; }
.grade-a { background: linear-gradient(135deg, #38a169, #48bb78); color: white; }
.grade-b { background: linear-gradient(135deg, #3182ce, #4299e1); color: white; }
.grade-c { background: linear-gradient(135deg, #d69e2e, #ecc94b); color: white; }
.grade-d { background: linear-gradient(135deg, #e53e3e, #fc8181); color: white; }
.callout { border-radius: 4px; }
</style>
@endpush
