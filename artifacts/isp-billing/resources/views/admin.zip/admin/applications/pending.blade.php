@extends('layouts.admin')

@section('title', 'Pending Applications')

@section('content')
<style>
.app-card { border-left: 4px solid #ffc107; margin-bottom: 12px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.app-card.status-submitted { border-left-color: #007bff; }
.app-card.status-under_review { border-left-color: #ffc107; }
.app-card .card-body { padding: 12px 15px; }
.app-card .app-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
.app-card .app-name { font-weight: 600; font-size: 15px; color: #333; margin: 0; }
.app-card .app-info { font-size: 13px; color: #666; margin-bottom: 5px; }
.app-card .app-meta { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; font-size: 12px; }
.app-card .btn-group-mobile { display: flex; flex-wrap: wrap; gap: 6px; }
.app-card .btn-group-mobile .btn { flex: 1; min-width: 70px; font-size: 13px; padding: 6px 10px; }
@media (min-width: 768px) { .mobile-cards { display: none; } }
@media (max-width: 767px) { .desktop-table { display: none; } .info-box { margin-bottom: 10px; } }
</style>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-6">
                <h1 class="m-0"><i class="fas fa-clock text-warning"></i> Pending</h1>
            </div>
            <div class="col-6 text-right">
                <a href="{{ route('admin.applications.index') }}" class="btn btn-secondary btn-sm">
                    <i class="fas fa-list"></i> All
                </a>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
                    <div class="stat-number">{{ $stats['submitted'] }}</div>
                    <div class="stat-label">Submitted</div>
                </div>
            </div>
            <div class="col-6 col-md-3 mb-2">
                <div class="stat-box bg-warning text-dark text-center py-3 rounded h-100">
                    <div class="stat-number">{{ $stats['under_review'] }}</div>
                    <div class="stat-label">Review</div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Applications Waiting for Review</h3>
            </div>
            <div class="card-body">
                <div class="mobile-cards">
                    @forelse($applications as $app)
                    <div class="card app-card status-{{ $app->status }}">
                        <div class="card-body">
                            <div class="app-header">
                                <h6 class="app-name">{{ $app->full_name_english }}</h6>
                                <span class="badge {{ $app->status_badge_class }}">{{ $app->status_label }}</span>
                            </div>
                            <div class="app-info">
                                <strong>#{{ $app->application_number }}</strong> | {{ $app->mobile_number }}
                            </div>
                            <div class="app-meta">
                                <span><i class="fas fa-box mr-1"></i>{{ $app->package?->name ?? '-' }}</span>
                                <span><i class="fas fa-map-marker-alt mr-1"></i>{{ $app->zone?->name ?? '-' }}</span>
                                <span><i class="fas fa-clock mr-1"></i>{{ $app->created_at->diffForHumans() }}</span>
                            </div>
                            @if($app->technician)
                            <div class="app-info"><i class="fas fa-user-cog mr-1"></i>{{ $app->technician->name }}</div>
                            @endif
                            <div class="btn-group-mobile">
                                <a href="{{ route('admin.applications.show', $app) }}" class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye mr-1"></i> Review
                                </a>
                                <a href="tel:{{ $app->mobile_number }}" class="btn btn-success btn-sm">
                                    <i class="fas fa-phone mr-1"></i> Call
                                </a>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <p class="text-muted">No pending applications</p>
                    </div>
                    @endforelse
                </div>

                <div class="desktop-table">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Application #</th>
                                    <th>Customer</th>
                                    <th>Mobile</th>
                                    <th>Package</th>
                                    <th>Zone</th>
                                    <th>Technician</th>
                                    <th>Status</th>
                                    <th>Submitted</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($applications as $app)
                                <tr>
                                    <td><strong>{{ $app->application_number }}</strong></td>
                                    <td>{{ $app->full_name_english }}</td>
                                    <td>{{ $app->mobile_number }}</td>
                                    <td>{{ $app->package?->name ?? '-' }}</td>
                                    <td>{{ $app->zone?->name ?? '-' }}</td>
                                    <td>{{ $app->technician?->name ?? '-' }}</td>
                                    <td><span class="badge {{ $app->status_badge_class }}">{{ $app->status_label }}</span></td>
                                    <td>{{ $app->created_at->diffForHumans() }}</td>
                                    <td>
                                        <a href="{{ route('admin.applications.show', $app) }}" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> Review
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="9" class="text-center py-4">
                                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                        <p class="text-muted">No pending applications</p>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                {{ $applications->links() }}
            </div>
        </div>
    </div>
</section>
@endsection
