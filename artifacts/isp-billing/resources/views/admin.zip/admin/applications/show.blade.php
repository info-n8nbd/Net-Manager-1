@extends('layouts.admin')

@section('title', 'Application Details')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Application: {{ $application->application_number }}</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.applications.index') }}">Applications</a></li>
                    <li class="breadcrumb-item active">{{ $application->application_number }}</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            {{ session('success') }}
        </div>
        @endif
        @if(session('error'))
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            {{ session('error') }}
        </div>
        @endif

        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Application Status</h3>
                        <span class="badge {{ $application->status_badge_class }} float-right" style="font-size: 1em;">{{ $application->status_label }}</span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Personal Information</h5>
                                <table class="table table-sm table-bordered">
                                    <tr><th width="40%">Application #</th><td>{{ $application->application_number }}</td></tr>
                                    <tr><th>Full Name (EN)</th><td>{{ $application->full_name_english }}</td></tr>
                                    <tr><th>Full Name (BN)</th><td>{{ $application->full_name_bangla }}</td></tr>
                                    <tr><th>Father/Husband</th><td>{{ $application->father_husband_name ?? '-' }}</td></tr>
                                    <tr><th>Mother</th><td>{{ $application->mother_name ?? '-' }}</td></tr>
                                    <tr><th>Date of Birth</th><td>{{ $application->date_of_birth?->format('d M Y') ?? '-' }}</td></tr>
                                    <tr><th>Gender</th><td>{{ ucfirst($application->gender) }}</td></tr>
                                    <tr><th>Mobile</th><td>{{ $application->mobile_number }}</td></tr>
                                    <tr><th>Alt Mobile</th><td>{{ $application->alternative_mobile ?? '-' }}</td></tr>
                                    <tr><th>Email</th><td>{{ $application->email ?? '-' }}</td></tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h5>Connection Details</h5>
                                <table class="table table-sm table-bordered">
                                    <tr><th width="40%">Type</th><td>{{ ucfirst($application->connection_type) }}</td></tr>
                                    <tr><th>Package</th><td>{{ $application->package?->name ?? '-' }}</td></tr>
                                    <tr><th>Zone</th><td>{{ $application->zone?->name ?? '-' }}</td></tr>
                                    <tr><th>IP Type</th><td>{{ ucfirst($application->ip_type) }}</td></tr>
                                    <tr><th>Billing Cycle</th><td>{{ ucfirst(str_replace('_', ' ', $application->billing_cycle)) }}</td></tr>
                                    <tr><th>Installation Charge</th><td>৳{{ number_format($application->installation_charge) }}</td></tr>
                                    <tr><th>ONU Required</th><td>{{ $application->onu_required ? 'Yes' : 'No' }}</td></tr>
                                    <tr><th>Router Required</th><td>{{ $application->router_required ? 'Yes' : 'No' }}</td></tr>
                                    <tr><th>Cable Length</th><td>{{ $application->cable_length_meters ?? '-' }} meters</td></tr>
                                </table>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h5>Address</h5>
                                <table class="table table-sm table-bordered">
                                    <tr>
                                        <th width="15%">Division</th><td>{{ $application->division ?? '-' }}</td>
                                        <th width="15%">District</th><td>{{ $application->district ?? '-' }}</td>
                                        <th width="15%">Thana</th><td>{{ $application->thana_upazila ?? '-' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Address</th><td colspan="5">{{ $application->house_road_floor ?? '-' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Landmark</th><td colspan="2">{{ $application->nearby_landmark ?? '-' }}</td>
                                        <th>GPS</th><td colspan="2">{{ $application->latitude }}, {{ $application->longitude }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-danger">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-id-card"></i> NID Verification</h3>
                        <span class="badge badge-{{ $application->nid_verification_status == 'verified' ? 'success' : ($application->nid_verification_status == 'rejected' ? 'danger' : 'warning') }} float-right">
                            {{ ucfirst($application->nid_verification_status) }}
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>NID Number:</strong> {{ $application->nid_number }}
                            </div>
                            <div class="col-md-4">
                                <h6>NID Front</h6>
                                @if($application->nid_front_image)
                                <a href="{{ asset('storage/' . $application->nid_front_image) }}" target="_blank">
                                    <img src="{{ asset('storage/' . $application->nid_front_image) }}" class="img-fluid img-thumbnail" style="max-height: 150px;">
                                </a>
                                @else
                                <p class="text-muted">Not uploaded</p>
                                @endif
                            </div>
                            <div class="col-md-4">
                                <h6>NID Back</h6>
                                @if($application->nid_back_image)
                                <a href="{{ asset('storage/' . $application->nid_back_image) }}" target="_blank">
                                    <img src="{{ asset('storage/' . $application->nid_back_image) }}" class="img-fluid img-thumbnail" style="max-height: 150px;">
                                </a>
                                @else
                                <p class="text-muted">Not uploaded</p>
                                @endif
                            </div>
                        </div>
                        @if($application->nid_verification_status == 'pending' && $application->canBeApproved())
                        <hr>
                        <form action="{{ route('admin.applications.verify-nid', $application) }}" method="POST" class="form-inline">
                            @csrf
                            <select name="verification_status" class="form-control mr-2" required>
                                <option value="verified">Verify NID</option>
                                <option value="rejected">Reject NID</option>
                            </select>
                            <input type="text" name="verification_note" class="form-control mr-2" placeholder="Note (optional)">
                            <button type="submit" class="btn btn-primary">Update NID Status</button>
                        </form>
                        @endif
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-history"></i> Status History</h3>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Action</th>
                                    <th>By</th>
                                    <th>Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($application->statusLogs as $log)
                                <tr>
                                    <td>{{ $log->created_at->format('d M Y H:i') }}</td>
                                    <td>{{ $log->action_label }}</td>
                                    <td>{{ $log->changedByUser?->name ?? 'System' }}</td>
                                    <td>{{ Str::limit($log->note, 80) }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                @if($application->canBeApproved())
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-check-circle"></i> Admin Actions</h3>
                    </div>
                    <div class="card-body">
                        @if($application->status == 'submitted')
                        <form action="{{ route('admin.applications.under-review', $application) }}" method="POST" class="mb-3">
                            @csrf
                            <button type="submit" class="btn btn-info btn-block">
                                <i class="fas fa-search"></i> Take Under Review
                            </button>
                        </form>
                        @endif

                        <form action="{{ route('admin.applications.approve', $application) }}" method="POST" class="mb-3">
                            @csrf
                            <div class="form-group">
                                <label>PPPoE Username <span class="text-danger">*</span></label>
                                <input type="text" name="username" class="form-control" value="{{ strtolower(preg_replace('/[^a-zA-Z]/', '', $application->full_name_english)) }}" required>
                                <small class="text-muted">e.g. masud42</small>
                            </div>
                            <div class="form-group">
                                <label>PPPoE Password <span class="text-danger">*</span></label>
                                <input type="text" name="password" class="form-control" value="{{ rand(1000, 9999) }}" required>
                                <small class="text-muted">e.g. 42</small>
                            </div>
                            <div class="form-group">
                                <label>Admin Note (Optional)</label>
                                <textarea name="admin_note" class="form-control" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn btn-success btn-block" onclick="return confirm('Approve this application? This will create a new client and MikroTik user.')">
                                <i class="fas fa-check"></i> Approve Application
                            </button>
                        </form>

                        <hr>

                        <form action="{{ route('admin.applications.request-correction', $application) }}" method="POST" class="mb-3">
                            @csrf
                            <div class="form-group">
                                <label>Correction Required</label>
                                <textarea name="correction_note" class="form-control" rows="2" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-warning btn-block">
                                <i class="fas fa-edit"></i> Request Correction
                            </button>
                        </form>

                        <hr>

                        <form action="{{ route('admin.applications.reject', $application) }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label>Rejection Reason</label>
                                <textarea name="rejection_reason" class="form-control" rows="2" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-danger btn-block" onclick="return confirm('Reject this application?')">
                                <i class="fas fa-times"></i> Reject Application
                            </button>
                        </form>
                    </div>
                </div>
                @endif

                @if($application->status == 'approved')
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-check-circle"></i> Approval Details</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Approved By:</strong> {{ $application->approver?->name }}</p>
                        <p><strong>Approved At:</strong> {{ $application->approved_at?->format('d M Y H:i') }}</p>
                        @if($application->admin_note)
                        <p><strong>Admin Note:</strong> {{ $application->admin_note }}</p>
                        @endif
                        <hr>
                        @if($application->createdClient)
                        <p><strong>Client ID:</strong> 
                            <a href="{{ route('admin.clients.show', $application->createdClient) }}">{{ $application->createdClient->client_id }}</a>
                        </p>
                        @endif
                        @if($application->mikrotik_created)
                        <p><strong>MikroTik User:</strong> {{ $application->mikrotik_username }}</p>
                        <p><strong>Device:</strong> {{ $application->mikrotikDevice?->name }}</p>
                        @else
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> MikroTik user not created
                        </div>
                        @endif
                    </div>
                </div>
                @endif

                @if($application->status == 'rejected')
                <div class="card card-danger">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-times-circle"></i> Rejection Details</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Rejected By:</strong> {{ $application->reviewer?->name }}</p>
                        <p><strong>Rejected At:</strong> {{ $application->reviewed_at?->format('d M Y H:i') }}</p>
                        <p><strong>Reason:</strong> {{ $application->rejection_reason }}</p>
                    </div>
                </div>
                @endif

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-user-cog"></i> Technician Info</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Technician:</strong> {{ $application->technician?->name }}</p>
                        <p><strong>Submitted:</strong> {{ $application->created_at->format('d M Y H:i') }}</p>
                        <p><strong>Feasibility:</strong> 
                            @if($application->installation_feasibility)
                            <span class="badge badge-success">Feasible</span>
                            @else
                            <span class="badge badge-danger">Not Feasible</span>
                            @endif
                        </p>
                        @if($application->technician_note)
                        <p><strong>Note:</strong> {{ $application->technician_note }}</p>
                        @endif
                    </div>
                </div>

                <a href="{{ route('admin.applications.edit', $application) }}" class="btn btn-warning btn-block">
                    <i class="fas fa-edit"></i> Edit Application
                </a>
            </div>
        </div>
    </div>
</section>
@endsection
