@extends('layouts.admin')

@section('title', 'Edit Application')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Edit Application: {{ $application->application_number }}</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.applications.index') }}">Applications</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <form action="{{ route('admin.applications.update', $application) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-user"></i> Personal Information</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Full Name (Bangla) <span class="text-danger">*</span></label>
                                        <input type="text" name="full_name_bangla" class="form-control" value="{{ old('full_name_bangla', $application->full_name_bangla) }}" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Full Name (English) <span class="text-danger">*</span></label>
                                        <input type="text" name="full_name_english" class="form-control" value="{{ old('full_name_english', $application->full_name_english) }}" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Father/Husband Name</label>
                                        <input type="text" name="father_husband_name" class="form-control" value="{{ old('father_husband_name', $application->father_husband_name) }}">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Mother Name</label>
                                        <input type="text" name="mother_name" class="form-control" value="{{ old('mother_name', $application->mother_name) }}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Date of Birth</label>
                                        <input type="date" name="date_of_birth" class="form-control" value="{{ old('date_of_birth', $application->date_of_birth?->format('Y-m-d')) }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <select name="gender" class="form-control">
                                            <option value="male" {{ old('gender', $application->gender) == 'male' ? 'selected' : '' }}>Male</option>
                                            <option value="female" {{ old('gender', $application->gender) == 'female' ? 'selected' : '' }}>Female</option>
                                            <option value="other" {{ old('gender', $application->gender) == 'other' ? 'selected' : '' }}>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" value="{{ old('email', $application->email) }}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Mobile Number <span class="text-danger">*</span></label>
                                        <input type="text" name="mobile_number" class="form-control" value="{{ old('mobile_number', $application->mobile_number) }}" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Alternative Mobile</label>
                                        <input type="text" name="alternative_mobile" class="form-control" value="{{ old('alternative_mobile', $application->alternative_mobile) }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-map-marker-alt"></i> Address Information</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Division</label>
                                        <input type="text" name="division" class="form-control" value="{{ old('division', $application->division) }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>District</label>
                                        <input type="text" name="district" class="form-control" value="{{ old('district', $application->district) }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Thana/Upazila</label>
                                        <input type="text" name="thana_upazila" class="form-control" value="{{ old('thana_upazila', $application->thana_upazila) }}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Zone</label>
                                        <select name="zone_id" class="form-control">
                                            <option value="">Select Zone</option>
                                            @foreach($zones as $zone)
                                            <option value="{{ $zone->id }}" {{ old('zone_id', $application->zone_id) == $zone->id ? 'selected' : '' }}>{{ $zone->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>House/Road/Floor</label>
                                <textarea name="house_road_floor" class="form-control" rows="2">{{ old('house_road_floor', $application->house_road_floor) }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-wifi"></i> Connection Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Connection Type</label>
                                <select name="connection_type" class="form-control">
                                    <option value="home" {{ old('connection_type', $application->connection_type) == 'home' ? 'selected' : '' }}>Home</option>
                                    <option value="corporate" {{ old('connection_type', $application->connection_type) == 'corporate' ? 'selected' : '' }}>Corporate</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Package</label>
                                <select name="package_id" class="form-control">
                                    <option value="">Select Package</option>
                                    @foreach($packages as $package)
                                    <option value="{{ $package->id }}" {{ old('package_id', $application->package_id) == $package->id ? 'selected' : '' }}>
                                        {{ $package->name }} - ৳{{ number_format($package->price) }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Billing Cycle</label>
                                <select name="billing_cycle" class="form-control">
                                    <option value="monthly" {{ old('billing_cycle', $application->billing_cycle) == 'monthly' ? 'selected' : '' }}>Monthly</option>
                                    <option value="quarterly" {{ old('billing_cycle', $application->billing_cycle) == 'quarterly' ? 'selected' : '' }}>Quarterly</option>
                                    <option value="half_yearly" {{ old('billing_cycle', $application->billing_cycle) == 'half_yearly' ? 'selected' : '' }}>Half Yearly</option>
                                    <option value="yearly" {{ old('billing_cycle', $application->billing_cycle) == 'yearly' ? 'selected' : '' }}>Yearly</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Installation Charge</label>
                                <input type="number" name="installation_charge" class="form-control" value="{{ old('installation_charge', $application->installation_charge) }}">
                            </div>
                            <div class="form-group">
                                <label>IP Type</label>
                                <select name="ip_type" class="form-control">
                                    <option value="dynamic" {{ old('ip_type', $application->ip_type) == 'dynamic' ? 'selected' : '' }}>Dynamic</option>
                                    <option value="static" {{ old('ip_type', $application->ip_type) == 'static' ? 'selected' : '' }}>Static</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>MikroTik Device</label>
                                <select name="mikrotik_device_id" class="form-control">
                                    <option value="">Auto Select</option>
                                    @foreach($mikrotikDevices as $device)
                                    <option value="{{ $device->id }}" {{ old('mikrotik_device_id', $application->mikrotik_device_id) == $device->id ? 'selected' : '' }}>{{ $device->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-sticky-note"></i> Admin Note</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <textarea name="admin_note" class="form-control" rows="3">{{ old('admin_note', $application->admin_note) }}</textarea>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <i class="fas fa-save"></i> Update Application
                    </button>
                    <a href="{{ route('admin.applications.show', $application) }}" class="btn btn-secondary btn-block">
                        Cancel
                    </a>
                </div>
            </div>
        </form>
    </div>
</section>
@endsection
