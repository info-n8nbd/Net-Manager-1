@extends('layouts.admin')

@section('title', 'Resellers')
@section('breadcrumb')
<li class="breadcrumb-item active">Resellers</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-store mr-2"></i>Resellers</h3>
        <div class="card-tools">
            <a href="{{ route('admin.reseller.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Reseller</a>
        </div>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Phone</th>
                    <th>Type</th>
                    <th>Commission</th>
                    <th>Wallet</th>
                    <th>Clients</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($resellers as $reseller)
                <tr>
                    <td><code>{{ $reseller->reseller_id }}</code></td>
                    <td>
                        <a href="{{ route('admin.reseller.show', $reseller) }}">{{ $reseller->name }}</a>
                    </td>
                    <td>{{ $reseller->email ?? '-' }}</td>
                    <td>{{ $reseller->company_name ?? '-' }}</td>
                    <td>{{ $reseller->phone }}</td>
                    <td><span class="badge badge-info">{{ ucfirst($reseller->type) }}</span></td>
                    <td>{{ $reseller->commission_rate }}%</td>
                    <td class="text-success">৳{{ number_format($reseller->wallet_balance, 2) }}</td>
                    <td><span class="badge badge-secondary">{{ $reseller->clients_count ?? 0 }}</span></td>
                    <td>
                        <span class="badge badge-{{ $reseller->status == 'active' ? 'success' : 'danger' }}">
                            {{ ucfirst($reseller->status) }}
                        </span>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <a href="{{ route('admin.reseller.show', $reseller) }}" class="btn btn-info" title="View">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="{{ route('admin.reseller.edit', $reseller) }}" class="btn btn-warning" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="{{ route('admin.reseller.wallet', $reseller) }}" class="btn btn-success" title="Wallet">
                                <i class="fas fa-wallet"></i>
                            </a>
                            <form action="{{ route('admin.reseller.destroy', $reseller) }}" method="POST" style="display:inline" onsubmit="return confirm('Are you sure you want to delete this reseller?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="11" class="text-center text-muted py-4">No resellers found</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        {{ $resellers->links() }}
    </div>
</div>
@endsection
