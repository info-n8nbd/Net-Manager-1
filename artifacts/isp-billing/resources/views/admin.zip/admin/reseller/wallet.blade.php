@extends('layouts.admin')

@section('title', 'Wallet - ' . $reseller->name)

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Reseller Wallet</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.reseller.index') }}">Resellers</a></li>
                    <li class="breadcrumb-item active">Wallet</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">{{ $reseller->name }}</h3>
                    </div>
                    <div class="card-body text-center">
                        <h3>Wallet Balance</h3>
                        <h1 class="{{ $reseller->wallet_balance >= 0 ? 'text-success' : 'text-danger' }}">
                            ৳{{ number_format($reseller->wallet_balance, 2) }}
                        </h1>
                        <p class="text-muted">
                            Credit Limit: ৳{{ number_format($reseller->credit_limit, 2) }}<br>
                            Available Credit: ৳{{ number_format($reseller->credit_limit + $reseller->wallet_balance, 2) }}
                        </p>
                    </div>
                </div>

                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title">Credit Wallet</h3>
                    </div>
                    <form action="{{ route('admin.reseller.wallet.credit', $reseller) }}" method="POST">
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label>Amount (৳)</label>
                                <input type="number" name="amount" class="form-control" step="0.01" min="1" required>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description" class="form-control" required placeholder="e.g., Advance payment">
                            </div>
                            <div class="form-group">
                                <label>Reference (Optional)</label>
                                <input type="text" name="reference" class="form-control" placeholder="e.g., Bank transaction ID">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-success btn-block">
                                <i class="fas fa-plus"></i> Credit Wallet
                            </button>
                        </div>
                    </form>
                </div>

                <div class="card card-danger">
                    <div class="card-header">
                        <h3 class="card-title">Debit Wallet</h3>
                    </div>
                    <form action="{{ route('admin.reseller.wallet.debit', $reseller) }}" method="POST">
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label>Amount (৳)</label>
                                <input type="number" name="amount" class="form-control" step="0.01" min="1" required>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description" class="form-control" required placeholder="e.g., Monthly bill">
                            </div>
                            <div class="form-group">
                                <label>Reference (Optional)</label>
                                <input type="text" name="reference" class="form-control" placeholder="e.g., Invoice number">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-danger btn-block">
                                <i class="fas fa-minus"></i> Debit Wallet
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Transaction History</h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Description</th>
                                    <th>Reference</th>
                                    <th class="text-right">Amount</th>
                                    <th class="text-right">Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($transactions as $transaction)
                                    <tr>
                                        <td>{{ $transaction->created_at->format('d M Y H:i') }}</td>
                                        <td>
                                            <span class="badge badge-{{ $transaction->type === 'credit' ? 'success' : 'danger' }}">
                                                {{ ucfirst($transaction->type) }}
                                            </span>
                                        </td>
                                        <td>{{ $transaction->description }}</td>
                                        <td>{{ $transaction->reference ?? '-' }}</td>
                                        <td class="text-right {{ $transaction->type === 'credit' ? 'text-success' : 'text-danger' }}">
                                            {{ $transaction->type === 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                                        </td>
                                        <td class="text-right">৳{{ number_format($transaction->balance_after, 2) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No transactions found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    @if($transactions->hasPages())
                    <div class="card-footer">
                        {{ $transactions->links() }}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
