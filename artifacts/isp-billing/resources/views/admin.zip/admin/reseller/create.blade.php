@extends('layouts.admin')

@section('title', 'Add Reseller')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.reseller.index') }}">Resellers</a></li>
<li class="breadcrumb-item active">Add</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title"><i class="fas fa-user-plus mr-2"></i>Add New Reseller</h3></div>
    <form action="{{ route('admin.reseller.store') }}" method="POST">
        @csrf
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-outline card-primary">
                        <div class="card-header"><h5 class="mb-0">Login Credentials</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Email (Login Username) <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required>
                                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="form-group">
                                <label>Password <span class="text-danger">*</span></label>
                                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" required minlength="6">
                                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                                <small class="text-muted">Minimum 6 characters</small>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password <span class="text-danger">*</span></label>
                                <input type="password" name="password_confirmation" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required>
                        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="form-group">
                        <label>Company Name</label>
                        <input type="text" name="company_name" class="form-control" value="{{ old('company_name') }}">
                    </div>
                    <div class="form-group">
                        <label>Phone <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone') }}" required>
                        @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="form-group">
                        <label>NID Number</label>
                        <input type="text" name="nid" class="form-control" value="{{ old('nid') }}">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Type <span class="text-danger">*</span></label>
                        <select name="type" class="form-control" required>
                            <option value="mac" {{ old('type') == 'mac' ? 'selected' : '' }}>MAC Binding</option>
                            <option value="bandwidth" {{ old('type') == 'bandwidth' ? 'selected' : '' }}>Bandwidth</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Billing Type</label>
                        <select name="billing_type" class="form-control">
                            <option value="prepaid" {{ old('billing_type') == 'prepaid' ? 'selected' : '' }}>Prepaid</option>
                            <option value="postpaid" {{ old('billing_type') == 'postpaid' ? 'selected' : '' }}>Postpaid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Commission Rate (%)</label>
                        <input type="number" name="commission_rate" class="form-control" value="{{ old('commission_rate', 10) }}" step="0.01" min="0" max="100">
                    </div>
                    <div class="form-group">
                        <label>Credit Limit (৳)</label>
                        <input type="number" name="credit_limit" class="form-control" value="{{ old('credit_limit', 0) }}" step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="4">{{ old('address') }}</textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Save Reseller</button>
            <a href="{{ route('admin.reseller.index') }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
@endsection
