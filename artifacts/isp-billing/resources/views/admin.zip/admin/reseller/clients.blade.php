@extends('layouts.admin')

@section('title', 'Reseller Clients')
@section('breadcrumb')
<li class="breadcrumb-item active">Reseller Clients</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Reseller Clients</h3></div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead><tr><th>Client</th><th>Reseller</th><th>Zone</th><th>Package</th><th>Due (৳)</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($clients as $client)
                <tr>
                    <td>{{ $client->name }}</td>
                    <td>{{ $client->reseller->name ?? 'N/A' }}</td>
                    <td>{{ $client->zone->name ?? '-' }}</td>
                    <td>{{ $client->package->name ?? '-' }}</td>
                    <td>{{ number_format($client->due_amount, 2) }}</td>
                    <td><span class="badge badge-{{ $client->status == 'active' ? 'success' : 'danger' }}">{{ ucfirst($client->status) }}</span></td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">No reseller clients</td></tr>
                @endforelse
            </tbody>
        </table>
        {{ $clients->links() }}
    </div>
</div>
@endsection
