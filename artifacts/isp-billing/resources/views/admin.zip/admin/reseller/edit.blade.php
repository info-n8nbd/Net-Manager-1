@extends('layouts.admin')

@section('title', 'Edit Reseller')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.reseller.index') }}">Resellers</a></li>
<li class="breadcrumb-item active">Edit</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title"><i class="fas fa-edit mr-2"></i>Edit Reseller: {{ $reseller->name }}</h3></div>
    <form action="{{ route('admin.reseller.update', $reseller) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-outline card-{{ $reseller->user ? 'info' : 'warning' }}">
                        <div class="card-header">
                            <h5 class="mb-0">Login Credentials</h5>
                            @if(!$reseller->user)
                            <small class="text-warning">No login account exists - password is required</small>
                            @endif
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Email (Login Username) <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', $reseller->email) }}" required>
                                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="form-group">
                                <label>{{ $reseller->user ? 'New Password' : 'Password' }} @if(!$reseller->user)<span class="text-danger">*</span>@endif</label>
                                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" minlength="6" {{ $reseller->user ? '' : 'required' }}>
                                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                                <small class="text-muted">{{ $reseller->user ? 'Leave blank to keep current password' : 'Required - minimum 6 characters' }}</small>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password @if(!$reseller->user)<span class="text-danger">*</span>@endif</label>
                                <input type="password" name="password_confirmation" class="form-control" {{ $reseller->user ? '' : 'required' }}>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $reseller->name) }}" required>
                        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="form-group">
                        <label>Company Name</label>
                        <input type="text" name="company_name" class="form-control" value="{{ old('company_name', $reseller->company_name) }}">
                    </div>
                    <div class="form-group">
                        <label>Phone <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone', $reseller->phone) }}" required>
                        @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="form-group">
                        <label>NID Number</label>
                        <input type="text" name="nid" class="form-control" value="{{ old('nid', $reseller->nid) }}">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Reseller ID</label>
                        <input type="text" class="form-control" value="{{ $reseller->reseller_id }}" readonly disabled>
                    </div>
                    <div class="form-group">
                        <label>Type <span class="text-danger">*</span></label>
                        <select name="type" class="form-control" required>
                            <option value="mac" {{ old('type', $reseller->type) == 'mac' ? 'selected' : '' }}>MAC Binding</option>
                            <option value="bandwidth" {{ old('type', $reseller->type) == 'bandwidth' ? 'selected' : '' }}>Bandwidth</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Billing Type</label>
                        <select name="billing_type" class="form-control">
                            <option value="prepaid" {{ old('billing_type', $reseller->billing_type) == 'prepaid' ? 'selected' : '' }}>Prepaid</option>
                            <option value="postpaid" {{ old('billing_type', $reseller->billing_type) == 'postpaid' ? 'selected' : '' }}>Postpaid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Commission Rate (%)</label>
                        <input type="number" name="commission_rate" class="form-control" value="{{ old('commission_rate', $reseller->commission_rate) }}" step="0.01" min="0" max="100">
                    </div>
                    <div class="form-group">
                        <label>Credit Limit (৳)</label>
                        <input type="number" name="credit_limit" class="form-control" value="{{ old('credit_limit', $reseller->credit_limit) }}" step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="active" {{ old('status', $reseller->status) == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ old('status', $reseller->status) == 'inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="4">{{ old('address', $reseller->address) }}</textarea>
                    </div>
                </div>
            </div>
            
            <div class="card card-warning card-outline mt-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-shield-alt mr-2"></i>Access Control Permissions</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted mb-3">Select which features this reseller can access:</p>
                    
                    @php
                        $resellerPermissions = [
                            'reseller.dashboard' => ['label' => 'Dashboard', 'icon' => 'fa-tachometer-alt', 'desc' => 'View dashboard statistics'],
                            'reseller.clients' => ['label' => 'My Clients', 'icon' => 'fa-users', 'desc' => 'View and manage assigned clients'],
                            'reseller.wallet' => ['label' => 'Wallet', 'icon' => 'fa-wallet', 'desc' => 'View wallet balance and transactions'],
                            'reseller.packages' => ['label' => 'My Packages', 'icon' => 'fa-box', 'desc' => 'View available packages and pricing'],
                            'reseller.collection' => ['label' => 'Collection Report', 'icon' => 'fa-chart-line', 'desc' => 'View collection reports'],
                            'reseller.due_report' => ['label' => 'Due Report', 'icon' => 'fa-exclamation-triangle', 'desc' => 'View client dues'],
                            'reseller.tickets' => ['label' => 'Tickets', 'icon' => 'fa-ticket-alt', 'desc' => 'View and manage support tickets'],
                        ];
                        $userPermissions = $reseller->user ? $reseller->user->permissions->pluck('name')->toArray() : [];
                    @endphp
                    
                    <div class="row">
                        @foreach($resellerPermissions as $permName => $perm)
                        <div class="col-md-6 mb-3">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="perm_{{ str_replace('.', '_', $permName) }}" 
                                       name="permissions[]" value="{{ $permName }}"
                                       {{ in_array($permName, old('permissions', $userPermissions)) ? 'checked' : '' }}>
                                <label class="custom-control-label" for="perm_{{ str_replace('.', '_', $permName) }}">
                                    <i class="fas {{ $perm['icon'] }} mr-1 text-warning"></i> {{ $perm['label'] }}
                                </label>
                                <br><small class="text-muted ml-4">{{ $perm['desc'] }}</small>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    
                    <div class="mt-3">
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="$('input[name=\'permissions[]\']').prop('checked', true)">
                            <i class="fas fa-check-double mr-1"></i>Select All
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="$('input[name=\'permissions[]\']').prop('checked', false)">
                            <i class="fas fa-times mr-1"></i>Deselect All
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Update Reseller</button>
            <a href="{{ route('admin.reseller.index') }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
@endsection
