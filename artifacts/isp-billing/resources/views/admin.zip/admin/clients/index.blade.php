@extends('layouts.admin')

@section('title', 'Client List')
@section('breadcrumb')
<li class="breadcrumb-item active">Clients</li>
@endsection

@push('styles')
<style>
.stats-summary {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
    flex-wrap: wrap;
}
.stats-summary .stat-item {
    font-size: 13px;
}
.stats-summary .stat-label {
    font-weight: 600;
}
.stats-summary .stat-value {
    font-weight: bold;
}
.filter-buttons {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.filter-buttons .btn {
    padding: 5px 10px;
    font-size: 12px;
}
.table thead th {
    background: #3c8dbc;
    color: white;
    font-weight: 500;
    font-size: 12px;
    white-space: nowrap;
}
.table td {
    font-size: 13px;
    vertical-align: middle;
}
.action-btns .btn {
    width: 26px;
    height: 26px;
    padding: 0;
    margin: 1px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
}
.status-badge {
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: 500;
}
.client-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.client-card .client-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 10px;
}
.client-card .client-name {
    font-weight: 700;
    font-size: 16px;
    color: #1a202c;
}
.client-card .client-id {
    font-size: 12px;
    color: #718096;
    margin-top: 3px;
}
.client-card .client-info {
    font-size: 13px;
    color: #4a5568;
    line-height: 1.7;
    margin-bottom: 12px;
}
.client-card .client-info strong {
    color: #2d3748;
    font-weight: 600;
}
.client-card .client-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.client-card .client-actions .btn {
    flex: 1;
    min-width: 70px;
    font-size: 11px;
    padding: 6px 8px;
}
.mobile-cards {
    display: none;
}
.search-form-mobile {
    display: none;
}
@media (max-width: 991px) {
    .table-responsive {
        display: none;
    }
    .mobile-cards {
        display: block;
    }
    .search-form-mobile {
        display: block;
        margin-bottom: 15px;
    }
    .search-form-desktop {
        display: none;
    }
    .filter-buttons {
        width: 100%;
        justify-content: flex-start;
    }
    .filter-buttons .btn {
        flex: 1;
        min-width: auto;
        text-align: center;
    }
    .card-header {
        flex-direction: column;
        align-items: flex-start !important;
    }
    .card-header .card-title {
        margin-bottom: 10px;
    }
}
</style>
@endpush

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
        <h3 class="card-title mb-2">
            <i class="fas fa-users mr-2"></i>Clients
        </h3>
        <div class="filter-buttons">
            <a href="{{ route('admin.clients.create') }}" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> <span class="d-none d-md-inline">Add</span>
            </a>
            <a href="{{ route('admin.clients.index') }}" class="btn btn-info btn-sm {{ !request('status') ? 'active' : '' }}">
                All
            </a>
            <a href="{{ route('admin.clients.index', ['status' => 'active']) }}" class="btn btn-success btn-sm {{ request('status') == 'active' ? 'active' : '' }}">
                Active
            </a>
            <a href="{{ route('admin.clients.index', ['status' => 'inactive']) }}" class="btn btn-danger btn-sm {{ request('status') == 'inactive' ? 'active' : '' }}">
                Inactive
            </a>
            <a href="{{ route('admin.clients.due') }}" class="btn btn-warning btn-sm">
                Due
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="stats-summary">
            <div class="stat-item">
                <span class="stat-label">Total:</span>
                <span class="stat-value text-primary">{{ $totalClients ?? $clients->total() }}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Active:</span>
                <span class="stat-value text-success">{{ $activeClients ?? 0 }}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Inactive:</span>
                <span class="stat-value text-danger">{{ $inactiveClients ?? 0 }}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Due:</span>
                <span class="stat-value text-warning">{{ $dueClients ?? 0 }}</span>
            </div>
        </div>
        
        <div class="search-form-mobile">
            <div class="quick-filter-mobile mb-3" style="background: #e3f2fd; padding: 12px; border-radius: 8px;">
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-white"><i class="fas fa-search text-primary"></i></span>
                    </div>
                    <input type="text" id="mobileQuickSearch" class="form-control" placeholder="Quick search: Name, ID, Phone, Zone...">
                </div>
                <div class="row">
                    <div class="col-4 pr-1">
                        <select id="mobileStatusFilter" class="form-control form-control-sm">
                            <option value="">Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                    <div class="col-4 px-1">
                        <select id="mobileZoneFilter" class="form-control form-control-sm">
                            <option value="">Zone</option>
                            @foreach($zones as $zone)
                            <option value="{{ strtolower($zone->name) }}">{{ $zone->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-4 pl-1">
                        <select id="mobileDueFilter" class="form-control form-control-sm">
                            <option value="">Due</option>
                            <option value="with-due">With Due</option>
                            <option value="no-due">No Due</option>
                        </select>
                    </div>
                </div>
                <div class="text-center mt-2">
                    <small class="text-muted" id="mobileFilterCount">Showing all clients</small>
                </div>
            </div>
            
            <div class="collapse" id="advancedFilterCollapse">
                <form method="GET" class="mb-3" style="background: #f8f9fa; padding: 10px; border-radius: 6px;">
                    <input type="hidden" name="status" value="{{ request('status') }}">
                    <div class="row mb-2">
                        <div class="col-12 mb-2">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Server search: Name, ID, Phone..." value="{{ request('search') }}">
                        </div>
                        <div class="col-6 pr-1">
                            <select name="zone_id" class="form-control form-control-sm" onchange="loadAreas(this.value)">
                                <option value="">All Zones</option>
                                @foreach($zones as $zone)
                                <option value="{{ $zone->id }}" {{ request('zone_id') == $zone->id ? 'selected' : '' }}>{{ $zone->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 pl-1">
                            <select name="area_id" id="mobileAreaSelect" class="form-control form-control-sm">
                                <option value="">All Areas</option>
                                @if(request('zone_id') && isset($areas))
                                    @foreach($areas as $area)
                                    <option value="{{ $area->id }}" {{ request('area_id') == $area->id ? 'selected' : '' }}>{{ $area->name }}</option>
                                    @endforeach
                                @endif
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6 pr-1">
                            <select name="package_id" class="form-control form-control-sm">
                                <option value="">All Packages</option>
                                @foreach($packages ?? [] as $package)
                                <option value="{{ $package->id }}" {{ request('package_id') == $package->id ? 'selected' : '' }}>{{ $package->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-6 pl-1">
                            <button type="submit" class="btn btn-primary btn-sm btn-block"><i class="fas fa-search mr-1"></i>Search</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="text-center mb-2">
                <button class="btn btn-link btn-sm text-muted" type="button" data-toggle="collapse" data-target="#advancedFilterCollapse">
                    <i class="fas fa-sliders-h mr-1"></i>Advanced Server Search
                </button>
            </div>
        </div>
        
        <div class="search-form-desktop row mb-3 align-items-center">
            <div class="col-md-8">
                <form method="GET" class="d-flex align-items-center flex-wrap" style="gap: 8px;">
                    <input type="hidden" name="status" value="{{ request('status') }}">
                    <div class="input-group input-group-sm" style="width: 200px;">
                        <input type="text" name="search" class="form-control" placeholder="Search name, phone, ID..." value="{{ request('search') }}">
                    </div>
                    <select name="zone_id" class="form-control form-control-sm" style="width: 140px; height: 31px;">
                        <option value="">All Zones</option>
                        @foreach($zones as $zone)
                        <option value="{{ $zone->id }}" {{ request('zone_id') == $zone->id ? 'selected' : '' }}>{{ $zone->name }}</option>
                        @endforeach
                    </select>
                    <select name="package_id" class="form-control form-control-sm" style="width: 140px; height: 31px;">
                        <option value="">All Packages</option>
                        @foreach($packages ?? [] as $package)
                        <option value="{{ $package->id }}" {{ request('package_id') == $package->id ? 'selected' : '' }}>{{ $package->name }}</option>
                        @endforeach
                    </select>
                    <button type="submit" class="btn btn-info btn-sm" style="height: 31px;">
                        <i class="fas fa-search"></i> Search
                    </button>
                </form>
            </div>
            <div class="col-md-4 text-right">
                <div class="input-group input-group-sm" style="width: 180px; float: right;">
                    <input type="text" id="quickSearch" class="form-control" placeholder="Quick filter...">
                </div>
            </div>
        </div>

        <div class="mobile-cards" id="mobileClientCards">
            @forelse($clients as $client)
            <div class="client-card" 
                 data-status="{{ $client->status }}" 
                 data-zone="{{ strtolower($client->zone->name ?? '') }}" 
                 data-due="{{ $client->due_amount > 0 ? 'with-due' : 'no-due' }}"
                 data-search="{{ strtolower($client->name.' '.$client->client_id.' '.$client->phone.' '.($client->zone->name ?? '').' '.($client->area->name ?? '').' '.($client->address ?? '').' '.($client->package->name ?? '')) }}">
                <div class="client-header">
                    <div>
                        <div class="client-name">{{ $client->name }}</div>
                        <div class="client-id">ID: {{ $client->username ?? $client->client_id }} | {{ $client->phone }}</div>
                    </div>
                    @if($client->status == 'active')
                        <span class="mobile-status-badge active">Active</span>
                    @elseif($client->status == 'inactive')
                        <span class="mobile-status-badge inactive">Inactive</span>
                    @elseif($client->status == 'suspended')
                        <span class="mobile-status-badge suspended">Suspended</span>
                    @elseif($client->status == 'pending')
                        <span class="mobile-status-badge pending">Pending</span>
                    @else
                        <span class="mobile-status-badge secondary">{{ ucfirst($client->status) }}</span>
                    @endif
                </div>
                <div class="client-info">
                    <strong>Package:</strong> {{ $client->package->name ?? '-' }} | 
                    <strong>Zone:</strong> {{ $client->zone->name ?? '-' }} | 
                    <strong>Due:</strong> <span class="{{ $client->due_amount > 0 ? 'text-danger' : 'text-success' }}" style="font-weight: 700;">৳{{ number_format($client->due_amount, 0) }}</span>
                </div>
                <div class="mobile-action-buttons">
                    <a href="{{ route('admin.clients.show', $client) }}" class="btn btn-view"><i class="fas fa-eye"></i> <span>View</span></a>
                    <a href="{{ route('admin.clients.edit', $client) }}" class="btn btn-edit"><i class="fas fa-edit"></i> <span>Edit</span></a>
                    <a href="{{ route('admin.payments.create') }}?client_id={{ $client->id }}" class="btn btn-pay"><i class="fas fa-money-bill"></i> <span>Pay</span></a>
                </div>
                <a href="{{ route('admin.clients.ledger', $client) }}" class="btn mobile-action-full"><i class="fas fa-file-alt"></i> Ledger</a>
            </div>
            @empty
            <div class="text-center text-muted py-4" id="noClientsMessage">
                <i class="fas fa-users fa-3x mb-3 text-muted"></i>
                <p>No clients found</p>
            </div>
            @endforelse
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover table-sm" id="clientsTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Login ID</th>
                        <th>Package</th>
                        <th>Zone</th>
                        <th>Contact</th>
                        <th>Due (৳)</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($clients as $client)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $client->name }}</td>
                        <td>{{ $client->username ?? $client->client_id }}</td>
                        <td>{{ $client->package->name ?? '-' }}</td>
                        <td>{{ $client->zone->name ?? '-' }}</td>
                        <td>{{ $client->phone }}</td>
                        <td class="{{ $client->due_amount > 0 ? 'text-danger font-weight-bold' : 'text-success' }}">
                            {{ number_format($client->due_amount, 0) }}
                        </td>
                        <td>
                            @if($client->status == 'active')
                                <span class="badge badge-success status-badge">Active</span>
                            @elseif($client->status == 'inactive')
                                <span class="badge badge-danger status-badge">Inactive</span>
                            @elseif($client->status == 'suspended')
                                <span class="badge badge-warning status-badge">Suspended</span>
                            @else
                                <span class="badge badge-secondary status-badge">{{ ucfirst($client->status) }}</span>
                            @endif
                        </td>
                        <td class="action-btns">
                            <a href="{{ route('admin.clients.show', $client) }}" class="btn btn-info btn-sm" title="View"><i class="fas fa-eye"></i></a>
                            <a href="{{ route('admin.clients.edit', $client) }}" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="{{ route('admin.payments.create') }}?client_id={{ $client->id }}" class="btn btn-primary btn-sm" title="Pay"><i class="fas fa-money-bill"></i></a>
                            <a href="{{ route('admin.clients.ledger', $client) }}" class="btn btn-secondary btn-sm" title="Ledger"><i class="fas fa-file-alt"></i></a>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="9" class="text-center">No clients found</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap">
            <div class="mb-2">
                Showing {{ $clients->firstItem() ?? 0 }}-{{ $clients->lastItem() ?? 0 }} of {{ $clients->total() }}
            </div>
            {{ $clients->withQueryString()->links('vendor.pagination.bootstrap-4') }}
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    $('#quickSearch').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#clientsTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

    function filterMobileClients() {
        var searchText = $('#mobileQuickSearch').val().toLowerCase();
        var statusFilter = $('#mobileStatusFilter').val().toLowerCase();
        var zoneFilter = $('#mobileZoneFilter').val().toLowerCase();
        var dueFilter = $('#mobileDueFilter').val();
        
        var visibleCount = 0;
        var totalCount = 0;
        
        $('#mobileClientCards .client-card').each(function() {
            totalCount++;
            var card = $(this);
            var cardSearch = card.data('search') || '';
            var cardStatus = card.data('status') || '';
            var cardZone = card.data('zone') || '';
            var cardDue = card.data('due') || '';
            
            var show = true;
            
            if (searchText && cardSearch.indexOf(searchText) === -1) {
                show = false;
            }
            if (statusFilter && cardStatus !== statusFilter) {
                show = false;
            }
            if (zoneFilter && cardZone !== zoneFilter) {
                show = false;
            }
            if (dueFilter && cardDue !== dueFilter) {
                show = false;
            }
            
            if (show) {
                card.show();
                visibleCount++;
            } else {
                card.hide();
            }
        });
        
        if (searchText || statusFilter || zoneFilter || dueFilter) {
            $('#mobileFilterCount').text('Showing ' + visibleCount + ' of ' + totalCount + ' clients');
        } else {
            $('#mobileFilterCount').text('Showing all ' + totalCount + ' clients');
        }
    }
    
    $('#mobileQuickSearch').on('input', filterMobileClients);
    $('#mobileStatusFilter').on('change', filterMobileClients);
    $('#mobileZoneFilter').on('change', filterMobileClients);
    $('#mobileDueFilter').on('change', filterMobileClients);
    
    filterMobileClients();
});
</script>
@endpush
