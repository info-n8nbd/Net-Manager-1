@extends('layouts.admin')

@section('title', 'Client Profile')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.clients.index') }}">Clients</a></li>
<li class="breadcrumb-item active">{{ $client->name }}</li>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-4">
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <div class="text-center mb-3">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary text-white" style="width: 80px; height: 80px; font-size: 32px;">
                        {{ strtoupper(substr($client->name, 0, 1)) }}
                    </div>
                </div>
                <h3 class="profile-username text-center">{{ $client->name }}</h3>
                <p class="text-muted text-center mb-1">{{ $client->client_id }}</p>
                <p class="text-center">
                    <span class="badge badge-{{ $client->status == 'active' ? 'success' : ($client->status == 'inactive' ? 'warning' : 'danger') }} px-3 py-2">
                        <i class="fas fa-{{ $client->status == 'active' ? 'check-circle' : 'times-circle' }} mr-1"></i>
                        {{ ucfirst($client->status) }}
                    </span>
                    <span class="badge badge-{{ $client->connection_status == 'online' ? 'info' : 'secondary' }} px-3 py-2 ml-1">
                        <i class="fas fa-wifi mr-1"></i>
                        {{ ucfirst($client->connection_status ?? 'offline') }}
                    </span>
                </p>
                <a href="{{ route('admin.clients.edit', $client) }}" class="btn btn-primary btn-block mt-3">
                    <i class="fas fa-edit mr-2"></i>Edit Profile
                </a>
            </div>
        </div>

        <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-gamepad mr-2"></i>Device Control</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.clients.sync', $client) }}" method="POST" class="mb-2">
                    @csrf
                    <button type="submit" class="btn btn-info btn-block btn-sm">
                        <i class="fas fa-sync mr-2"></i>Sync Status
                    </button>
                </form>
                @if($client->connection_status == 'online')
                <form action="{{ route('admin.clients.disconnect', $client) }}" method="POST" class="mb-2">
                    @csrf
                    <button type="submit" class="btn btn-warning btn-block btn-sm" onclick="return confirm('Disconnect this client?')">
                        <i class="fas fa-power-off mr-2"></i>Disconnect
                    </button>
                </form>
                @endif
                @if($client->status == 'active')
                <form action="{{ route('admin.clients.disable', $client) }}" method="POST" class="mb-2">
                    @csrf
                    <button type="submit" class="btn btn-danger btn-block btn-sm" onclick="return confirm('Disable this client? They will be disconnected.')">
                        <i class="fas fa-ban mr-2"></i>Disable Client
                    </button>
                </form>
                @else
                <form action="{{ route('admin.clients.enable', $client) }}" method="POST" class="mb-2">
                    @csrf
                    <button type="submit" class="btn btn-success btn-block btn-sm">
                        <i class="fas fa-check-circle mr-2"></i>Enable Client
                    </button>
                </form>
                @endif
                @if($client->onu_serial)
                <form action="{{ route('admin.clients.reboot-onu', $client) }}" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-secondary btn-block btn-sm" onclick="return confirm('Reboot ONU for this client?')">
                        <i class="fas fa-redo mr-2"></i>Reboot ONU
                    </button>
                </form>
                @endif
            </div>
        </div>

        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-money-bill-wave mr-2"></i>Billing Summary</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <tr><td class="w-50"><strong>Monthly Fee</strong></td><td class="text-right text-primary font-weight-bold">৳{{ number_format($client->monthly_fee, 2) }}</td></tr>
                    <tr><td><strong>Due Amount</strong></td><td class="text-right text-danger font-weight-bold">৳{{ number_format($client->due_amount, 2) }}</td></tr>
                    <tr><td><strong>Balance</strong></td><td class="text-right text-success font-weight-bold">৳{{ number_format($client->balance ?? 0, 2) }}</td></tr>
                    <tr><td><strong>Billing Date</strong></td><td class="text-right">{{ $client->billing_date }} of every month</td></tr>
                    <tr><td><strong>Billing Cycle</strong></td><td class="text-right">{{ ucfirst($client->billing_cycle ?? 'monthly') }}</td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card">
            <div class="card-header p-2">
                <ul class="nav nav-pills flex-wrap">
                    <li class="nav-item"><a class="nav-link active" href="#profile" data-toggle="tab"><i class="fas fa-user mr-1"></i><span class="d-none d-sm-inline">Profile</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#connection" data-toggle="tab"><i class="fas fa-network-wired mr-1"></i><span class="d-none d-sm-inline">Connection</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#installation" data-toggle="tab"><i class="fas fa-tools mr-1"></i><span class="d-none d-sm-inline">Installation</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#billing-history" data-toggle="tab"><i class="fas fa-file-invoice-dollar mr-1"></i><span class="d-none d-sm-inline">Billing</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#tickets" data-toggle="tab"><i class="fas fa-ticket-alt mr-1"></i><span class="d-none d-sm-inline">Tickets</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#activity" data-toggle="tab"><i class="fas fa-history mr-1"></i><span class="d-none d-sm-inline">Activity</span></a></li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="active tab-pane" id="profile">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-outline card-primary mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-id-card mr-2"></i>Personal Information</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>Full Name</strong></td><td>{{ $client->name }}</td></tr>
                                            <tr><td><strong>Father/Husband</strong></td><td>{{ $client->father_husband_name ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Date of Birth</strong></td><td>{{ $client->date_of_birth ? $client->date_of_birth->format('d M Y') : 'N/A' }}</td></tr>
                                            <tr><td><strong>NID Number</strong></td><td>{{ $client->nid ?? 'N/A' }}</td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-outline card-success mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-phone-alt mr-2"></i>Contact Details</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>Mobile</strong></td><td><a href="tel:{{ $client->phone }}">{{ $client->phone }}</a></td></tr>
                                            <tr><td><strong>Alt. Mobile</strong></td><td>{{ $client->alt_phone ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Email</strong></td><td>{{ $client->email ?? 'N/A' }}</td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card card-outline card-warning mb-3">
                            <div class="card-header py-2">
                                <h6 class="card-title mb-0"><i class="fas fa-map-marker-alt mr-2"></i>Address Details</h6>
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-sm table-striped mb-0">
                                    <tr><td style="width: 20%"><strong>Zone</strong></td><td>{{ $client->zone->name ?? 'N/A' }}</td></tr>
                                    <tr><td><strong>Full Address</strong></td><td>{{ $client->address }}</td></tr>
                                    <tr><td><strong>Landmark</strong></td><td>{{ $client->nearby_landmark ?? 'N/A' }}</td></tr>
                                    @if($client->google_map_lat && $client->google_map_lng)
                                    <tr><td><strong>GPS Location</strong></td><td>
                                        <a href="https://www.google.com/maps?q={{ $client->google_map_lat }},{{ $client->google_map_lng }}" target="_blank" class="btn btn-xs btn-info">
                                            <i class="fas fa-map mr-1"></i>View on Map
                                        </a>
                                    </td></tr>
                                    @endif
                                </table>
                            </div>
                        </div>
                        @if($client->remarks || $client->technician_note)
                        <div class="card card-outline card-secondary">
                            <div class="card-header py-2">
                                <h6 class="card-title mb-0"><i class="fas fa-sticky-note mr-2"></i>Notes & Remarks</h6>
                            </div>
                            <div class="card-body">
                                @if($client->technician_note)
                                <p class="mb-2"><strong>Technician Note:</strong> {{ $client->technician_note }}</p>
                                @endif
                                @if($client->remarks)
                                <p class="mb-0"><strong>Remarks:</strong> {{ $client->remarks }}</p>
                                @endif
                            </div>
                        </div>
                        @endif
                    </div>

                    <div class="tab-pane" id="connection">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-outline card-info mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-wifi mr-2"></i>Connection Info</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>Package</strong></td><td class="text-primary font-weight-bold">{{ $client->package->name ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Connection Type</strong></td><td><span class="badge badge-info">{{ strtoupper($client->connection_type ?? 'PPPoE') }}</span></td></tr>
                                            <tr><td><strong>Connection Date</strong></td><td>{{ $client->connection_date ? $client->connection_date->format('d M Y') : 'N/A' }}</td></tr>
                                            <tr><td><strong>Status</strong></td><td>
                                                <span class="badge badge-{{ $client->connection_status == 'online' ? 'success' : 'danger' }}">
                                                    <i class="fas fa-{{ $client->connection_status == 'online' ? 'check-circle' : 'times-circle' }} mr-1"></i>
                                                    {{ strtoupper($client->connection_status ?? 'OFFLINE') }}
                                                </span>
                                            </td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-outline card-danger mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-key mr-2"></i>PPPoE Credentials</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>Username</strong></td><td><code>{{ $client->username }}</code></td></tr>
                                            <tr><td><strong>Password</strong></td><td><code>{{ $client->pppoe_password ?? '••••••' }}</code></td></tr>
                                            <tr><td><strong>MAC Address</strong></td><td><code>{{ $client->mac_address ?? 'N/A' }}</code></td></tr>
                                            <tr><td><strong>IP Address</strong></td><td><code>{{ $client->ip_address ?? 'Dynamic' }}</code></td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-outline card-success mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-clock mr-2"></i>Session Info</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr>
                                                <td class="w-40"><strong>Last Online</strong></td>
                                                <td>
                                                    @if($client->last_online)
                                                        <span class="text-success"><i class="fas fa-check-circle mr-1"></i>{{ $client->last_online->format('d M Y h:i A') }}</span>
                                                    @else
                                                        <span class="text-muted">Never</span>
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><strong>Last Logout</strong></td>
                                                <td>
                                                    @if($client->last_logout)
                                                        <span class="text-danger"><i class="fas fa-sign-out-alt mr-1"></i>{{ $client->last_logout->format('d M Y h:i A') }}</span>
                                                    @else
                                                        <span class="text-muted">N/A</span>
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr><td><strong>Session Uptime</strong></td><td>{{ $client->session_uptime ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Session IP</strong></td><td><code>{{ $client->session_ip ?? 'N/A' }}</code></td></tr>
                                            <tr><td><strong>Session MAC</strong></td><td><code>{{ $client->session_mac ?? 'N/A' }}</code></td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-outline card-warning mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-tachometer-alt mr-2"></i>Bandwidth Usage</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>Download Speed</strong></td><td>{{ $client->download_speed ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Upload Speed</strong></td><td>{{ $client->upload_speed ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>Total Download</strong></td><td>{{ $client->total_download_bytes ? number_format($client->total_download_bytes / 1073741824, 2) . ' GB' : 'N/A' }}</td></tr>
                                            <tr><td><strong>Total Upload</strong></td><td>{{ $client->total_upload_bytes ? number_format($client->total_upload_bytes / 1073741824, 2) . ' GB' : 'N/A' }}</td></tr>
                                            <tr><td><strong>Last Updated</strong></td><td>{{ $client->bandwidth_last_updated ? $client->bandwidth_last_updated->format('d M Y h:i A') : 'N/A' }}</td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card card-outline card-primary mb-3">
                            <div class="card-header py-2 d-flex justify-content-between align-items-center">
                                <h6 class="card-title mb-0"><i class="fas fa-network-wired mr-2"></i>OLT/ONU Information</h6>
                                @if($client->onu_status == 'online')
                                    <span class="badge badge-success"><i class="fas fa-check-circle mr-1"></i>ONU ONLINE</span>
                                @elseif($client->onu_status == 'offline')
                                    <span class="badge badge-danger"><i class="fas fa-times-circle mr-1"></i>ONU OFFLINE</span>
                                @else
                                    <span class="badge badge-secondary"><i class="fas fa-question-circle mr-1"></i>UNKNOWN</span>
                                @endif
                            </div>
                            <div class="card-body p-0">
                                <div class="row m-0">
                                    <div class="col-md-6 p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>ONU Serial</strong></td><td><code>{{ $client->onu_serial ?? 'N/A' }}</code></td></tr>
                                            <tr><td><strong>ONU Model</strong></td><td>{{ $client->onu_model ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>OLT Port</strong></td><td>{{ $client->olt_port ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>ONU Firmware</strong></td><td>{{ $client->onu_firmware ?? 'N/A' }}</td></tr>
                                            <tr><td><strong>ONU Temperature</strong></td><td>
                                                @if($client->onu_temperature)
                                                    <span class="{{ $client->onu_temperature > 70 ? 'text-danger' : ($client->onu_temperature > 55 ? 'text-warning' : 'text-success') }}">
                                                        {{ $client->onu_temperature }}°C
                                                    </span>
                                                @else
                                                    N/A
                                                @endif
                                            </td></tr>
                                        </table>
                                    </div>
                                    <div class="col-md-6 p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr><td class="w-40"><strong>RX Power</strong></td><td>
                                                @if($client->onu_rx_power)
                                                    @php
                                                        $rxClass = $client->onu_rx_power >= -25 ? 'text-success' : ($client->onu_rx_power >= -28 ? 'text-warning' : 'text-danger');
                                                    @endphp
                                                    <span class="{{ $rxClass }}"><i class="fas fa-signal mr-1"></i>{{ $client->onu_rx_power }} dBm</span>
                                                @else
                                                    N/A
                                                @endif
                                            </td></tr>
                                            <tr><td><strong>TX Power</strong></td><td>
                                                @if($client->onu_tx_power)
                                                    <span class="text-info"><i class="fas fa-broadcast-tower mr-1"></i>{{ $client->onu_tx_power }} dBm</span>
                                                @else
                                                    N/A
                                                @endif
                                            </td></tr>
                                            <tr><td><strong>Signal Quality</strong></td><td>
                                                @if($client->onu_signal_quality)
                                                    @php
                                                        $qualityClass = $client->onu_signal_quality == 'excellent' ? 'success' : 
                                                            ($client->onu_signal_quality == 'good' ? 'info' : 
                                                            ($client->onu_signal_quality == 'fair' ? 'warning' : 'danger'));
                                                    @endphp
                                                    <span class="badge badge-{{ $qualityClass }}">{{ strtoupper($client->onu_signal_quality) }}</span>
                                                @else
                                                    <span class="badge badge-secondary">UNKNOWN</span>
                                                @endif
                                            </td></tr>
                                            <tr><td><strong>ONU Uptime</strong></td><td>
                                                @if($client->onu_uptime_seconds)
                                                    @php
                                                        $days = floor($client->onu_uptime_seconds / 86400);
                                                        $hours = floor(($client->onu_uptime_seconds % 86400) / 3600);
                                                        $mins = floor(($client->onu_uptime_seconds % 3600) / 60);
                                                    @endphp
                                                    {{ $days }}d {{ $hours }}h {{ $mins }}m
                                                @else
                                                    N/A
                                                @endif
                                            </td></tr>
                                            <tr><td><strong>Last Check</strong></td><td>{{ $client->onu_last_check ? $client->onu_last_check->format('d M Y h:i A') : 'N/A' }}</td></tr>
                                        </table>
                                    </div>
                                </div>
                                @if($client->onu_status == 'offline' && $client->onu_down_reason)
                                <div class="alert alert-danger m-3 mb-2">
                                    <strong><i class="fas fa-exclamation-triangle mr-2"></i>ONU Down Reason:</strong>
                                    {{ $client->onu_down_reason }}
                                    @if($client->onu_last_down)
                                        <br><small class="text-muted">Down since: {{ $client->onu_last_down->format('d M Y h:i A') }}</small>
                                    @endif
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="installation">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-outline card-success mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-tools mr-2"></i>Installation Details</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr>
                                                <td class="w-50"><strong>Installation Charge</strong></td>
                                                <td class="text-right font-weight-bold">৳{{ number_format($client->installation_charge ?? 0, 2) }}</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Cable Length</strong></td>
                                                <td class="text-right">{{ number_format($client->cable_length_meters ?? 0) }} meters</td>
                                            </tr>
                                            <tr>
                                                <td><strong>ONU Provided</strong></td>
                                                <td class="text-right">
                                                    @if($client->onu_required)
                                                        <span class="badge badge-success"><i class="fas fa-check"></i> Yes</span>
                                                    @else
                                                        <span class="badge badge-secondary"><i class="fas fa-times"></i> No</span>
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><strong>Router Provided</strong></td>
                                                <td class="text-right">
                                                    @if($client->router_required)
                                                        <span class="badge badge-success"><i class="fas fa-check"></i> Yes</span>
                                                    @else
                                                        <span class="badge badge-secondary"><i class="fas fa-times"></i> No</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-outline card-primary mb-3">
                                    <div class="card-header py-2">
                                        <h6 class="card-title mb-0"><i class="fas fa-credit-card mr-2"></i>Payment Preferences</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <table class="table table-sm table-striped mb-0">
                                            <tr>
                                                <td class="w-50"><strong>Preferred Method</strong></td>
                                                <td class="text-right">{{ ucfirst($client->preferred_payment_method ?? 'Cash') }}</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Billing Cycle</strong></td>
                                                <td class="text-right">{{ ucfirst($client->billing_cycle ?? 'Monthly') }}</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Billing Date</strong></td>
                                                <td class="text-right">{{ $client->billing_date }} of each month</td>
                                            </tr>
                                            @if($client->signup_fee)
                                            <tr>
                                                <td><strong>Signup Fee</strong></td>
                                                <td class="text-right">৳{{ number_format($client->signup_fee, 2) }}</td>
                                            </tr>
                                            @endif
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="billing-history">
                        <style>
                        .detail-table { font-size: 12px; }
                        .detail-table th, .detail-table td { padding: 6px 8px !important; vertical-align: middle; }
                        .detail-table .status-badge { font-size: 10px; padding: 3px 6px; }
                        .detail-table .small-text { font-size: 11px; color: #666; }
                        .detail-table .action-btn { padding: 2px 6px; font-size: 11px; }
                        .billing-card { border-left: 4px solid #007bff; margin-bottom: 10px; background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
                        .billing-card.type-bill { border-left-color: #17a2b8; }
                        .billing-card.type-payment { border-left-color: #28a745; }
                        .billing-card.status-unpaid { border-left-color: #dc3545; }
                        .billing-card .card-body { padding: 10px 12px; }
                        .billing-filter { background: #f8f9fa; padding: 10px; border-radius: 6px; margin-bottom: 12px; }
                        @media (min-width: 768px) { .mobile-billing-cards { display: none; } }
                        @media (max-width: 767px) { .desktop-billing-table { display: none; } }
                        </style>

                        <div class="billing-filter">
                            <div class="row">
                                <div class="col-6 col-md-3 mb-2">
                                    <select id="billingTypeFilter" class="form-control form-control-sm">
                                        <option value="">All Types</option>
                                        <option value="bill">Bills Only</option>
                                        <option value="payment">Payments Only</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-3 mb-2">
                                    <select id="billingStatusFilter" class="form-control form-control-sm">
                                        <option value="">All Status</option>
                                        <option value="paid">Paid</option>
                                        <option value="unpaid">Unpaid</option>
                                        <option value="partial">Partial</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6 mb-2">
                                    <input type="text" id="billingSearchInput" class="form-control form-control-sm" placeholder="Search by month, amount, method...">
                                </div>
                            </div>
                        </div>

                        <div class="mobile-billing-cards" id="mobileBillingCards">
                            @php
                                $billingHistory = collect();
                                foreach($client->bills as $bill) {
                                    $billPayments = $client->payments->where('bill_id', $bill->id);
                                    $lastPayment = $billPayments->sortByDesc('payment_date')->first();
                                    $billingHistory->push([
                                        'type' => 'bill',
                                        'date' => $bill->created_at,
                                        'bill' => $bill,
                                        'payment' => $lastPayment
                                    ]);
                                }
                                $billingHistory = $billingHistory->sortByDesc('date');
                            @endphp
                            @forelse($billingHistory->take(20) as $item)
                            <div class="card billing-card type-{{ $item['type'] }} {{ $item['bill']->status == 'unpaid' ? 'status-unpaid' : '' }}" data-type="{{ $item['type'] }}" data-status="{{ $item['bill']->status }}" data-search="{{ strtolower($item['bill']->billing_month.'/'.$item['bill']->billing_year.' '.$item['bill']->total_amount.' '.($item['payment'] ? ($item['payment']->paymentMethod->name ?? 'Cash').' '.($item['payment']->collectedBy->name ?? '') : '')) }}">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <div>
                                            <span class="badge badge-info mr-1">Bill</span>
                                            <strong>{{ $item['bill']->billing_month }}/{{ $item['bill']->billing_year }}</strong>
                                        </div>
                                        <span class="badge badge-{{ $item['bill']->status == 'paid' ? 'success' : ($item['bill']->status == 'partial' ? 'warning' : 'danger') }}">{{ ucfirst($item['bill']->status) }}</span>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-6">
                                            <div class="small-text text-muted">Generated</div>
                                            <div>{{ $item['bill']->created_at->format('d M Y h:i A') }}</div>
                                        </div>
                                        <div class="col-3">
                                            <div class="small-text text-muted">Amount</div>
                                            <div class="font-weight-bold">৳{{ number_format($item['bill']->total_amount) }}</div>
                                        </div>
                                        <div class="col-3">
                                            <div class="small-text text-muted">Due</div>
                                            <div class="text-danger font-weight-bold">৳{{ number_format($item['bill']->due_amount) }}</div>
                                        </div>
                                    </div>
                                    @if($item['payment'])
                                    <div class="bg-light p-2 rounded mb-2">
                                        <div class="small-text text-success mb-1"><i class="fas fa-check-circle mr-1"></i>Payment Received</div>
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="small-text"><i class="fas fa-calendar mr-1"></i>{{ $item['payment']->payment_date->format('d M Y h:i A') }}</div>
                                            </div>
                                            <div class="col-6">
                                                <div class="small-text"><i class="fas fa-credit-card mr-1"></i>{{ $item['payment']->paymentMethod->name ?? 'Cash' }}</div>
                                            </div>
                                        </div>
                                        @if($item['payment']->collectedBy)
                                        <div class="small-text mt-1"><i class="fas fa-user mr-1"></i>Collected by: {{ $item['payment']->collectedBy->name }}</div>
                                        @endif
                                    </div>
                                    @endif
                                    <div class="d-flex gap-2 flex-wrap">
                                        <a href="{{ route('admin.billing.edit', $item['bill']) }}" class="btn btn-warning btn-xs"><i class="fas fa-edit mr-1"></i>Edit</a>
                                        <a href="{{ route('admin.billing.invoice', $item['bill']) }}" class="btn btn-info btn-xs"><i class="fas fa-download mr-1"></i>Invoice</a>
                                        <form action="{{ route('admin.billing.destroy', $item['bill']) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this bill?')">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <div class="text-center text-muted py-4">No billing history found</div>
                            @endforelse
                        </div>

                        <div class="desktop-billing-table">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover detail-table mb-0" id="billingTable">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Period</th>
                                            <th>Generated</th>
                                            <th>Amount</th>
                                            <th>Payment Date</th>
                                            <th>Method</th>
                                            <th>Collected By</th>
                                            <th>Due</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="billingTableBody">
                                    @forelse($billingHistory->take(20) as $item)
                                    <tr data-type="bill" data-status="{{ $item['bill']->status }}">
                                        <td><strong>{{ $item['bill']->billing_month }}/{{ $item['bill']->billing_year }}</strong></td>
                                        <td class="small-text">{{ $item['bill']->created_at->format('d M Y h:i A') }}</td>
                                        <td>৳{{ number_format($item['bill']->total_amount) }}</td>
                                        <td>
                                            @if($item['payment'])
                                            <span class="text-success">{{ $item['payment']->payment_date->format('d M Y h:i A') }}</span>
                                            @else
                                            <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>{{ $item['payment'] ? ($item['payment']->paymentMethod->name ?? 'Cash') : '-' }}</td>
                                        <td class="small-text">{{ $item['payment'] && $item['payment']->collectedBy ? $item['payment']->collectedBy->name : '-' }}</td>
                                        <td class="text-danger">৳{{ number_format($item['bill']->due_amount) }}</td>
                                        <td><span class="badge badge-{{ $item['bill']->status == 'paid' ? 'success' : ($item['bill']->status == 'partial' ? 'warning' : 'danger') }} status-badge">{{ ucfirst($item['bill']->status) }}</span></td>
                                        <td>
                                            <a href="{{ route('admin.billing.edit', $item['bill']) }}" class="btn btn-warning btn-xs action-btn" title="Edit"><i class="fas fa-edit"></i></a>
                                            <a href="{{ route('admin.billing.invoice', $item['bill']) }}" class="btn btn-info btn-xs action-btn" title="Invoice"><i class="fas fa-download"></i></a>
                                            <form action="{{ route('admin.billing.destroy', $item['bill']) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this bill?')">
                                                @csrf @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-xs action-btn" title="Delete"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="9" class="text-center text-muted py-3">No billing history found</td></tr>
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const typeFilter = document.getElementById('billingTypeFilter');
                            const statusFilter = document.getElementById('billingStatusFilter');
                            const searchInput = document.getElementById('billingSearchInput');

                            function filterBilling() {
                                const type = typeFilter.value.toLowerCase();
                                const status = statusFilter.value.toLowerCase();
                                const search = searchInput.value.toLowerCase();

                                document.querySelectorAll('.billing-card').forEach(card => {
                                    const cardType = card.dataset.type;
                                    const cardStatus = card.dataset.status;
                                    const cardSearch = card.dataset.search;

                                    let show = true;
                                    if (type && cardType !== type) show = false;
                                    if (status && cardStatus !== status) show = false;
                                    if (search && !cardSearch.includes(search)) show = false;

                                    card.style.display = show ? 'block' : 'none';
                                });

                                document.querySelectorAll('#billingTableBody tr').forEach(row => {
                                    const rowStatus = row.dataset.status;
                                    const rowText = row.textContent.toLowerCase();

                                    let show = true;
                                    if (status && rowStatus !== status) show = false;
                                    if (search && !rowText.includes(search)) show = false;

                                    row.style.display = show ? '' : 'none';
                                });
                            }

                            typeFilter.addEventListener('change', filterBilling);
                            statusFilter.addEventListener('change', filterBilling);
                            searchInput.addEventListener('input', filterBilling);
                        });
                        </script>
                    </div>

                    <div class="tab-pane" id="tickets">
                        <table class="table table-sm table-hover">
                            <thead class="thead-light">
                                <tr><th>Ticket</th><th>Subject</th><th>Priority</th><th>Status</th><th>Date</th></tr>
                            </thead>
                            <tbody>
                            @forelse($client->tickets->take(15) as $ticket)
                            <tr>
                                <td><strong>{{ $ticket->ticket_no }}</strong></td>
                                <td>{{ Str::limit($ticket->subject, 40) }}</td>
                                <td>
                                    <span class="badge badge-{{ $ticket->priority == 'high' ? 'danger' : ($ticket->priority == 'medium' ? 'warning' : 'info') }}">
                                        {{ ucfirst($ticket->priority ?? 'normal') }}
                                    </span>
                                </td>
                                <td><span class="badge badge-{{ $ticket->status == 'open' ? 'warning' : ($ticket->status == 'closed' ? 'success' : 'info') }}">{{ ucfirst($ticket->status) }}</span></td>
                                <td>{{ $ticket->created_at->format('d M Y') }}</td>
                            </tr>
                            @empty
                            <tr><td colspan="5" class="text-center text-muted py-4"><i class="fas fa-inbox mr-2"></i>No tickets found</td></tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="tab-pane" id="activity">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Date/Time</th>
                                        <th>Action</th>
                                        <th>Details</th>
                                        <th>By</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @forelse($client->activityLogs->take(50) as $log)
                                <tr>
                                    <td class="text-nowrap">
                                        <small>{{ $log->created_at->format('d M Y') }}</small><br>
                                        <small class="text-muted">{{ $log->created_at->format('h:i A') }}</small>
                                    </td>
                                    <td>
                                        @php
                                            $actionBadge = match($log->action_type) {
                                                'activated' => 'success',
                                                'deactivated', 'suspended' => 'warning',
                                                'connection_created' => 'info',
                                                'bill_generated' => 'primary',
                                                'payment_received' => 'success',
                                                'reconnected' => 'info',
                                                'disconnected' => 'danger',
                                                default => 'secondary'
                                            };
                                            $actionIcon = match($log->action_type) {
                                                'activated', 'reconnected' => 'check-circle',
                                                'deactivated', 'suspended' => 'times-circle',
                                                'connection_created' => 'wifi',
                                                'bill_generated' => 'file-invoice',
                                                'payment_received' => 'money-bill',
                                                'disconnected' => 'power-off',
                                                default => 'circle'
                                            };
                                        @endphp
                                        <span class="badge badge-{{ $actionBadge }}">
                                            <i class="fas fa-{{ $actionIcon }} mr-1"></i>
                                            {{ ucwords(str_replace('_', ' ', $log->action_type)) }}
                                        </span>
                                    </td>
                                    <td>
                                        @if($log->old_value && $log->new_value)
                                            <span class="text-muted">{{ $log->old_value }}</span>
                                            <i class="fas fa-arrow-right mx-1 text-muted"></i>
                                            <span class="text-dark">{{ $log->new_value }}</span>
                                        @elseif($log->new_value)
                                            {{ $log->new_value }}
                                        @else
                                            <span class="text-muted">-</span>
                                        @endif
                                        @if($log->extra_data)
                                            @if(isset($log->extra_data['amount']))
                                                <br><small class="text-success">৳{{ number_format($log->extra_data['amount'], 2) }}</small>
                                            @endif
                                        @endif
                                    </td>
                                    <td>
                                        <span class="badge badge-{{ $log->triggered_by == 'system' || $log->triggered_by == 'auto' ? 'secondary' : 'primary' }}">
                                            {{ ucfirst($log->triggered_by) }}
                                        </span>
                                        @if($log->performedByUser)
                                            <br><small class="text-muted">{{ $log->performedByUser->name }}</small>
                                        @endif
                                    </td>
                                    <td>
                                        <small>{{ $log->reason ?? '-' }}</small>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-history mr-2"></i>No activity logs found
                                    </td>
                                </tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>
                        @if($client->activityLogs->count() > 50)
                        <div class="text-center p-2 border-top">
                            <small class="text-muted">Showing latest 50 activities. Total: {{ $client->activityLogs->count() }}</small>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
