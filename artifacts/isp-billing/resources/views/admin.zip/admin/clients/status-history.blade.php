@extends('layouts.admin')

@section('title', 'Client Status History')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.clients.index') }}">Clients</a></li>
<li class="breadcrumb-item"><a href="{{ route('admin.clients.show', $client) }}">{{ $client->name }}</a></li>
<li class="breadcrumb-item active">Status History</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user mr-2"></i>Client Info</h3>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 60px; height: 60px; font-size: 1.5rem;">
                        {{ strtoupper(substr($client->name, 0, 1)) }}
                    </div>
                    <h5 class="mt-2 mb-0">{{ $client->name }}</h5>
                    <small class="text-muted">{{ $client->client_id }}</small>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Current Status</span>
                        <span class="badge badge-{{ $client->status == 'active' ? 'success' : ($client->status == 'inactive' ? 'secondary' : ($client->status == 'suspended' ? 'warning' : 'danger')) }}">
                            {{ ucfirst($client->status) }}
                        </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Phone</span>
                        <span>{{ $client->phone }}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Zone</span>
                        <span>{{ $client->zone->name ?? 'N/A' }}</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-info">
                <h3 class="card-title"><i class="fas fa-link mr-2"></i>Quick Links</h3>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <a href="{{ route('admin.clients.show', $client) }}" class="list-group-item list-group-item-action">
                        <i class="fas fa-user mr-2"></i> View Profile
                    </a>
                    <a href="{{ route('admin.clients.ledger', $client) }}" class="list-group-item list-group-item-action">
                        <i class="fas fa-file-invoice-dollar mr-2"></i> Billing Ledger
                    </a>
                    <a href="{{ route('admin.clients.line-shifts', $client) }}" class="list-group-item list-group-item-action">
                        <i class="fas fa-exchange-alt mr-2"></i> Line Shifts
                    </a>
                    <a href="{{ route('admin.clients.reconnections', $client) }}" class="list-group-item list-group-item-action">
                        <i class="fas fa-plug mr-2"></i> Reconnections
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-history mr-2"></i>Status Change History</h3>
            </div>
            <div class="card-body">
                @if($logs->count() > 0)
                <div class="timeline">
                    @foreach($logs as $log)
                    <div class="time-label">
                        <span class="bg-primary">{{ $log->created_at->format('M d, Y') }}</span>
                    </div>
                    <div>
                        <i class="fas fa-sync-alt bg-{{ 
                            $log->new_status == 'active' ? 'success' : 
                            ($log->new_status == 'inactive' ? 'secondary' : 
                            ($log->new_status == 'suspended' ? 'warning' : 'danger')) 
                        }}"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fas fa-clock"></i> {{ $log->created_at->format('h:i A') }}</span>
                            <h3 class="timeline-header">
                                Status changed from 
                                <span class="badge badge-{{ 
                                    $log->old_status == 'active' ? 'success' : 
                                    ($log->old_status == 'inactive' ? 'secondary' : 
                                    ($log->old_status == 'suspended' ? 'warning' : 'danger')) 
                                }}">{{ ucfirst($log->old_status ?? 'N/A') }}</span>
                                to 
                                <span class="badge badge-{{ 
                                    $log->new_status == 'active' ? 'success' : 
                                    ($log->new_status == 'inactive' ? 'secondary' : 
                                    ($log->new_status == 'suspended' ? 'warning' : 'danger')) 
                                }}">{{ ucfirst($log->new_status) }}</span>
                            </h3>
                            <div class="timeline-body">
                                @if($log->reason)
                                <p><strong>Reason:</strong> {{ $log->reason }}</p>
                                @endif
                                <p class="text-muted mb-0">
                                    <i class="fas fa-user"></i> Changed by: {{ $log->changedBy->name ?? 'System' }}
                                </p>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    <div>
                        <i class="fas fa-flag bg-gray"></i>
                    </div>
                </div>
                @else
                <div class="text-center py-5">
                    <i class="fas fa-history fa-4x text-muted mb-3"></i>
                    <h5 class="text-muted">No Status Changes</h5>
                    <p class="text-muted">There are no recorded status changes for this client.</p>
                </div>
                @endif
            </div>
            <div class="card-footer">
                {{ $logs->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
