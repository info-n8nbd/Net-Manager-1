@extends('layouts.admin')

@section('title', 'Add Client')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.clients.index') }}">Clients</a></li>
<li class="breadcrumb-item active">Add</li>
@endsection

@section('content')
<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-plus mr-2"></i>Add New Client</h3>
    </div>
    <form action="{{ route('admin.clients.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="card-body">
            @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
            </div>
            @endif
            
            <div class="row">
                <div class="col-md-4">
                    <div class="card card-outline card-primary">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-user mr-2"></i>Personal Information</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
                            </div>
                            <div class="form-group">
                                <label>Phone <span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control" value="{{ old('phone') }}" required>
                            </div>
                            <div class="form-group">
                                <label>Alt Phone</label>
                                <input type="text" name="alt_phone" class="form-control" value="{{ old('alt_phone') }}">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" value="{{ old('email') }}">
                            </div>
                            <div class="form-group">
                                <label>NID Number</label>
                                <input type="text" name="nid" class="form-control" value="{{ old('nid') }}">
                            </div>
                            <div class="form-group">
                                <label>NID Front Image</label>
                                <input type="file" name="nid_front_image" class="form-control-file" accept="image/*">
                            </div>
                            <div class="form-group">
                                <label>NID Back Image</label>
                                <input type="file" name="nid_back_image" class="form-control-file" accept="image/*">
                            </div>
                            <div class="form-group">
                                <label>Address <span class="text-danger">*</span></label>
                                <textarea name="address" class="form-control" rows="3" required>{{ old('address') }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card card-outline card-info">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-network-wired mr-2"></i>Connection Details</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Connection Type <span class="text-danger">*</span></label>
                                <select name="connection_type" class="form-control" required>
                                    <option value="pppoe" {{ old('connection_type') == 'pppoe' ? 'selected' : '' }}>PPPoE</option>
                                    <option value="queue" {{ old('connection_type') == 'queue' ? 'selected' : '' }}>Queue</option>
                                    <option value="invoice" {{ old('connection_type') == 'invoice' ? 'selected' : '' }}>Invoice Only</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Zone <span class="text-danger">*</span></label>
                                <select name="zone_id" class="form-control" required id="zone_id">
                                    <option value="">Select Zone</option>
                                    @foreach($zones as $zone)
                                    <option value="{{ $zone->id }}" data-areas='@json($zone->areas)'>{{ $zone->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Area</label>
                                <select name="area_id" class="form-control" id="area_id">
                                    <option value="">Select Area</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Package <span class="text-danger">*</span></label>
                                <select name="package_id" class="form-control" required id="package_id">
                                    <option value="">Select Package</option>
                                    @foreach($packages as $package)
                                    <option value="{{ $package->id }}" data-price="{{ $package->price }}">{{ $package->name }} - ৳{{ number_format($package->price, 2) }} ({{ $package->bandwidth }})</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Username <span class="text-danger">*</span></label>
                                <input type="text" name="username" class="form-control" value="{{ old('username') }}" required>
                            </div>
                            <div class="form-group">
                                <label>PPPoE Password</label>
                                <div class="input-group">
                                    <input type="text" name="pppoe_password" class="form-control" value="{{ old('pppoe_password') }}" id="pppoe_password">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-secondary" onclick="generatePassword()"><i class="fas fa-random"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>MAC Address</label>
                                <input type="text" name="mac_address" class="form-control" value="{{ old('mac_address') }}" placeholder="AA:BB:CC:DD:EE:FF">
                            </div>
                            <div class="form-group">
                                <label>IP Address</label>
                                <input type="text" name="ip_address" class="form-control" value="{{ old('ip_address') }}">
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" name="mac_binding_enabled" value="1" class="custom-control-input" id="mac_binding" {{ old('mac_binding_enabled') ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="mac_binding">Enable MAC Binding</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card card-outline card-success">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-money-bill mr-2"></i>Billing & Fees</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Monthly Fee (৳)</label>
                                <input type="number" name="monthly_fee" class="form-control" value="{{ old('monthly_fee', 0) }}" id="monthly_fee" step="0.01" readonly>
                            </div>
                            <div class="form-group">
                                <label>Permanent Discount (৳)</label>
                                <input type="number" name="permanent_discount" class="form-control" value="{{ old('permanent_discount', 0) }}" step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label>Signup Fee (৳)</label>
                                <input type="number" name="signup_fee" class="form-control" value="{{ old('signup_fee', 0) }}" step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label>Connection Date</label>
                                <input type="date" name="connection_date" class="form-control" value="{{ old('connection_date', date('Y-m-d')) }}">
                            </div>
                            <div class="form-group">
                                <label>Billing Date (Day of Month)</label>
                                <input type="number" name="billing_date" class="form-control" value="{{ old('billing_date', 1) }}" min="1" max="28">
                            </div>
                            <div class="form-group">
                                <label>Payment Deadline (Days)</label>
                                <input type="number" name="payment_deadline" class="form-control" value="{{ old('payment_deadline', 10) }}" min="1" max="30">
                            </div>
                            <div class="form-group">
                                <label>Auto Disconnect After (Days)</label>
                                <input type="number" name="auto_disconnect_days" class="form-control" value="{{ old('auto_disconnect_days', 15) }}" min="1" max="60">
                            </div>
                            <div class="form-group">
                                <label>Bill Calculation</label>
                                <select name="bill_calculation_type" class="form-control">
                                    <option value="auto">Auto</option>
                                    <option value="manual">Manual</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="pending">Pending (New Request)</option>
                                    <option value="active">Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card card-outline card-warning">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-tachometer-alt mr-2"></i>Queue Bandwidth (For Queue Clients)</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Max Limit</label>
                                <input type="text" name="queue_max_limit" class="form-control" value="{{ old('queue_max_limit') }}" placeholder="10M/10M">
                            </div>
                            <div class="form-group">
                                <label>Burst Limit</label>
                                <input type="text" name="queue_burst_limit" class="form-control" value="{{ old('queue_burst_limit') }}" placeholder="15M/15M">
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>YouTube Bandwidth</label>
                                        <input type="text" name="youtube_bandwidth" class="form-control" value="{{ old('youtube_bandwidth') }}" placeholder="5M/5M">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Facebook Bandwidth</label>
                                        <input type="text" name="facebook_bandwidth" class="form-control" value="{{ old('facebook_bandwidth') }}" placeholder="5M/5M">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card card-outline card-danger">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-map-marker-alt mr-2"></i>Location (Google Map)</h5></div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Google Map Link</label>
                                <input type="text" name="google_map_location" class="form-control" value="{{ old('google_map_location') }}" placeholder="Paste Google Maps link here">
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Latitude</label>
                                        <input type="text" name="google_map_lat" class="form-control" value="{{ old('google_map_lat') }}" id="lat">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Longitude</label>
                                        <input type="text" name="google_map_lng" class="form-control" value="{{ old('google_map_lng') }}" id="lng">
                                    </div>
                                </div>
                            </div>
                            <div id="map" style="height: 200px; background: #eee; display: flex; align-items: center; justify-content: center; border-radius: 4px;">
                                <span class="text-muted">Map Preview (Add Google Maps API Key)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card card-outline card-secondary">
                <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-comment mr-2"></i>Remarks & Notes</h5></div>
                <div class="card-body">
                    <div class="form-group mb-0">
                        <label>Remarks</label>
                        <textarea name="remarks" class="form-control" rows="2" placeholder="Any additional notes about this client...">{{ old('remarks') }}</textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save Client</button>
            <button type="submit" name="save_and_send_sms" value="1" class="btn btn-success"><i class="fas fa-sms mr-1"></i>Save & Send Login SMS</button>
            <a href="{{ route('admin.clients.index') }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
document.getElementById('zone_id').addEventListener('change', function() {
    var areas = JSON.parse(this.selectedOptions[0].dataset.areas || '[]');
    var areaSelect = document.getElementById('area_id');
    areaSelect.innerHTML = '<option value="">Select Area</option>';
    areas.forEach(function(area) {
        areaSelect.innerHTML += '<option value="'+area.id+'">'+area.name+'</option>';
    });
});

document.getElementById('package_id').addEventListener('change', function() {
    var price = this.selectedOptions[0].dataset.price || 0;
    document.getElementById('monthly_fee').value = price;
});

function generatePassword() {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    var password = '';
    for (var i = 0; i < 8; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.getElementById('pppoe_password').value = password;
}
</script>
@endpush
