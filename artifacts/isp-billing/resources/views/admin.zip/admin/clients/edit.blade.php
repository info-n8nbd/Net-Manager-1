@extends('layouts.admin')

@section('title', 'Edit Client')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.clients.index') }}">Clients</a></li>
<li class="breadcrumb-item active">Edit</li>
@endsection

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Edit Client: {{ $client->name }}</h3></div>
    <form action="{{ route('admin.clients.update', $client) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Name *</label>
                        <input type="text" name="name" class="form-control" value="{{ old('name', $client->name) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Phone *</label>
                        <input type="text" name="phone" class="form-control" value="{{ old('phone', $client->phone) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="{{ old('email', $client->email) }}">
                    </div>
                    <div class="form-group">
                        <label>Address *</label>
                        <textarea name="address" class="form-control" rows="3" required>{{ old('address', $client->address) }}</textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Zone</label>
                        <select name="zone_id" class="form-control">
                            @foreach($zones as $zone)
                            <option value="{{ $zone->id }}" {{ $client->zone_id == $zone->id ? 'selected' : '' }}>{{ $zone->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Package</label>
                        <select name="package_id" class="form-control">
                            @foreach($packages as $package)
                            <option value="{{ $package->id }}" {{ $client->package_id == $package->id ? 'selected' : '' }}>{{ $package->name }} - ৳{{ number_format($package->price, 2) }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="{{ old('username', $client->username) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Monthly Fee (৳)</label>
                        <input type="number" name="monthly_fee" class="form-control" value="{{ old('monthly_fee', $client->monthly_fee) }}" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="active" {{ $client->status == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ $client->status == 'inactive' ? 'selected' : '' }}>Inactive</option>
                            <option value="suspended" {{ $client->status == 'suspended' ? 'selected' : '' }}>Suspended</option>
                            <option value="pending" {{ $client->status == 'pending' ? 'selected' : '' }}>Pending</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Update Client</button>
            <a href="{{ route('admin.clients.index') }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
@endsection
