@extends('layouts.admin')

@section('title', 'Loan Management')
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('admin.accounts.cash') }}">Accounts</a></li>
<li class="breadcrumb-item active">Loan Management</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-hand-holding-usd mr-2"></i>New Loan Entry</h3>
            </div>
            <form action="{{ route('admin.accounts.loan.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label>Loan Type <span class="text-danger">*</span></label>
                        <select name="type" class="form-control" required>
                            <option value="received">Loan Received</option>
                            <option value="given">Loan Given</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Party Name <span class="text-danger">*</span></label>
                        <input type="text" name="party_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Party Phone</label>
                        <input type="text" name="party_phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Amount (৳) <span class="text-danger">*</span></label>
                        <input type="number" name="amount" class="form-control" step="0.01" min="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>Account <span class="text-danger">*</span></label>
                        <select name="account_id" class="form-control" required>
                            @foreach($accounts as $account)
                            <option value="{{ $account->id }}">{{ $account->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Loan Date <span class="text-danger">*</span></label>
                        <input type="date" name="loan_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                    </div>
                    <div class="form-group">
                        <label>Due Date</label>
                        <input type="date" name="due_date" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-save mr-1"></i>Save Loan</button>
                </div>
            </form>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-list mr-2"></i>Loan Records</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Ref#</th>
                            <th>Type</th>
                            <th>Party</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Remaining</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($loans as $loan)
                        <tr>
                            <td><code>{{ $loan->reference_no }}</code></td>
                            <td>
                                <span class="badge badge-{{ $loan->type === 'received' ? 'success' : 'danger' }}">
                                    {{ ucfirst($loan->type) }}
                                </span>
                            </td>
                            <td>{{ $loan->party_name }}</td>
                            <td class="text-right">৳{{ number_format($loan->amount, 2) }}</td>
                            <td class="text-right">৳{{ number_format($loan->remaining_amount, 2) }}</td>
                            <td>
                                <span class="badge badge-{{ $loan->status === 'completed' ? 'success' : ($loan->status === 'partial' ? 'warning' : 'info') }}">
                                    {{ ucfirst($loan->status) }}
                                </span>
                            </td>
                            <td>{{ $loan->loan_date->format('d M Y') }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted">No loans found</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($loans->hasPages())
            <div class="card-footer">{{ $loans->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
