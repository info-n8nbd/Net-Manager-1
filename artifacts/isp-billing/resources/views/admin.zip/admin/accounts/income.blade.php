@extends('layouts.admin')

@section('title', 'Income')
@section('breadcrumb')
<li class="breadcrumb-item active">Income</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Income Records</h3></div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead><tr><th>Date</th><th>Head</th><th>Account</th><th>Amount (৳)</th><th>Description</th></tr></thead>
                    <tbody>
                        @forelse($incomes as $income)
                        <tr>
                            <td>{{ $income->income_date->format('d M Y') }}</td>
                            <td>{{ $income->incomeHead->name ?? 'N/A' }}</td>
                            <td>{{ $income->account->name ?? 'N/A' }}</td>
                            <td>{{ number_format($income->amount, 2) }}</td>
                            <td>{{ $income->description ?? '-' }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="5" class="text-center">No income records</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $incomes->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-success">
            <div class="card-header"><h3 class="card-title">Add Income</h3></div>
            <form action="{{ route('admin.accounts.income.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Income Head</label>
                        <select name="income_head_id" class="form-control" required>
                            @foreach($incomeHeads as $head)
                            <option value="{{ $head->id }}">{{ $head->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Account</label>
                        <select name="account_id" class="form-control" required>
                            @foreach($accounts as $account)
                            <option value="{{ $account->id }}">{{ $account->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Amount (৳)</label><input type="number" name="amount" class="form-control" step="0.01" required></div>
                    <div class="form-group"><label>Date</label><input type="date" name="income_date" class="form-control" value="{{ date('Y-m-d') }}" required></div>
                    <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-success">Add Income</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
