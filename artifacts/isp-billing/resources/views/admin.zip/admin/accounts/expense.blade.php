@extends('layouts.admin')

@section('title', 'Expense')
@section('breadcrumb')
<li class="breadcrumb-item active">Expense</li>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3 class="card-title">Expense Records</h3></div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead><tr><th>Date</th><th>Head</th><th>Account</th><th>Amount (৳)</th><th>Description</th></tr></thead>
                    <tbody>
                        @forelse($expenses as $expense)
                        <tr>
                            <td>{{ $expense->expense_date->format('d M Y') }}</td>
                            <td>{{ $expense->expenseHead->name ?? 'N/A' }}</td>
                            <td>{{ $expense->account->name ?? 'N/A' }}</td>
                            <td>{{ number_format($expense->amount, 2) }}</td>
                            <td>{{ $expense->description ?? '-' }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="5" class="text-center">No expense records</td></tr>
                        @endforelse
                    </tbody>
                </table>
                {{ $expenses->links() }}
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-danger">
            <div class="card-header"><h3 class="card-title">Add Expense</h3></div>
            <form action="{{ route('admin.accounts.expense.store') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="form-group"><label>Expense Head</label>
                        <select name="expense_head_id" class="form-control" required>
                            @foreach($expenseHeads as $head)
                            <option value="{{ $head->id }}">{{ $head->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Account</label>
                        <select name="account_id" class="form-control" required>
                            @foreach($accounts as $account)
                            <option value="{{ $account->id }}">{{ $account->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group"><label>Amount (৳)</label><input type="number" name="amount" class="form-control" step="0.01" required></div>
                    <div class="form-group"><label>Date</label><input type="date" name="expense_date" class="form-control" value="{{ date('Y-m-d') }}" required></div>
                    <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="card-footer"><button type="submit" class="btn btn-danger">Add Expense</button></div>
            </form>
        </div>
    </div>
</div>
@endsection
