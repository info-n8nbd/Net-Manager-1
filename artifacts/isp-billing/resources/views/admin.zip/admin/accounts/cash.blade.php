@extends('layouts.admin')

@section('title', 'Cash In Hand')
@section('breadcrumb')
<li class="breadcrumb-item active">Cash In Hand</li>
@endsection

@section('content')
<div class="row mb-3">
    <div class="col-6 col-md-4">
        <div class="stat-box bg-success text-white text-center py-3 rounded">
            <div class="stat-number">৳{{ number_format($totalCash, 0) }}</div>
            <div class="stat-label">Cash In Hand</div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header"><h3 class="card-title">Cash Accounts</h3></div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead><tr><th>Account Name</th><th>Current Balance (৳)</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($accounts as $account)
                <tr>
                    <td>{{ $account->name }}</td>
                    <td>{{ number_format($account->current_balance, 2) }}</td>
                    <td><span class="badge badge-{{ $account->is_active ? 'success' : 'danger' }}">{{ $account->is_active ? 'Active' : 'Inactive' }}</span></td>
                </tr>
                @empty
                <tr><td colspan="3" class="text-center">No cash accounts</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
