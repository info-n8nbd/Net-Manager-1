@extends('layouts.admin')

@section('title', 'Staff Collection Dues')

@section('content-header')
<div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-hand-holding-usd mr-2"></i>Staff Collection Dues</h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item active">Staff Dues</li>
        </ol>
    </div>
</div>
@endsection

@section('content')
<div class="row mb-3">
    <div class="col-4 mb-2">
        <div class="stat-box bg-danger text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($totalPendingDues, 0) }}</div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
    <div class="col-4 mb-2">
        <div class="stat-box bg-info text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($totalCollected, 0) }}</div>
            <div class="stat-label">Collected</div>
        </div>
    </div>
    <div class="col-4 mb-2">
        <div class="stat-box bg-success text-white text-center py-3 rounded h-100">
            <div class="stat-number">৳{{ number_format($totalSubmitted, 0) }}</div>
            <div class="stat-label">Submitted</div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card card-danger card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-users mr-2"></i>Staff with Pending Dues</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Staff Name</th>
                            <th>Role</th>
                            <th>Total Collected</th>
                            <th>Total Submitted</th>
                            <th>Current Due</th>
                            <th>Last Submission</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($staffDues as $due)
                        <tr>
                            <td>
                                <strong>{{ $due->user->name ?? 'N/A' }}</strong>
                                <br><small class="text-muted">{{ $due->user->email ?? '' }}</small>
                            </td>
                            <td>
                                @if($due->user && $due->user->roles->count() > 0)
                                    @foreach($due->user->roles as $role)
                                        <span class="badge badge-info">{{ $role->name }}</span>
                                    @endforeach
                                @else
                                    <span class="badge badge-secondary">Staff</span>
                                @endif
                            </td>
                            <td>৳{{ number_format($due->total_collected, 2) }}</td>
                            <td class="text-success">৳{{ number_format($due->total_submitted, 2) }}</td>
                            <td class="text-danger"><strong>৳{{ number_format($due->current_due, 2) }}</strong></td>
                            <td>
                                @if($due->last_submission_date)
                                    {{ $due->last_submission_date->format('d M Y') }}
                                @else
                                    <span class="text-muted">Never</span>
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('admin.staff-dues.show', $due->user) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#receiveModal{{ $due->user_id }}">
                                    <i class="fas fa-hand-holding-usd"></i> Receive
                                </button>
                            </td>
                        </tr>
                        
                        <div class="modal fade" id="receiveModal{{ $due->user_id }}" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="{{ route('admin.staff-dues.receive', $due->user) }}" method="POST">
                                        @csrf
                                        <div class="modal-header bg-success">
                                            <h5 class="modal-title text-white">
                                                <i class="fas fa-hand-holding-usd mr-2"></i>Receive Payment from {{ $due->user->name }}
                                            </h5>
                                            <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-info">
                                                <strong>Current Due:</strong> ৳{{ number_format($due->current_due, 2) }}
                                            </div>
                                            <div class="form-group">
                                                <label>Amount to Receive (৳)</label>
                                                <input type="number" name="amount" class="form-control" 
                                                       value="{{ $due->current_due }}" max="{{ $due->current_due }}" 
                                                       step="0.01" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Payment Method</label>
                                                <select name="payment_method" class="form-control" required>
                                                    <option value="cash">Cash</option>
                                                    <option value="bank_transfer">Bank Transfer</option>
                                                    <option value="bkash">bKash</option>
                                                    <option value="nagad">Nagad</option>
                                                    <option value="other">Other</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Remarks (Optional)</label>
                                                <textarea name="remarks" class="form-control" rows="2"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-check mr-1"></i>Receive Payment
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-check-circle fa-3x mb-2 text-success"></i><br>
                                No staff have pending dues
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-chart-bar mr-2"></i>Collection Summary</h3>
            </div>
            <div class="card-body">
                <p><strong>Current Time:</strong> {{ now()->format('d M Y, h:i:s A') }} (BDT GMT+6)</p>
                <hr>
                <ul class="list-group">
                    @foreach($allStaffDues->take(10) as $due)
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        {{ $due->user->name ?? 'Unknown' }}
                        <span class="badge badge-{{ $due->current_due > 0 ? 'danger' : 'success' }} badge-pill">
                            ৳{{ number_format($due->current_due, 0) }}
                        </span>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
