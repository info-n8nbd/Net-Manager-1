@extends('layouts.admin')

@section('title', 'Staff Dues - ' . $user->name)

@section('content-header')
<div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-user mr-2"></i>{{ $user->name }} - Collection Details</h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.staff-dues.index') }}">Staff Dues</a></li>
            <li class="breadcrumb-item active">{{ $user->name }}</li>
        </ol>
    </div>
</div>
@endsection

@section('content')
<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user-circle mr-2"></i>Staff Info</h3>
            </div>
            <div class="card-body">
                <p><strong>Name:</strong> {{ $user->name }}</p>
                <p><strong>Email:</strong> {{ $user->email }}</p>
                <p><strong>Role:</strong> 
                    @if($user->roles->count() > 0)
                        @foreach($user->roles as $role)
                            <span class="badge badge-info">{{ $role->name }}</span>
                        @endforeach
                    @else
                        <span class="badge badge-secondary">Staff</span>
                    @endif
                </p>
                <hr>
                @if($staffDue)
                <div class="row mb-2">
                    <div class="col-4">
                        <div class="stat-box bg-danger text-white text-center py-2 rounded">
                            <div class="stat-number">৳{{ number_format($staffDue->current_due, 0) }}</div>
                            <div class="stat-label">Due</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-box bg-info text-white text-center py-2 rounded">
                            <div class="stat-number">৳{{ number_format($staffDue->total_collected, 0) }}</div>
                            <div class="stat-label">Collected</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-box bg-success text-white text-center py-2 rounded">
                            <div class="stat-number">৳{{ number_format($staffDue->total_submitted, 0) }}</div>
                            <div class="stat-label">Submitted</div>
                        </div>
                    </div>
                </div>
                
                @if($staffDue->current_due > 0)
                <form action="{{ route('admin.staff-dues.clear-all', $user) }}" method="POST" onsubmit="return confirm('Are you sure you want to mark all dues as received?');">
                    @csrf
                    <button type="submit" class="btn btn-success btn-block">
                        <i class="fas fa-check-double mr-1"></i>Receive All Dues (৳{{ number_format($staffDue->current_due, 2) }})
                    </button>
                </form>
                @endif
                @else
                <div class="alert alert-info">No collection records found for this staff.</div>
                @endif
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card card-warning card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-clock mr-2"></i>Unsubmitted Payments ({{ $unsubmittedPayments->count() }})</h3>
            </div>
            <div class="card-body table-responsive p-0" style="max-height: 400px;">
                <table class="table table-hover table-striped table-head-fixed">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Amount</th>
                            <th>Date & Time (BDT)</th>
                            <th>Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($unsubmittedPayments as $payment)
                        <tr>
                            <td>
                                <strong>{{ $payment->client->name ?? 'N/A' }}</strong>
                                <br><small class="text-muted">{{ $payment->client->client_id ?? '' }}</small>
                            </td>
                            <td class="text-success"><strong>৳{{ number_format($payment->amount, 2) }}</strong></td>
                            <td>
                                {{ $payment->created_at->format('d M Y, h:i:s A') }}
                                <br><small class="text-muted">(BDT GMT+6)</small>
                            </td>
                            <td><span class="badge badge-info">{{ ucfirst($payment->payment_method ?? 'Cash') }}</span></td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">
                                <i class="fas fa-check-circle fa-2x mb-2 text-success"></i><br>
                                All payments have been submitted
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                    @if($unsubmittedPayments->count() > 0)
                    <tfoot class="bg-light">
                        <tr>
                            <th>Total Unsubmitted</th>
                            <th class="text-danger">৳{{ number_format($unsubmittedPayments->sum('amount'), 2) }}</th>
                            <th colspan="2"></th>
                        </tr>
                    </tfoot>
                    @endif
                </table>
            </div>
        </div>
        
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-history mr-2"></i>Submission History</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Submission #</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Date & Time (BDT)</th>
                            <th>Received By</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($submissions as $submission)
                        <tr>
                            <td><code>{{ $submission->submission_no }}</code></td>
                            <td class="text-success"><strong>৳{{ number_format($submission->amount, 2) }}</strong></td>
                            <td><span class="badge badge-info">{{ ucfirst($submission->payment_method) }}</span></td>
                            <td>
                                {{ $submission->received_at ? $submission->received_at->format('d M Y, h:i:s A') : $submission->created_at->format('d M Y, h:i:s A') }}
                                <br><small class="text-muted">(BDT GMT+6)</small>
                            </td>
                            <td>{{ $submission->receiver->name ?? 'N/A' }}</td>
                            <td>
                                <span class="badge badge-{{ $submission->status == 'received' ? 'success' : ($submission->status == 'pending' ? 'warning' : 'danger') }}">
                                    {{ ucfirst($submission->status) }}
                                </span>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">No submission history</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($submissions->hasPages())
            <div class="card-footer">
                {{ $submissions->links() }}
            </div>
            @endif
        </div>
    </div>
</div>

<a href="{{ route('admin.staff-dues.index') }}" class="btn btn-secondary">
    <i class="fas fa-arrow-left mr-1"></i>Back to Staff Dues
</a>
@endsection
